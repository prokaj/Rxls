
## .onAttach<-function(libname, pkgname){
##     inst<-file.path(Sys.getenv("appdata"),Rxlsdir,"versions")
##     src<-system.file("EXCEL/versions",package=pkgname)
##     if (!file.exists(inst) || file.info(inst)$mtime<file.info(src)$mtime)
##         {
##         msg<-paste(
##             "Célszerű lefuttatni az 'installRxls()' parancsot!",sep="")
##         packageStartupMessage(msg)
##     }
## }
read.dcf0<-function(file,as.matrix=FALSE){
  lines<-readLines(file)
  ind<-lines==""
  fac<-cumsum(ind)
  fac[ind]<-NA
  res<-split(strsplit(lines,": "),fac)
  res<-lapply(res,function(x){
    x1<-sapply(x,"[",1) #]
    x2<-sapply(x,"[",2) #]
    names(x2)<-x1
    x2
  })
  names(res)<-sapply(res,"[","file") #]
  if(as.matrix) do.call(rbind,res) else res
}

chk.prop<-function(p,src,inst)
  sapply(src,function(f)
         identical(inst[[f["file"]]][p],f[p]))

.onAttach<-function(libname, pkgname){
  inst<-file.path(Sys.getenv("appdata"),Rxlsdir,"versions")
  if(!file.exists(inst)) {
    msg<-paste("Az Rxls csomag telepítése hiányos vagy sérült.",
               "\tFutassa le az 'installRxls()' parancsot!\n",
               sep="\n")
    packageStartupMessage(msg)
    return()
  }
  msg<-""
  
  ver.inst <- read.dcf0(inst)
  
  src<-system.file("EXCEL/versions",package=pkgname)
  ver.src<-if(file.exists(src)) read.dcf0(src) else list()
  v.ok<-chk.prop("version",src=ver.src,inst=ver.inst)
  m.ok<-chk.prop("md5sum",src=ver.src,inst=ver.inst)
  if(!all(v.ok & m.ok)){
    f<-names(ver.src)
    if(!all(v.ok)){
      msg<-paste("Verziószám eltérés:",
                 paste(f[!v.ok],collapse=", "))
    }
    if(!all(m.ok)){
      msg<-paste(msg,
                 paste("Ellenőrző összeg eltérés:",
                       paste(f[!m.ok],collapse=", ")),
                 sep="\n")
    }
    msg<-paste(msg,
               "Célszerű lefuttatni az 'installRxls()' parancsot!",
               sep="\n")
    packageStartupMessage(msg)
  }
}

