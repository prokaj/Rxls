XLsource<-function(...,wbname=.wbname,
                   name = {
                     dots <- match.call(expand.dots = FALSE)$...
                     if (length(dots) && 
                         !all(sapply(dots, function(x) is.symbol(x) ||
                                     is.character(x))))
                       stop("... must contain names or character strings")
                     sapply(dots, as.character)},
                   env=parent.frame(),
                   wsname = sprintf("R kód(%s)",name),
                   wb = ##ifelse(is.null(wbname),
                        ##XL[["activeworkbook"]],
                        XL[["workbooks",wbname]]##)
                  ,
                   XL=THISXL){
  on.exit({wb<-XL<-NULL;gc()})
  for(wsn in wsname){
      withObj(wb[["worksheets",wsn]],{
                x<-.[["usedrange"]][["value"]]
                x<-x[!is.na(x)]
                eval(parse(text=paste(x,collapse="\n")),envir=env)
            })
  }
}
##
XLapply<-function(obj,prop,...)
  sapply(seq_len(obj$count()),function(i)comInvoke(obj$item(i),method=prop,...))

XLdata<-function(c1=1,c2=2,c2.offset=c2-c1,range,
                 onlyvisible=TRUE,
                 rmHidden=FALSE,
                 env=parent.frame(),
                 XLrange={
                   on.exit(XLrange<-NULL);
                   if(missing(range))
                     range<-XL$selection()$address(external=TRUE)
                   .XLrange(range,XL=XL)
                 },
                 XL=THISXL,
                 value="value2"){
  XLrange<-XLusedrange(XLrange$columns(c1))
  var.names<-XLrange[[value]]
  var.names<-check.merge(var.names,Cells=XLrange,value=value)
  XLrange<-XLrange$offset(0,c2.offset)
  var.values<-XLrange[[value]]
  var.values<-check.merge(var.values,Cells=XLrange,value=value)
  hind<-sapply(seq_along(var.names),function(i)
               XLrange$rows(i)$hidden())
  ind<- if(onlyvisible) which(!hind) else seq_along(var.names)
  if(rmHidden){
    xx<-var.names[hind]
    xx<-unlist(xx[sapply(xx,function(y)
                         is.character(y) &&
                         exists(y,envir=env,inherits=FALSE))])
    rm(list=xx,envir=env)
  }
  for(i in ind){
    if(is.character(var.names[[i]]))
      assign(var.names[[i]],var.values[[i]],envir=env)
  }
}
