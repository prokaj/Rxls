install.xls <- function(filelist=NULL,PACKAGE="",
                        instdir=local({
                          sdir<-Sys.getenv("HOME")
                          if(sdir=="")
                            sdir<-Sys.getenv("APPDATA")
                          if(sdir=="")
                            sdir<-getwd()
                          caption<-if(length(filelist)>1)
                            paste("Melyik mappába kerüljenek a telepítendő fileok:",
                                  paste(filelist, collapse=", ") ,sep=" ")
                          else
                            paste("Melyik mappába kerüljön a", filelist,"file?")
                          choose.dir(sdir,caption=caption)
                        }),
                        loadRxls=TRUE){
  if(is.null(filelist) || (length(filelist)==0)) return()
  cat("**************************************\n")
  cat("*       EXCEL fileok telepítése      *\n")
  cat("**************************************\n")
  flush.console()
  if(loadRxls){
    require(com)
    ## comRegisterRegistry() ## ez csak rendszergazdakent hatasos
    ## comRegisterServer()   ## ez automatikusan megtortenik a csomag betoltesekor
    xlopen<-function(x) {
      y<-suppressWarnings(normalizePath(x))
      if(file.exists(y)){
        if(!comIsValidHandle(XL$workbooks(basename(y))))
          XL[["workbooks"]]$open(y)
        else
          warning("Az '", basename(y), "' már meg van nyitva.")
      }else
      warning("Az '", y,"' = normalizePath('",x,"') file nem létezik.")
    }
    XL<-comCreateObject("EXCEL.APPLICATION")
    if(is.null(XL))
      win.stop("Nem sikerült elindítani az EXCEL-t!!")
    XL[["displayalerts"]]<-FALSE
    on.exit({
      XL[["displayalerts"]]<-TRUE
      XL$quit()
      if(XL[["workbooks"]][["count"]]>0) XL[["visible"]]<-TRUE
      XL<-NULL
      gc()
    })
    xlopen(file.path(Sys.getenv("appdata"),Rxlsdir,"R.xls"))
    ## system.file("EXCEL","R.xls",package="Rxls"))
    for(fn in c(filelist))
      xlopen(system.file("EXCEL",fn,package=PACKAGE))
    dir<-instdir
    if(!is.na(dir)){
      cat("Fileok másolása:\n")
      cat(paste(filelist,collapse=" "),"->",dir,"\n",sep=" ")
      for(fn in filelist){
        sfn<-suppressWarnings(normalizePath(file.path(dir,fn)))
        XL[["workbooks",fn]]$saveas(sfn)
      }
    }
    for(fn in filelist){
      XL[["workbooks",fn]]$close(TRUE)
    }
  }else{
    if(is.na(instdir)) return()
    for(fn in filelist){
      message(fn," másolása",appendLF=FALSE)
      copy<-!file.exists(file.path(instdir,fn)) ||
      length(grep("[yYiI]",
                  substr(readline("\nA file létezik, csere (i/N)?"),
                         1L,1L))==1)
      if(copy){
        if(file.copy(system.file("EXCEL",fn,package=PACKAGE),
                     instdir,overwrite=TRUE))
          message("...ok") else message("failed")
      }
    }
  }
  cat("**************************************\n")
  cat("*      A telepítés befejeződött       \n")
  cat("**************************************\n")
  flush.console()
}
#$
