logDevInit<-function(mod=c("EXCEL","TCL","R","null")){
  mod <- match.arg(mod)
  nullfn<-function(...){}
  pbs<-list()
  if(mod=="null"){
    user<-new.env()
    user$mod <-mod
    user$close <- nullfn
    user$log <- function(...)sprintf(...)
    user$pbs <- function(...)pbs[[...]]
    pbs[["1"]]<-list(step = nullfn, show = nullfn, inc = nullfn,
                     rm = nullfn, hide = nullfn, reset= nullfn,
                     refresh = nullfn )
    user$progress <- function(...) "1"
    return(user)
  }
  itms <- vector("list")
  cnt <-0; printtime <- 0
  refresh<-function(mindiff,itms)
    if(unclass(Sys.time())-printtime>=mindiff){
      printtime<<-unclass(Sys.time())
                show(paste(lapply(itms,
                                  function(x)
                                  do.call(sprintf,as.list(x))),collapse=" "))
              }
  switch(mod,
         EXCEL= {
                  XL<-NULL
                  if(exists("THISXL",envir=parent.frame()))
                     XL<-get("THISXL",envir=parent.frame())
                  if (missing(XL) || !(inherits(XL,"COMObject") && comIsValidHandle(XL)))
                    XL<-comGetObject("Excel.Application")
                  if (!(inherits(XL,"COMObject") && comIsValidHandle(XL)))
                    XL<-comCreateObject("Excel.Application")
                  if (!(inherits(XL,"COMObject") && comIsValidHandle(XL)))
                    stop("Nem található használható EXCEL példány")
                  XL[["visible"]]<-TRUE
                  show<-function(txt){ XL[["Statusbar"]]<-gsub("\n"," ",txt,useBytes=TRUE); txt}
                  close<-function(){
                        XL[["Statusbar"]]<-FALSE
                        XL<-NULL
                        gc()
                      }
                } ,
         TCL = {
                 if(require(tcltk)){
                   tt<-tktoplevel();  tktitle(tt)<-"R futási állapot"
                   tkwm.minsize(tt,550,10);
                   tkwm.maxsize(tt,700,25)
                   l<-tklabel(tt); 
                   tkpack(l); 
                   tkpack.configure(l,side="left")
                   show<-function(txt) { 
                     tcl(l,"configure",text=txt) ; 
                     txt
                   }
                   close<-function() tkdestroy(tt)
                 }
                 else
                   stop("A 'tcltk' csomag nem található")
               } ,
         R   = {
                 cat("\n");
                 txtlen<-0;
                 show<-function(txt){
                   cat("\r", sprintf(sprintf("%%-%ds", txtlen), txt))
                   flush.console()
                   txtlen <<- nchar(txt)
                   txt
                 }
                 close=function(){
                   cat("\n"); txtlen <<- 0
                   flush.console()
                 }
               }
         )
  log <- function(...,lazyness=-1)
    refresh(lazyness,c(itms, list(list(...))))
  newprogress <- function(pattern,...,lazyness=-1){
                   mdiff <- lazyness
                   name <- as.character(cnt)
                   x <- list(list(pattern,...))
                   names(x)<-name
                   itms<<-c(itms,x)
                   list(step = 
                        function(...){
                          itms[[name]]<<-c(itms[[name]][1],list(...))
                          refresh(mdiff,itms)
                        },
                        inc = function(...){
                          if(length(itms[[name]])==2)
                            itms[[name]][[2]]<<-itms[[name]][[2]]+1
                          refresh(mdiff,itms)
                        },
                        refresh = function() refresh(-1,itms),
                        hide =function(){
                          x<<-itms[name]
                          itms[name]<<-NULL
                        },
                        show = function() itms<<-c(itms,x),
                        rm = function() {
                          itms[name] <<- NULL
                          pbs[name] <<- NULL
                        },
                        reset = function(pattern,...,lazyness){
                          if(!(missing(pattern))) itms[[name]]<<-list(pattern,...);
                          if(!(missing(lazyness))) mdiff<<-lazyness
                        }
                        )
                 };
  progress<-function(...){
    cnt <<- cnt+1
    pbname<-as.character(cnt)
    pbs[[pbname]] <<- newprogress(...)
    pbname
  }
  finalize<-function(...){
    close()
  }
  local({
    user<-new.env()
    user$mod<-mod
    user$log<-log
    user$pbs<-function(...)pbs[[...]]
    user$progress<-progress
    user$close<-finalize
    reg.finalizer(user,finalize)
    user
  })
}
mkfun<-function(){
  logDevs<-list()
  logDev.act <- 0
  logDev.id <- 0
  ld.act<-function()
    structure(logDev.act,names=names(logDevs)[logDev.act])
  logDev<-function(...){
    logDev.id <<- logDev.id + 1
               logDevs<<-c(logDevs,logDevInit(...))
    logDev.act<<-length(logDevs)
    names(logDevs)[logDev.act]<<-paste(logDevs[[logDev.act]]$mod,
                                       logDev.id,sep=":")
    logDevs<<-logDevs
    ld.act()
  }
  logDev("null")
  logDev.list<-function()
    structure(seq_along(logDevs), names=names(logDevs))
  logDev.off<-function(){
    if(logDev.act!=1){
      logDevs[[logDev.act]]$close()
      logDevs<<-logDevs[-logDev.act]
      logDev.act<<-length(logDevs)
    }
    ld.act()
  }
  logDev.set<-function(num){
    if(num<=length(logDevs) && num>=1) logDev.act<<-num
    ld.act()
  }
  progress.call<-function(...,.LID,.PID,.METHOD){
    f<-logDevs[[.LID]]
    if(!is.null(f)) f<-f$pbs(.PID)
    if(is.null(f))
      warning("Trying to use deleted log Device")
    else f[[.METHOD]](...)
  }
  progress<-function(...){
    lid<-names(logDevs)[logDev.act]
    pid<-logDevs[[logDev.act]]$progress(...)
    methods<-names(logDevs[[lid]]$pbs(pid))
    names(methods)<-methods
    lapply(methods,function(fn){
      formals(progress.call)[c(".LID",".PID",".METHOD")] <- c(lid,pid,fn)
      progress.call
    })
  }
  
  logMessage<-function(...,sleep=0){
    logDevs[[logDev.act]]$log(...)
    if(sleep>0) Sys.sleep(sleep)
  }

  list(logDev=logDev,
       logDev.off=logDev.off,
       logDev.list=logDev.list,
       logDev.set=logDev.set,
       progress=progress,
       logMessage=logMessage)
}

listAssign<-function(lst,env){
  for(nn in names(lst))
    assign(nn,lst[[nn]],envir=env)
}

listAssign(mkfun(),env=environment())

condMessage<-function(cond) logMessage(cond$message)

errMessage<-function(cond) {
  err.msg<-cond$message
  if(nchar(err.msg)>255)
    err.msg<-paste(substr(err.msg,1,255-3),"...",sep="")
  logMessage(err.msg)
  winDialog("ok",err.msg)
}

## 2013.05.30 logdevice arg
background<-function(expr=eval(.FUN),
                     logdevice=ifelse(exists("THISXL") &&
                                          comIsValidHandle(THISXL),
                         c("EXCEL","null","R","TCL"),
                         c("null","R","EXCEL","TCL"))){
    logdevice <- match.arg(logdevice)
    logDev(logdevice,XL=THISXL); on.exit(logDev.off())
    withCallingHandlers(expr,
                        error =Rxls:::errMessage,
                        warning=Rxls:::condMessage,
                        message=Rxls:::condMessage)
}
XLwith<-function(expr=eval(.FUN),
                 logdevice = ifelse(exists("THISXL") &&
                                        comIsValidHandle(THISXL),
                     c("EXCEL", "null", "R", "TCL"),
                     c("null", "R", "EXCEL", "TCL")),
                 env=parent.frame()){
    detachXL<-attachXL(env)
    on.exit(detachXL(),add=TRUE)

    logdevice <- match.arg(logdevice)
    logDev(logdevice)
    on.exit(logDev.off(),add=TRUE)

    withCallingHandlers(eval(substitute(expr),env),
                        error = Rxls:::errMessage,
                        warning = Rxls:::condMessage, 
                        message = Rxls:::condMessage)
}

err.fun<-if(require(tcltk))
  function(){
  err.msg<-geterrmessage()
  tk_messageBox("ok",paste(strwrap(err.msg,width=60),collapse="\n"))
  }else function(){
  err.msg<-geterrmessage()
  if(nchar(err.msg)>255)
    err.msg<-paste(substr(err.msg,1,255-3),"...",sep="")
  winDialog("ok",err.msg)
}
## err.fun<-function(){
##   err.msg<-geterrmessage()
##   if(nchar(err.msg)>255)
##     err.msg<-paste(substr(err.msg,1,255-3),"...",sep="")
##   winDialog("ok",err.msg)
## }
warn.fun<-function(msg){
## if(logDevs[[logDev.act]]$mod %in% c("TCL","EXCEL")){
logMessage(paste("warning:",names(msg)),sleep=2)
##}else print.warnings(msg)
}

