reg.unlist<-function(x,prefix=""){
  if(!is.list(x)) return(structure(x,names=prefix));
  do.call(c,lapply(seq_along(x),
                   function(y)
                   reg.unlist(x[[y]],
                              paste(prefix,names(x)[y],sep="\\"))))
}
R_RegEntries<-function(){
  require(utils)
  views<-c("32-bit","64-bit")
  names(views)<-paste(views,":")
  hives<-eval(formals(readRegistry)[["hive"]])
  keys<-c("SOFTWARE\\R-core",
          "CLSID\\{3660C348-DF59-4CA2-83E8-3A913A9FBC77}",
          "TypeLib\\{38008F95-0BBF-43FD-A884-2DE4B3939429}\\1.0\\0\\win32")
  names(keys)<-c("R","CLSID","TLB")
  names(hives)<-hives
  res<-lapply(views, function(view){
    res<-lapply(keys,function(key){
      res<-lapply(hives,function(hive)
                  try(readRegistry(hive=hive,key=key,
                                   maxdepth = 100,view=view),silent=TRUE))
      res<-res[!sapply(res,inherits,"try-error")]
      if(length(res)) names(res)<-paste(names(res),key,sep="\\")
      res
    })
    class(res)<-"reg.data"
    res
  })
  res
}
print.reg.data<-function(x){
  cat("R related registry entries:\n")
  z<-reg.unlist(x)
  cat(paste(names(z),z,sep=": \n"),sep="\n")
  cat("\n")
  invisible(x)
}

