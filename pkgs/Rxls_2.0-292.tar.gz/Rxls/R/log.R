  
logInit<-function(mod=c("EXCEL","TCL","R","null"),XL=NULL){  
    mod  <- match.arg(mod)
    if(mod=="null"){
      nullfn<-function(...){}
      return(list(close = nullfn,
                  log=function(...)sprintf(...),
                  progress  = function(...)
                  list(step = nullfn, show = nullfn, inc  = nullfn,
                       rm   = nullfn, hide = nullfn, reset= nullfn)
                  )
             )
    }
    itms <- vector("list")
    cnt  <-0; printtime <- 0
    
  refresh<-function(mindiff,itms)
      if(unclass(Sys.time())-printtime>=mindiff){
        printtime<<-unclass(Sys.time())
        show(paste(lapply(itms,
                          function(x)
                          do.call(sprintf,as.list(x))),collapse=" "))
      }
    
    switch(mod,
           EXCEL={
                   XL<-NULL
                   if(exists("THISXL",envir=parent.frame()))
                      XL<-get("THISXL",envir=parent.frame())
                   if (missing(XL) || !(inherits(XL,"COMObject") && comIsValidHandle(XL)))
                     XL<-comGetObject("Excel.Application")
                   if (!(inherits(XL,"COMObject") && comIsValidHandle(XL)))
                     XL<-comCreateObject("Excel.Application")
                   if (!(inherits(XL,"COMObject") && comIsValidHandle(XL)))
                     stop("Nem található használható EXCEL példány")
                   XL[["visible"]]<-TRUE
                   show<-function(txt){ XL[["Statusbar"]]<-gsub("\n"," ",txt,useBytes=TRUE); txt}
                   close<-function(){
                         XL[["Statusbar"]]<-FALSE
                         XL<-NULL
                         gc()
                       }
                 },
           TCL  ={
                   if(require(tcltk)){
                     tt<-tktoplevel();  tktitle(tt)<-"R futási állapot"
                     tkwm.minsize(tt,550,10);
                     tkwm.maxsize(tt,700,25)
                     l<-tklabel(tt); 
                     tkpack(l); 
                     tkpack.configure(l,side="left")
                     show<-function(txt) { 
                       tcl(l,"configure",text=txt) ; 
                       txt
                     }
                     close<-function() tkdestroy(tt)
                   }
                   else
                     stop("A 'tcltk' csomag nem található")
                 },
           R    ={
                   cat("\n");
                   txtlen<-0;
                   show<-function(txt){
                     cat("\r", sprintf(sprintf("%%-%ds", txtlen), txt))
                     flush.console()
                     txtlen <<- nchar(txt)
                     txt
                   }
                   close=function(){
                     cat("\n"); txtlen <<- 0
                     flush.console()
                   }
                 }
           )
    
  
  log   <- function(...,lazyness=-1){
             refresh(lazyness,##itms<<-
                     c(itms, list(list(...))))
           };
  progress <- function(pattern,...,lazyness=-1,tipus=c("TEXT","ICON")){
                tipus <- match.arg(tipus)
                mdiff <- lazyness
                name  <- as.character(cnt<<-cnt+1)
                x     <- list(list(pattern,...))
                names(x)<-name
                itms<<-c(itms,x)
                list(step =
                     function(...){
                       itms[[name]]<<-c(itms[[name]][1],list(...))
                       refresh(mdiff,itms)
                     },
                     inc = function(...){
                       if(length(itms[[name]])==2)
                         itms[[name]][[2]]<<-itms[[name]][[2]]+1
                       refresh(mdiff,itms)
                     },
                     hide  = 
                     function(){
                       x<<-itms[name]
                       itms[name]<<-NULL
                     },
                     show  = function() itms<<-c(itms,x),
                     rm    = function() itms[name]<<-NULL,
                     reset = function(pattern,...,lazyness){
                       if(!(missing(pattern))) itms[[name]]<<-list(pattern,...);
                       if(!(missing(lazyness))) mdiff<<-lazyness   
                     }  
                     )
              };
  local({
    user<-new.env()  
    user$log<-log
    user$progress<-progress
    user$close<-function(){
                  itms<<-vector("list")
                  cnt<<-0; printtime <<- 0
                  rm.err.warn()
                  close()
                };     
    err.fun<-if(require(tcltk))
      function(){
      err.msg<-geterrmessage()
      tk_messageBox("ok",paste(strwrap(err.msg,width=60),collapse="\n"))
      }else function(){
      err.msg<-geterrmessage()
      if(nchar(err.msg)>255)
        err.msg<-paste(substr(err.msg,1,255-3),"...",sep="")
      winDialog("ok",err.msg)
    }
      
    warn.fun<-function(x){
      print.warnings(x)
      if(mod %in% c("TCL","EXCEL")){
        log(paste("warning:",msg))
        Sys.sleep(2)
      }
    }

    rm.err.warn<-function(...){
      close()
      ##if(exists("warning",envir=.GlobalEnv,inherits=FALSE))
      ##  rm("warning",envir=.GlobalEnv)
      options(error=NULL)##,warning.expression=NULL)
    }

    ##assign("warning",warn.fun,envir=.GlobalEnv)
    if(!is.null(mod) && mod!="R") options(error=err.fun)
    ##,warning.expression=quote({warn.fun(last.warning)}))
    reg.finalizer(user,f=rm.err.warn);
    user
  })
  }
