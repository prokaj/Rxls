## msoFileDialogFilePicker 3 File picker dialog box.
## msoFileDialogFolderPicker 4 Folder picker dialog box.
## msoFileDialogOpen 1 Open dialog box.
## msoFileDialogSaveAs 2 Save As dialog box.
XLfiledlg<-function(title="Select file",
                    default="",
                    multi=FALSE,
                    type=c("file","folder")){
  msotype<-switch(match.arg(type),"file"=3,"folder"=4)
  XL<-comCreateObject("excel.application")
  dlg<-XL$filedialog(msotype)
  dlg[["title"]]<-title
  dlg[["Initialfilename"]]<-default
  if(dlg$show()==-1)
    res<-sapply(seq_len(dlg$selecteditems()$count()),
                dlg$selecteditems)
  else res<-NULL;
  dlg<-NULL;
  XL$quit(); XL<-NULL
  gc()
  res
}
pkgzip<-function(pkgs={
  preselect<-grep("(com(|proxy)|Rxls)$", rownames(ipkgs),value=TRUE)
  if(ask)
    select.list(rownames(ipkgs),preselect,
                multiple=TRUE,title="Zippelendő csomagok:",graphics=T)
  else preselect
},
                 zip.mappa=choose.dir(Sys.getenv("HOME"),
                   "Zip állományok helye:"),
                 ask=interactive(),PACKAGES=FALSE){
  if(! (require(utils) && require(tools))) stop()
  ipkgs<-installed.packages()
  ## pkgs<-dir(.libPaths(),full.name=TRUE)
  ## A 3.0.1-ben choose.dir nem műközdik rendesen!
  pkgs<-file.path(ipkgs[pkgs,"LibPath"],ipkgs[pkgs,"Package"])
  if(is.na(zip.mappa)) return(character(0))
  zip.mappa<-file_path_as_absolute(zip.mappa)
  wd <- getwd(); on.exit(setwd(wd))
  for(pkg in pkgs){
    dcf <- read.dcf(file.path(pkg,"DESCRIPTION"));
    fn <- paste(paste(dcf[1,"Package"],dcf[1,"Version"],sep="_"),
                "zip",sep=".");
    setwd(dirname(pkg))
    zip(file.path(zip.mappa, fn),basename(pkg))
  }
  if(PACKAGES && require(tools)){
    write_PACKAGES(dir=zip.mappa,type="win.binary")
  }
  pkgs
}

