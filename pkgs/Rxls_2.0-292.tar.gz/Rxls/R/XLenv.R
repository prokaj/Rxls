getXLenv<-function () {
    .xln<-ls(pos=1,all.names=TRUE,pattern = "^\\.XL")
    if(length(.xln)==1){
        .xl<-get(.xln,pos=1)
        .wsn<-ls(env=.xl,pattern="^wb_")
        if(length(.wsn)==1){
            get(.wsn,envir = .xl)
        }
    }
}

withXLenv<-function(expr,envir=getXLenv())
    eval(substitute(expr),envir=envir)

XLattachname<-function(env)
    with(env,
         if(exists("THISXL"))
             withObj(THISXL[["hwnd"]],
                     ifelse(exists(".wbname"),
                            sprintf(".XL%d:wb_%s",.,.wbname),
                            sprintf(".XL%d",.))
                     ))

null.fn<-function(){}
environment(null.fn)<-.GlobalEnv

attachXL<-function(env=getXLenv(),
                   name=XLattachname(env),
                   vars=c("THISXL",".wbname",".wsname"),
                   allow.multiple=FALSE,
                   silent=TRUE){
    if(!is.environment(env) ||
       is.null(name) ||
       (!allow.multiple && (name %in% search()))) return(null.fn)
    names(vars)<-vars
    attach(name=name,
           what=lapply(vars,function(x)
               if(exists(x,envir = env,inherits = T))
                   get(x,envir=env,inherits=T)),
           warn.conflict=!silent)
    env<-vars<-allow.multiple<-silent<-NULL
    function()if(name %in% search()) detach(name,character.only = TRUE)
}

detachXLenvs<-function(XLid=paste(".XL",hwnd,sep=""),
                       hwnd=0,
                       XLid.pattern=sprintf("^\\%s(:|$)",XLid)){
    while(any(grepl(XLid.pattern,search())))
        detach(pos=grep(XLid.pattern,search())[1])
}
