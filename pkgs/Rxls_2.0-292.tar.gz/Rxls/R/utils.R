win.stop<-function(...){
  if(interactive()) winDialog(type="ok",substr(sprintf(...),1,255))
  stop(call.=FALSE)
}
file.fullname<-function (dir,file){
  normalizePath(file.path(dir,file),mustWork=FALSE)
}
ACCESS.get <- function(dir,file,table,where="",fields="*"){
  if(!require(RODBC)) stop("Az RODBC csomag nincs telepítve")
  ffile <- file.fullname(dir,file)
  ch<- odbcConnectAccess(ffile)
  if(ch<0) stop(sprintf("Nem sikerült csatlakozni a '%s' adatbázishoz",ffile))
  on.exit(close(ch))
  ered <- odbcQuery(ch,sprintf("SELECT %s FROM %s %s;",
                               paste(fields,collapse=", "),
                               table,where))
  if(ered<0){
    sqlErr<-odbcGetErrMsg(ch)
    odbcClearError(ch)
    stop(sprintf("Nem sikerült beolvasni a következőt:\n%s[%s]\n%s",
         ffile,table,paste(sqlErr,collapse="\n")))
  }
  else {
    x<-sqlGetResults(ch, buffsize=10000)
    attr(x,"call")<-getPar0()
    x
  }
}
ODBC.get <- function(dsn,sql){
  if(!require(RODBC)) stop("Az RODBC csomag nincs telepítve")
  ch<-odbcConnect(dsn)
  if(ch<0) stop(sprintf("Nem sikerült csatlakozni a '%s' adatbázishoz",dsn))
  on.exit(close(ch))
  ered <- odbcQuery(ch,sql)
  if(ered<0){
    sqlErr<-odbcGetErrMsg(ch)
    odbcClearError(ch)
    stop(sprintf("Adatbázis olvasási hiba:\n%s",paste(sqlErr,collapse="\n")))
  }
  else{
    x<-sqlGetResults(ch, buffsize=10000)
    attr(x,"call")<-getPar0()
    x
  }
}
getFromDB<-function(dir,file,table,where="",dsn,sql){
  if(!inherits(try(dsn,silent=TRUE),"try-error")){
    ## kód az SQL ághoz
    ODBC.get(dsn=dsn,sql=sql)
  }else{
    ## kód az ACCESS ághoz
    ACCESS.get(dir=dir,file=file,table=table,where=where)
  }
}

ACCESS.get2 <- function(dir,file,table,where="",fields="*",
                        progress.text="Adatok olvasása [%d]"){
  if(!require(RODBC)) stop("Az RODBC csomag nincs telepítve")
  ffile <- file.fullname(dir,file)
  ch <- odbcConnectAccess(ffile)
  if(ch<0) stop(sprintf("Nem sikerült csatlakozni a '%s' adatbázishoz",ffile))
  on.exit(close(ch))
  ered <- odbcQuery(ch,sprintf("SELECT %s FROM %s %s;",
                               paste(fields,collapse=", "),
                               table,where))
  if(ered<0){
    sqlErr<-odbcGetErrMsg(ch)
    odbcClearError(ch)
    stop(sprintf("Nem sikerült beolvasni a következőt:\n%s[%s]\n%s",
         ffile,table,paste(sqlErr,collapse="\n")))
  }
  else {
    pb<-progress(progress.text,0,lazyness=.3)
    on.exit({pb$refresh();pb$rm()},add=TRUE)
    res<-NULL
    while(inherits(x<-sqlGetResults(ch, max=1e4,buffsize=1e4),"data.frame")){
      if(is.null(res))
        res<-x
      else
        res[seq(nrow(res)+1,by=1,length=nrow(x)),]<-x
      pb$step(nrow(res))
    }
    attr(res,"call")<-getPar0()
    res
  }
}

withObj<-function(x=NULL,expr,...,quiet=TRUE){
  if(!is.null(x)) eval(substitute(expr),list("."=x),enclos=parent.frame()) else
  if(!quiet) {
    warning(sprintf("Object '%s' is NULL", deparse(substitute(x))))
    invisible(NULL)
  }
}

## .XL<-function(name="THISXL",env=parent.frame(2))
##        withObj(try(get(name,env,inherits=TRUE),silent=TRUE),
##              if(inherits(.,"try-error")) NULL else .)

## .XL<-function(XL=ifelse(exists(".activeXL",pos=1),
##                      get(".activeXL",pos=1),
##                      ls(pos=1,pattern="^.XL",all.names=TRUE)[1]))
##       get("THISXL",envir=get(XL,pos=1))
getPar0<-function(call=sys.call(sys.parent()),env=parent.frame()){
  for(x in names(call))
    if(x!="") try(call[[x]]<-get(x,env),silent=TRUE)
  call
}
