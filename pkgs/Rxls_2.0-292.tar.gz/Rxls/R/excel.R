## -*- R -*-
XLlist2df<-function(x,header=1,trim=FALSE,skip=0,
                    head.sep="",numeric=FALSE,...){
  if(trim){
    ind<-unlist(lapply(split(is.na(x),row(x)),all))
    x<-x[!ind,,drop=FALSE]
    ind<-unlist(lapply(split(is.na(x),col(x)),all))
    x<-x[,!ind,drop=FALSE]
  }
  if(is.function(skip)) skip<-skip(x)
  if(skip>0) x <- x[-(1:skip),,drop=FALSE]
  nam <- NULL
  if(is.function(header)) header<-header(x)
  if(header>0 && nrow(x)>header){
    head <- x[1:header,,drop=FALSE]
    head[is.na(head)] <- ""
    x <- x[(header+1):nrow(x),,drop=FALSE]
    if(header>1)
    nam<-sapply(split.default(unclass(head),col(head)),
                paste,collapse=head.sep)
    else
    nam <- as.character(head)
  }
  if(numeric) {
    ats<-attributes(x)
    suppressWarnings(x<-lapply(x,as.numeric))
    attributes(x)<-ats
  }
  dots<-list(...)
  x<-do.call("data.frame",
  c(lapply(split.default(x,col(x)),unlist.keepclass),
  dots[intersect(names(dots),names(formals(data.frame)))]))
  if(!is.null(nam)) names(x)<-nam
  x
}
unlist.keepclass<-function(x)
  structure(unlist(x,recursive=FALSE),class=oldClass(x[[1]]))
XLrc<-function(r,
               rind=r$rows()$count(),
               cind=r$columns()$count())
    c( r$rows(rind)$row(), r$columns(cind)$column() )


XLusedrange<-function(r){
    if(missing(r)) r<-THISXL$selection()
   
    withObj(r[["worksheet"]],{
                rc<-XLrc(r)
                urc<-XLrc(.[["usedrange"]])
                Mrc<-pmin.int(urc,rc)
                mrc<-XLrc(r,1,1)
                .$range(.$cells(mrc[1],mrc[2]),.$cells(Mrc[1],Mrc[2]))
            })
}

XLgetval<-function(r,value="value2")
    XLusedrange(r)[[value]]

check.merge<-function(x,Cells,
                      which.cols=seq_len(ncol(x)),
                      which.rows=seq_len(nrow(x)),
                      rr=which.rows[row(x)],
                      cc=which.cols[col(x)],
                      value="value2"){
  ## ha nincs egyesitett cella akkor nem kell semmit csinalni
    if(identical(FALSE,Cells$mergecells())) return(x)
    for(i in seq_along(x)[unlist(lapply(x,is.na))]){
        if((Cell<-Cells[["cells",rr[i],cc[i]]])[["MergeCells"]]){
            x[i]<-Cell[["MergeArea"]][["cells",1,1]][[value]]
            Cell<-NULL
        }
    }
    Cells <- NULL
    x
}

XLreaddf.cols<-function(range,which.cols=seq_len(ncol(x)),
                        XLrange={
                            on.exit(XLrange<-NULL,add=TRUE);
                            if(missing(range))
                                XL$selection()
                            else
                                .XLrange(range,XL=XL)
                        },
                        ...,chk.merge=TRUE,value="value2",XL=THISXL){
    XLrange<-XLusedrange(XLrange)
    x <- XLrange[[value]]
    x <- x[,which.cols,drop=FALSE]
    if(chk.merge)
        x<-check.merge(x,Cells=XLrange,which.cols=which.cols,value=value)
    XLlist2df(x,...)
}
XLreaddf.rows<-function(range,which=seq_len(nrow(x)),
                        XLrange={
                            on.exit(XLrange<-NULL,add=TRUE);
                            if(missing(range))
                                XL$selection()
                            else
                                .XLrange(range,XL=XL)
                        },
                        ...,chk.merge=TRUE,value="value2",XL=THISXL){
    XLrange<-XLusedrange(XLrange)
    x <- XLrange[[value]]
    x <- x[which,,drop=FALSE]
    if(chk.merge)
        x<-check.merge(x,Cells=XLrange,which.rows=which,value=value)
    XLlist2df(t(x),...)
}
XLDate<-function(date,d1904=FALSE)
    as.Date(date,
            origin=as.Date(if(d1904) "1903-12-30" else "1899-12-30"))

XLPOSIXct<-function(date,d1904=FALSE)
    as.POSIXct(date*3.6e6,
               origin=as.Date(if(d1904) "1903-12-30" else "1899-12-30"))
XLget<-function(range,
                XLrange={
                  if(missing(range))
                    XL$selection()
                  else
                    .XLrange(range,XL=XL)
              },value="value",XL=THISXL)
    XLusedrange(XLrange)[[value]]
.XLrange<-function(range,.wb=.wbname,.ws=.wsname,XL=THISXL){
    address<-ifelse(grepl("!",range) || inherits(try(.wb,silent=TRUE),"try-error") || is.null(.wb),
                    range,
                    sprintf("'[%s]%s'!%s",.wb,.ws,range))
    XL$range(address)
}
XLScreenUpdateTurnOff<-function(Appl,activecell=FALSE){
### Const xlCalculationManual = -4135 (&HFFFFEFD9)
  cm <- Appl[["Calculation"]]
  Appl[["Calculation"]] <- -4135
  Appl[["ScreenUpdating"]] <- FALSE
  if(activecell)
    ac<-Appl$activecell()
  function(){
    Appl[["Calculation"]] <- cm
    Appl[["ScreenUpdating"]] <- TRUE
    if(activecell) {
      ac$activate()
      ac<<-NULL
    }
    Appl<<-NULL
  }
}
XLwritedf<-function(XLrange,df,with.names=TRUE,autoFit=TRUE,setname){
  if(missing(XLrange)) XLrange<-THISXL$selection()
  if(is.null(XLrange)) return()
  ac<-XLrange$cells(1,1)
  ws<-ac$worksheet()
  turnOn<-XLScreenUpdateTurnOff(ws$application(), activecell=TRUE)
  on.exit(turnOn())
  x.offset<-0
  ws$activate()
  if(with.names){
    r<-ws$range(ac,ac$offset(0,ncol(df)-1))
    r[["value"]]<-structure(names(df),dim=c(1,ncol(df)))
    x.offset<-1
  }
  if(nrow(df)>0){
    lapply(seq_along(df),
           function(coln){
             r<-ws$range(ac$offset(x.offset,coln-1),
                         ac$offset(x.offset+nrow(df)-1,coln-1))
             r[["value"]]<-col.format(df[[coln]])
             if(inherits(df[[coln]],"POSIXt")||inherits(df[[coln]],"Date"))
               r$parse()
           }
           )
  }
  if(autoFit){
    r<-ws$range(ac,ac$offset(x.offset+nrow(df)-1,
                             ncol(df)-1))
    r$columns()$autofit()
  }
  if(!missing(setname) && is.character(setname)){
    r<-ws$range(ac,ac$offset(x.offset+nrow(df)-1,
                             ncol(df)-1))
    addr<-paste("=",r$address(external=T),sep="")
    ws$parent()$names()$add(Name=setname, refersto=addr)
  }
  NULL
}
col.format<-function(col){
  col<- if(inherits(col,"POSIXt")||inherits(col,"Date"))
    format(col,"%Y-%m-%d %H:%M")
  else{
    if(is.factor(col)) paste("'",col,sep="") else col
  }
  ind<-is.na(col)
  col<-as.list(col)
  col[ind]<-""
  structure(col,dim=c(length(col),1))
}
getHWND<-function(){
  hwnd<-getWindowsHandle()
  if(is.integer(hwnd)) return(hwnd)
  if(typeof(hwnd)=="externalptr")
    return(as.integer(gsub("^<[^0-9]+|>$","",deparse(hwnd))))
  if(is.null(hwnd)) {
    warning("WindowsHandle is NULL")
    return(0)
  }
  win.stop("HWND hiba. Lehetséges R verzió gond?")
}
