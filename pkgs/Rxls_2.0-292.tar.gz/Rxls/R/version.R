Rxlsdir<-"Rxls"

`%subset%`<-function(x,y) length(setdiff(x,y))==0

get.versions<-function(wd,version="0.0-0",recalc.md5sum=FALSE){
  require(tools)
  ver.file<-file.path(wd,"versions")
  if(file.exists(ver.file)){
    ver<-try(read.dcf(ver.file))
    if((!inherits(ver,"try-error")) &&
       (c("file","version") %subset% colnames(ver))){
      if((!("md5sum"%in%colnames(ver))) || recalc.md5sum){
        ver<-ver[,grep("md5sum",colnames(ver),invert=T),
                 drop=FALSE]
        ver<-cbind(ver,
                   md5sum=md5sum(file.path(wd,ver[,"file"])))
      }
      ## csak a letezo fileokrol kellene infot adni!!
      ver<-cbind(ver,fullpath=file.path(wd,ver[,"file"]))
      return(ver)
    }
  }
  ## csak excel fileok .xl.. es a backup fileok nelkul
  ## unix *~, windows ~$*
  files<-dir(wd,full.names=FALSE,pattern="^[^~].*\\.xl.*[^~]$")
  cbind(file=files,
        fullpath=file.path(wd,files),
        version=version,
        md5sum=md5sum(file.path(wd,files)))
}

oldEXCELfiles<-function(srcdir=system.file("EXCEL",package=.packageName),
                        instdir=file.path(Sys.getenv("appdata"),Rxlsdir)){
  src.ver<-data.frame(get.versions(srcdir),stringsAsFactors=FALSE)
  inst.ver<-data.frame(get.versions(instdir,recalc=TRUE),
                       stringsAsFactors=FALSE)
  ind<-match(src.ver$file,inst.ver$file)
  src.ver$old[is.na(ind)]<-TRUE
  if(any(!is.na(ind))){
    src.ver$old <- with(inst.ver[ind,,drop=FALSE],
                        {
                          src.vernums<-package_version(src.ver$version,FALSE)
                          vernums<-package_version(version,FALSE)
                          src.vernums>vernums | src.ver$md5sum != md5sum
                        })
  }
  src.ver$old[is.na(src.ver$old)]<-TRUE
  return(src.ver)
  ## src.ver$old[is.na(src.ver$old)]<-TRUE
  ##
  ## ver<-merge(src.ver,inst.ver,by="file",suffixes=c(".src",".inst"),
  ##  stringsAsFactors=FALSE)
  ## ver$old <- package_version(ver$version.src,F)>
  ## package_version(ver$version.inst,F) | ver$md5sum.src!=ver$md5sum.inst
  ## ver$old[is.na(ver$old)]<-TRUE
  ## ver
}
write.versions<-function(ver,dir){
  write.dcf(ver[,c("file","version","md5sum"),drop=FALSE],
            file=file.path(dir,"versions"))
}
#$
installRxls<-function(){
  srcdir<- system.file("EXCEL",package=.packageName)
  instdir<-file.path(Sys.getenv("appdata"),Rxlsdir)
  if (!file.exists(instdir)){
    message(instdir, " könyvtár létrehozása.")
    if(!dir.create(instdir))
      stop(instdir, " könyvtár létrehozása sikertelen.")
  }
  of<-oldEXCELfiles(srcdir=srcdir,instdir=instdir)
  if(!any(of$old)){
    message("Nincs frissítendő file.")
    return()
  }
  message("Frissítendő fileok: ",
          paste(of$file[of$old],collapse=", "))
  of$copied<-FALSE
  of$copied[of$old]<-with(of[of$old,],
                          file.copy(file.path(srcdir,file),
                                    file.path(instdir,file),
                                    overwrite=TRUE))
  write.versions(of[of$copied | of$old,],instdir)
  if(any(of$old & !of$copied)){
    message(paste(of$file[of$old & !of$copied],collapse=", "),
            " másolása nem sikerült!")
  }else{
    message("A frissítés sikerült!")
  }
}
RxlsFiles<-function(){
  dir(system.path("EXCEL",package=.packageName),full.name=FALSE)
}
create.versions<-function(wd,ver.info=character(0)){
  require(tools)
  files<-dir(wd,full.names=FALSE,pattern="^[^~].*\\.xl.*[^~]$")
  ver<-cbind(file=files,version=NA,md5sum=md5sum(file.path(wd,files)))
  rownames(ver)<-ver[,"file"]
  ind<-names(ver.info) %in% rownames(ver)
  ver[names(ver.info)[ind],"version"]<-ver.info[ind]
  ver
}
installRxls<-function(){
  instdir<-file.path(Sys.getenv("appdata"),Rxlsdir)
  if (!file.exists(instdir)){
    message(instdir, " könyvtár létrehozása.")
    if(!dir.create(instdir))
      stop(instdir, " könyvtár létrehozása sikertelen.")
  }
  instfile<-file.path(instdir,"versions")
  ver.inst<-if(file.exists(instfile)) read.dcf0(instfile) else list()
  srcdir<- system.file("EXCEL",package=.packageName)
  ver.src<-read.dcf0(file.path(srcdir,"versions"))
  v.ok<-chk.prop("version",src=ver.src,inst=ver.inst)
  m.ok<-chk.prop("md5sum",src=ver.src,inst=ver.inst)
  msg<-""
  if(!all(v.ok & m.ok)){
    ver.info<-character(0)
    ver.info[names(ver.inst)]<-unlist(lapply(ver.inst,
                                             "[","version"))
    src.m.ok<-ver.src[m.ok]
    ver.info[names(src.m.ok)]<-unlist(lapply(src.m.ok,
                                             "[","version"))
    if(any(!m.ok)){
      msg<-paste("Másolandó fileok:",
                 paste(names(ver.src[!m.ok]),collapse=", "))
      message(msg)
      copied<-sapply(names(ver.src)[!m.ok],
                     function(file)
                     file.copy(file.path(srcdir,file),
                               file.path(instdir,file),
                               overwrite=TRUE))
      if(!all(copied)){
        msg<-paste("Néhány file másolása sikertelen:",
                   paste((names(ver.src)[!m.ok])[!copied],
                         collapse=", "))
        message(msg)
      }else{
        message("A másolás sikeresen megtörtént.")
      }
      copied.f<-(ver.src[!m.ok])[copied]
      ver.info[names(copied.f)]<-unlist(lapply(copied.f,
                                               "[","version"))
    }
    message("Verzió információ frissítése...",appendLF=FALSE)
    if(!inherits(try(write.dcf(create.versions(instdir,ver.info),
                               file=instfile)),"try-error"))
      message("ok")
  }
}
#$
