## foreach<-function(obj,fun){
## ered<-list()
## for(i in seq_len(obj[["count"]])){
##    nn<-obj[[item,i]][["name"]]
##    if(is.null(nn)) nn<-i
##    ered[[nn]]<-fun(obj[["item",i]])
##  }
##  ered
## }
names.COMObject<-function(x)
  unlist(lapply(seq_len(x[["count"]]),
                function(i) x[["item",i]][["name"]]))
