================================================================================
Excel Samples
================================================================================

Will show how to use Microsoft Excel from R (R as a COM server)

get_current_excel_selection.R	queries current Excel instance for selection
new_excel.R			creates new Excel window and writes/reads data
