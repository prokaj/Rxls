load.data<-function(file,fields=".+"){
  ind    <- regexpr("\\.[[:alnum:]]*$",file,T)
  ext    <- if(ind>0) substring(file,ind+1) else ""
  fields <- paste(fields,sep="|")
  x<-switch(ext,
            "mdb"=load.mdb(file,fields),
            "csv"=load.csv(file,fields),
            stop("Hibás filenév\n\t%s
Az adatállomány csak 'mdb' vagy 'csv' lehet!",file)
            )
x
}
load.mdb<-function(file,table,fields){
    if(!require(RODBC)) stop("Az RODBC csomag nincs telepítve")
    con<-odbcConnectAccess(file)
    on.exit(close(con))
    tables<-grep(table,sqlTables(con)$TABLE_NAME,value=T)
    if(length(tables)==0 || 
       (length (tables)>1 && is.na(tables<-tables[match(table,tables)]))) 
        my.stop("Hibás tábla név.\n Nem egyértelmű, vagy hiányzó tábla")
    fields<-grep(fields,sqlColumns(con,table)$Column_name,value=T)
    sqlQuery(con,sprintf("SELECT %s\nFROM %s;",paste(fields,collapse=","),table))
    x<-sqlGetResults(con)
    attr(x,"call")<-getPar0()
    x       
}

load.csv<-function(file,fields){
   x<-read.table(file,sep=";",header=TRUE,dec=",")
   x<-x[grep(fields,names(x))]
   attr(x,"call")<-getPar0()
   x
}

month<-function(x){     
  if(length(x)==0) return(numeric(0))
  if(inherits(x,"Date")||inherits(x,"POSIXt")) x<-format(x,"%Y.%m")
  if(is.numeric(x))      return(x)
  if(is.character(x))    x<-as.factor(x)
  if(is.factor(x))
    unlist(lapply(strsplit(levels(x),"\\.|/"),
                  function(z)
                  as.integer(z[1])*12+as.integer(z[2])))[unclass(x)]
}

Table2fun<-function(table,factors=NULL,values=NULL){  
  for(i in factors) table[i]<-as.factor(table[[i]])
  levs<-lapply(table[factors],levels)
  mapping<-array(0,dim=unlist(lapply(levs,length)),dimnames=levs)
  mapping[do.call(cbind,table[factors])]<-seq_along(table[[1]])
  if(is.integer(factors))
    factors<-names(table)[factors]
  FUN <- function(adat)
    table[mapping[do.call(cbind,
                          lapply(factors,
                                 function(fac)
                                 match(levels(adat[[fac]]),
                                       levs[[fac]])[unclass(adat[[fac]])]))],
          values]
  FUN
}

my.stop<-function(...){
  winDialog(type="ok",substr(sprintf(...),1,255))
  stop(call.=FALSE)
}
## mar nem kell
my.stop<-stop
translate.col<-function(df,
                        dict=load.data("ett.csv"),
                        new.col="CSOPORT",orig.col="MODOZAT_KOD",
                        from.col="GL_PROD_CODE",to.col="DAP",.factor=T){
  df[new.col]<-dict[match(df[[orig.col]],dict[[from.col]]),to.col]
  if(.factor)
    df[new.col]<-as.factor(df[[new.col]])
  df
}
my.aggregate<- function (x, by, FUN, ...){
  if(nrow(x)==0)
    data.frame(x,by)
  else
    aggregate(x,by,FUN,...)
}

getPar<-function(par,
                 env=parent.frame(2),
                 call=sys.call(sys.parent())){
    do.call(substitute,list(call[[par]],env=as.list(env)))
}

getPar0<-function(call=sys.call(sys.parent()),env=parent.frame()){
    for(x in names(call))
        if(x!="") try(call[[x]]<-get(x,env),silent=TRUE)
    call
}
