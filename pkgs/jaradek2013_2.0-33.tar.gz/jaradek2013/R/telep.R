install.jaradek<-function() 
  install.xls(filelist=c("Ellenor.xls","Kalkulator.xls"),
              PACKAGE="jaradek2013")
