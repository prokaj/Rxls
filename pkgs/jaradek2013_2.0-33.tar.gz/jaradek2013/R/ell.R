XLell <- function(jaradek, fuggo, ett, besorolas,
                  halandosag, hozamok, novelesek, UTALKTSG, 
                  report=stdout(), tartido=NULL, .ell=TRUE){
  calc<- function(jaradek,...){
      attr.call<-attr(jaradek,"call")
      jaradek<-{
          if(.ell) ell(jaradek,...) else CF(jaradek,...)
      }
      attr(jaradek,"call")<-attr.call
      jaradek
  }
  
  message("Járadékos adatok beolvasása ...");  force(jaradek)
  message("ETT adatok olvasása ...");  force(ett)
  
  pb<-progress("Előkészítés: %s")
  pb$step("Hozam és növelési ráták ...")
  ratak <- merge(hozamok,novelesek,by=1)
  if(is.numeric(ratak[[1]]))
  ratak[[1]] <- format(as.Date("1900-01-01")+ratak[[1]]-2,"%Y.%m.%d")
  ratak <- prep.df(ratak)
  
  pb$step("Halandóság ...");  halandosag <- prep.df(halandosag)
  
  pb$step("Besorolás ...")             
  names(besorolas) <- toupper(names(besorolas))
  besorolas$HALANDOSAG <- factor(as.character(besorolas$HALANDOSAG),
                                 levels=colnames(halandosag))
  besorolas$HOZAM <- factor(as.character(besorolas$HOZAM),
                            levels=colnames(ratak))
  besorolas$NOVEKEDES <- factor(as.character(besorolas$NOVEKEDES),
                                levels=colnames(ratak))
  tf<-Table2fun(besorolas,1:5,6:8)  
  pb$rm()
  if(nrow(jaradek)+nrow(fuggo)>0){
      ## XLell szamolas
      pb <- progress("Számolás: %s","")
      pb$step(sprintf("Tőkésített (%d db)",nrow(jaradek)))

      jaradek$IND<-interaction(jaradek$JARAZ,jaradek$TARTIDO,drop=TRUE)

      jaradek <- calc(jaradek=translate.col(jaradek,ett),besorolas.fun=tf,halandosag,ratak,UTALKTSG,JARAZ="IND",
                                                         idopontok=tartido)


      pb$step(sprintf("Függő (%d db)", nrow(fuggo)))
      fuggo$IND<-interaction(fuggo$KARAKTASZAM,fuggo$TARTIDO,drop=TRUE)

      fuggo<-calc(jaradek=translate.col(fuggo,ett),besorolas.fun=tf,halandosag,ratak,UTALKTSG,JARAZ="IND",
                                                   idopontok=tartido,
                  KF.matrix.formula=matrix(c(K1+F1+J1,K2+F2+J1,K3N+F3N+J2N),ncol=3))

      pb$rm();
      ## XLell szamolas vege

      ## XLell riport generalas
        message("Riport generálás")
      if(.ell){
          ## riport genaralas
          rep<-initReport(report)

          rep$newpage("Riport (tőkésített)")
          rep$param("ETT file",attr(ett,"call"))
          rep$rep(jaradek,forras=attr(jaradek,"call"))

          rep$newpage("Riport (függő)")
          rep$rep(fuggo,forras=attr(fuggo,"call"))

          rep$newpage("Tőkésített járadékok")
          rep$df(df=jaradek)
          rep$newpage("Függő járadékok")
          rep$df(df=fuggo)
          rep$close();
          ## riport genaralas vege
      }
      else{
          ## CF tablak genaralasa
          rep<-initReport(report)

          rep$newpage("Paraméterek")
          rep$param("ETT file",attr(ett,"call"))
          rep$param("Tőkésített",attr(jaradek,"call"))
          rep$param("Függő",attr(fuggo,"call"))

          rep$newpage("Tartalék adat")
          x<-merge(jaradek$VSUM,unique(ett[grep("^(GL_|BIT|DAP)",names(ett))]),
                     by.x="MÓDOZAT_KÓD",by.y=1,all.x=TRUE,all.y=FALSE)
          y<-merge(fuggo$VSUM,unique(ett[grep("^(GL_|BIT|DAP)",names(ett))]),
                   by.x="MÓDOZAT_KÓD",by.y=1,all.x=TRUE,all.y=FALSE)
          lapply(c("DAP","BIT","GL_VEZER"),function(vp){
            byx<-grep(paste("^",vp,sep=""),names(x),value=TRUE)
            x <- my.aggregate(x[c("VJC","CNT","FJC")],by=x[byx],sum)
            x$V_MEAN <-x$VJC/x$CNT
            y <- my.aggregate(y[c("VJC","CNT")],by=y[byx],sum)
            y$V_MEAN <-y$VJC/y$CNT
            rep$df(df=merge(x,y,by=byx,all=T,
                     suffixes=c("[Tőkésített]","[Függő]")))
            rep$writeLn("")
          })

          rep$newpage("CF adat")
          CF.tokes<-data.frame("DÁTUM"=unique(unlist(lapply(jaradek$CF,names))))
          for(MOD in names(jaradek$CF)){
            CF.tokes[[MOD]]<-NA
            CF.tokes[match(names(jaradek$CF[[MOD]]),
                           CF.tokes$"DÁTUM"),MOD] <- jaradek$CF[[MOD]]
          }
          CF.tokes$SZUMMA<-rowSums(as.matrix(CF.tokes[names(jaradek$CF)]),
                                   na.rm=TRUE)
          ind <- setdiff(seq_along(names(CF.tokes)),match("DÁTUM",names(CF.tokes)))
          names(CF.tokes)[ind] <- paste(names(CF.tokes)[ind],"[Tőkés]",sep="")

          CF.fuggo<-data.frame("DÁTUM"=unique(unlist(lapply(fuggo$CF,names))))
          for(MOD in names(fuggo$CF)){
            CF.fuggo[[MOD]]<-NA
            CF.fuggo[match(names(fuggo$CF[[MOD]]),
                           CF.fuggo$"DÁTUM"),MOD] <- fuggo$CF[[MOD]]
          }
          CF.fuggo$SZUMMA<-rowSums(as.matrix(CF.fuggo[names(fuggo$CF)]),
                                   na.rm=TRUE)
          ind <- setdiff(seq_along(names(CF.fuggo)),match("DÁTUM",names(CF.fuggo)))
          names(CF.fuggo)[ind] <- paste(names(CF.fuggo)[ind],"[Függő]",sep="")

          CF<-merge(CF.tokes,CF.fuggo,by="DÁTUM",all=T,
                    suffixes=c("[Tőkés]","[Függő]"))
          CF$SZUMMA<-rowSums(CF[c("SZUMMA[Tőkés]","SZUMMA[Függő]")],na.rm=T)
          eleje<-c("DÁTUM",sort(grep("^SZUMMA",names(CF),value=TRUE)))
          rep$df(df=CF[c(eleje,setdiff(names(CF),eleje))])

          rep$newpage("Előrejelzés (adat)")
          x<-jaradek$PREDICT
          pr<-x[[1]];x[1]<-NULL
          while(length(x)>0){
            pr<-merge(pr,x[[1]],all=T)
            x[1]<-NULL
          }
          x<-fuggo$PREDICT
          while(length(x)>0){
            x[[1]]$FJC<-x[[1]]$VJC
            x[[1]]$VJC<-0
            pr<-merge(pr,x[[1]],all=T)
            x[1]<-NULL
          }
          pr<-merge(pr,unique(ett[grep("^(GL_|BIT|DAP)",names(ett))]),
                    by.x="MÓDOZAT_KÓD",by.y=1,all.x=TRUE,all.y=FALSE)
          rep$df(df=pr,NAME="DATA")

          rep$newpage("Előrejelzés (pivot)")
          rep$pivot(datasource="DATA",
                    rows="BIT",cols="DÁTUM",
                    pages=c("MÓDOZAT_KÓD"),
                    data=list(src=c("VJC","FJC","KIFIZETÉS"),
                        caption=c("JÁRADÉK TART","FÜGGŐ TART","KUMMULÁLT KIF.")))

          rep$close();
          ## CF tablak genaralas vege
      }
      invisible(list(jaradek,fuggo));
      ## XLell riport generalas vege
    }else
  stop("A járadékos és függőkár adatbázisban nics egyetlen szerződés sem!!!")
}
ell<-function (jaradek, besorolas.fun,halandosag,
               ratak,UTALKTSG,
               JARAZ="JARAZ",
               KF.matrix.formula=matrix(c(K1+F1,K2+F2,K3N+F3N),ncol=3),
               idopontok=NULL){
  pb<-progress(" [%s]")
  on.exit(pb$rm(),add=TRUE)
  pb$step("index készítése")
    for(coln in intersect(c("JAROSSZ","PRUDMO","BIZTOSSZ","BIZTOSSZ_KAROSULT",
                            "K1","K2","K3N","F1","F2","F3N",
                            "J1","J2N","FUGGOKARRESZ","FUGGOKAROSSZ",
                            "VIJC1","ZN","VIJC2","VKJC1","VKJC2","VJC","FJC"),
                          names(jaradek)))
    jaradek[[coln]]<-as.numeric(jaradek[[coln]])

  jaradek$ONYF_FOLY <- as.factor(jaradek$ONYF_FOLY)
  jaradek$NY13      <- as.factor(jaradek$NY13)
  bes               <- besorolas.fun(jaradek)
  jaradek[names(bes)] <- bes

  hibas<-with(jaradek,is.na(GYAKORISAG)|is.na(UTALKEZDHO)|
              is.na(PRUDMO)|is.na(HALANDOSAG))
  if(any(hibas))
    attr(jaradek,"hibasak")<-jaradek[hibas,]
  jaradek<-jaradek[!hibas,]
  jaradek$KEZD_MONTH <- month(jaradek$UTALKEZDHO)
  omega_0 <- rep(1440,length(levels(jaradek$HALANDOSAG)))

  jaradek$VEGE_MONTH <- with(jaradek,
                             pmin(month(KIFVEGDAT)+PRUDMO,
                                  month(SZULDAT)+omega_0[HALANDOSAG]))

  t <- match(month(jaradek$TARTIDO),month(rownames(ratak)))
  gc(); 
  ho_ind <- mapply(seq,jaradek$KEZD_MONTH,
                   jaradek$VEGE_MONTH,jaradek$GYAKORISAG,SIMPLIFY=FALSE)

  jarindlevs<-seq_along(rownames(jaradek))
  jarind <- factor(rep.int(jarindlevs,
                           as.integer(unlist(lapply(ho_ind,length)))),
                   levels=jarindlevs)

  ho_ind <- as.integer(unlist(ho_ind))
  korind <- ho_ind-month(jaradek$SZULDAT)[jarind]
  ho_ind <- match(ho_ind,month(rownames(ratak)))
  gc()
  p_k  <- halandosag[cbind(korind,jaradek$HALANDOSAG[jarind])] /(halandosag[cbind(month(jaradek$TARTIDO)-month(jaradek$SZULDAT),
                     jaradek$HALANDOSAG)][jarind]);
  e_lt <- ((jaradek$JAROSSZ/(ratak[cbind(t,jaradek$NOVEKEDES)]))[jarind])*(ratak[cbind(ho_ind,jaradek$NOVEKEDES[jarind])])
  ##mult_seq <- halandosag[cbind(korind,jaradek$HALANDOSAG[jarind])]  * ratak[cbind(ho_ind,jaradek$HOZAM[jarind])] * ratak[cbind(ho_ind,jaradek$NOVEKEDES[jarind])];
  pb$step("V_I,jc,1 számítása")
  jaradek$VIJC2.ELL <- jaradek$VIJC1.ELL <- unlist(lapply(split.default(ratak[cbind(ho_ind,jaradek$HOZAM[jarind])]*e_lt*p_k,jarind),sum))/ratak[cbind(t,jaradek$HOZAM)] ;
  pb$step("Z(n) számítása")
  
  jaradek$ZN.ELL  <- Zn  <- {
                              KF.matrix <- eval(substitute(KF.matrix.formula),jaradek)
                              Zncalc<-function(){
                                jar.subset <- (1:nrow(jaradek))[jaradek$BIZTOSSZ_JELL>0]
                                ind.subset <- seq_along(jarind)[jarind%in%jar.subset]

                                jarind <- jarind[ind.subset]; korind<-korind[ind.subset]

                                ord <- order(jaradek[[JARAZ]][jarind],korind)
                                jarind <- jarind[ord]; korind <- korind[ord]; 
                                ind.subset <- ind.subset[ord]

                                ho_ind <- ho_ind[ind.subset]; e_lt<-e_lt[ind.subset];
                                ind <- match(unique(jaradek[[JARAZ]][jar.subset]),jaradek[[JARAZ]]);
                                
                                treshold <- jaradek$BIZTOSSZ[ind]-
                                  KF.matrix[cbind(ind,jaradek$BIZTOSSZ_JELL[ind])];
                                
                                jarazonind <- factor(jaradek[[JARAZ]][jarind],
                                                     levels=unique(jaradek[[JARAZ]][jar.subset]));
                                
                                e_ltcumsum <- lapply(split.default(e_lt,jarazonind),cumsum);
                                
                                Zn <- rep(1440,nrow(jaradek));
                                
                                Zn[jar.subset] <- 
                                  mapply(function(x,y,z)
                                         c(z,1440)[findInterval(y,x,
                                                                rightmost.closed=TRUE)+1], 
                                         e_ltcumsum,treshold,
                                         split.default(korind,jarazonind),
                                         SIMPLIFY=TRUE)[match(jaradek[[JARAZ]][jar.subset],
                                           levels(jarazonind))];
                                Zn
                              };
                              Zncalc()
                            }; 
  
  pb$step("V_I,jc,2 számítása")
  jaradek$VIJC2.ELL <- { 
                         p_k <- p_k * (korind <= Zn[jarind]);
                         unlist(lapply(split.default(ratak[cbind(ho_ind,jaradek$HOZAM[jarind])]*e_lt*p_k,jarind),sum))/ratak[cbind(t,jaradek$HOZAM)];
                       };
  pb$step("V_K,jc,1 számítása")
  jaradek$VKJC1.ELL <-VKJC1<- UTALKTSG*unlist(lapply(split.default(p_k,jarind),sum));
  pb$step("V_K,jc,2 számítása")  
  jaradek$VKJC2.ELL <- rep(0,nrow(jaradek)); 
  ind <- {
           ord<-order(-1*round(VKJC1),jaradek$JOGCIM,decreasing=FALSE)
           unlist(lapply(split((1:nrow(jaradek))[ord],jaradek[[JARAZ]][ord]),"[",1))
         };
  ind<-ind[!is.na(ind)]
  jaradek$VKJC2.ELL[ind] <- jaradek$VKJC1.ELL[ind] 
  invisible(jaradek); 
}
CF<-function(jaradek, besorolas.fun,halandosag,
             ratak,UTALKTSG,
             JARAZ="JARAZ",
             KF.matrix.formula=matrix(c(K1+F1,K2+F2,K3N+F3N),ncol=3),
             idopontok=NULL){
  pb<-progress(" [%s]")
  on.exit(pb$rm(),add=TRUE)
  pb$step("index készítése")
    for(coln in intersect(c("JAROSSZ","PRUDMO","BIZTOSSZ","BIZTOSSZ_KAROSULT",
                            "K1","K2","K3N","F1","F2","F3N",
                            "J1","J2N","FUGGOKARRESZ","FUGGOKAROSSZ",
                            "VIJC1","ZN","VIJC2","VKJC1","VKJC2","VJC","FJC"),
                          names(jaradek)))
    jaradek[[coln]]<-as.numeric(jaradek[[coln]])

  jaradek$ONYF_FOLY <- as.factor(jaradek$ONYF_FOLY)
  jaradek$NY13      <- as.factor(jaradek$NY13)
  bes               <- besorolas.fun(jaradek)
  jaradek[names(bes)] <- bes

  hibas<-with(jaradek,is.na(GYAKORISAG)|is.na(UTALKEZDHO)|
              is.na(PRUDMO)|is.na(HALANDOSAG))
  if(any(hibas))
    attr(jaradek,"hibasak")<-jaradek[hibas,]
  jaradek<-jaradek[!hibas,]
  jaradek$KEZD_MONTH <- month(jaradek$UTALKEZDHO)
  omega_0 <- rep(1440,length(levels(jaradek$HALANDOSAG)))

  jaradek$VEGE_MONTH <- with(jaradek,
                             pmin(month(KIFVEGDAT)+PRUDMO,
                                  month(SZULDAT)+omega_0[HALANDOSAG]))

  t <- match(month(jaradek$TARTIDO),month(rownames(ratak)))
  gc(); 
  ho_ind <- mapply(seq,jaradek$KEZD_MONTH,
                   jaradek$VEGE_MONTH,jaradek$GYAKORISAG,SIMPLIFY=FALSE)

  jarindlevs<-seq_along(rownames(jaradek))
  jarind <- factor(rep.int(jarindlevs,
                           as.integer(unlist(lapply(ho_ind,length)))),
                   levels=jarindlevs)

  ho_ind <- as.integer(unlist(ho_ind))
  korind <- ho_ind-month(jaradek$SZULDAT)[jarind]
  ho_ind <- match(ho_ind,month(rownames(ratak)))
  gc()
  p_k  <- halandosag[cbind(korind,jaradek$HALANDOSAG[jarind])] /(halandosag[cbind(month(jaradek$TARTIDO)-month(jaradek$SZULDAT),
                     jaradek$HALANDOSAG)][jarind]);
  e_lt <- ((jaradek$JAROSSZ/(ratak[cbind(t,jaradek$NOVEKEDES)]))[jarind])*(ratak[cbind(ho_ind,jaradek$NOVEKEDES[jarind])])
  ##mult_seq <- halandosag[cbind(korind,jaradek$HALANDOSAG[jarind])]  * ratak[cbind(ho_ind,jaradek$HOZAM[jarind])] * ratak[cbind(ho_ind,jaradek$NOVEKEDES[jarind])];

  pb$step("Z(n) számítása")
  jaradek$ZN.ELL <- Zn    <- {
                               KF.matrix <- eval(substitute(KF.matrix.formula),jaradek)
                               Zncalc<-function(){
                                 jar.subset <- (1:nrow(jaradek))[jaradek$BIZTOSSZ_JELL>0]
                                 ind.subset <- seq_along(jarind)[jarind%in%jar.subset]

                                 jarind <- jarind[ind.subset]; korind<-korind[ind.subset]

                                 ord <- order(jaradek[[JARAZ]][jarind],korind)
                                 jarind <- jarind[ord]; korind <- korind[ord]; 
                                 ind.subset <- ind.subset[ord]

                                 ho_ind <- ho_ind[ind.subset]; e_lt<-e_lt[ind.subset];
                                 ind <- match(unique(jaradek[[JARAZ]][jar.subset]),jaradek[[JARAZ]]);
                                 
                                 treshold <- jaradek$BIZTOSSZ[ind]-
                                   KF.matrix[cbind(ind,jaradek$BIZTOSSZ_JELL[ind])];
                                 
                                 jarazonind <- factor(jaradek[[JARAZ]][jarind],
                                                      levels=unique(jaradek[[JARAZ]][jar.subset]));
                                 
                                 e_ltcumsum <- lapply(split.default(e_lt,jarazonind),cumsum);
                                 
                                 Zn <- rep(1440,nrow(jaradek));
                                 
                                 Zn[jar.subset] <- 
                                   mapply(function(x,y,z)
                                          c(z,1440)[findInterval(y,x,
                                                                 rightmost.closed=TRUE)+1], 
                                          e_ltcumsum,treshold,
                                          split.default(korind,jarazonind),
                                          SIMPLIFY=TRUE)[match(jaradek[[JARAZ]][jar.subset],
                                            levels(jarazonind))];
                                 Zn
                               };
                               Zncalc()
                             }; 

  pb$step("V_I,jc,2 számítása")
  jaradek$VIJC2 <- { 
                     p_k <- p_k * (korind <= Zn[jarind]);
                     unlist(lapply(split.default(ratak[cbind(ho_ind,jaradek$HOZAM[jarind])]*e_lt*p_k,jarind),sum))/ratak[cbind(t,jaradek$HOZAM)];
                   };
  pb$step("V_K,jc,1 számítása")
  VKJC1 <- UTALKTSG*unlist(lapply(split.default(p_k,jarind),sum));
  pb$step("V_K,jc,2 számítása")  
  jaradek$VKJC2 <- rep(0,nrow(jaradek)); 
  ind <- {
           ord<-order(-1*round(VKJC1),jaradek$JOGCIM,decreasing=FALSE)
           unlist(lapply(split((1:nrow(jaradek))[ord],jaradek[[JARAZ]][ord]),"[",1))
         };
  ind <- ind[!is.na(ind)]
  jaradek$VKJC2[ind] <- VKJC1[ind]

  pb$step("Tartalék összesítés")
  mod  <- as.factor(jaradek$MODOZAT_KOD)
  Vsum <- {
            SVJC <- unlist(lapply(split.default(with(jaradek,VIJC2+VKJC2),mod),sum))
            njar <- unlist(lapply(lapply(split.default(jaradek[[JARAZ]],mod),unique),
                                  length))
            Find <- with(jaradek,(VEGE_MONTH-month(SZULDAT)) <= ZN.ELL)
            SFJC <- jaradek$FUGGOKAROSSZ[Find] +
              jaradek$VIJC2[Find]*jaradek$FUGGOKARRESZ[Find]
            SFJC <- unlist(lapply(split.default(SFJC,mod[Find]),sum))
            data.frame("MÓDOZAT_KÓD"=levels(mod),VJC=as.numeric(SVJC),
                       CNT=as.numeric(njar),FJC=as.numeric(SFJC))
          };

  pb$step("CF számolás")
  SCF <- mapply(function(x,y){
           ered<-unlist(lapply(split.default(x,rownames(ratak)[y]),
                               sum))
           ered[ered!=0]
         },
                split.default(p_k*e_lt,mod[jarind]),
                split.default(ho_ind,mod[jarind]),
                SIMPLIFY=FALSE);
  
  pb$step("Tartalék előrejelzés")
  honapok <- match(month(idopontok),month(rownames(ratak)))
  szorzo  <- jaradek$JAROSSZ[jarind]*ratak[cbind(ho_ind,jaradek$NOVEKEDES[jarind])]*ratak[cbind(ho_ind,jaradek$HOZAM[jarind])]*p_k
  pb1 <- progress("/%s/");
  Vpredict<-function(t,s){
    pb1$step(format(s,"%Y.%m.%d"))
    ind<-(ho_ind<=t)

    if(any(ind))
      KIF<- unlist(lapply(split(p_k[ind]*e_lt[ind],mod[jarind[ind]]),sum))
    else KIF<-rep(0,length(levels(mod)))

    ind<-(ho_ind > t)
    if(any(ind)){
      ho_ind <- ho_ind[ind]; jarind <- jarind[ind]; 
      szorzo <- szorzo[ind]; p_k <- p_k[ind]
      V2 <- unlist(lapply(split.default(szorzo,jarind),sum)) / 
        (ratak[cbind(t,jaradek$NOVEKEDES)]*ratak[cbind(t,jaradek$HOZAM)])
      VKJC1 <- UTALKTSG*unlist(lapply(split.default(p_k,jarind),sum));
      ind   <- {
                 ord<-order(-1*round(VKJC1),jaradek$JOGCIM,decreasing=FALSE)
                 unlist(lapply(split((1:nrow(jaradek))[ord],jaradek[[JARAZ]][ord]),"[",1))
               }; 
      ind   <- ind[!is.na(ind)]
      VK    <- unlist(lapply(split.default(VKJC1[ind],mod[ind]),sum))
      ##match(names(VK),jaradek[[JARAZ]])]),sum))
      if(any(Find)){
        SFJC <- jaradek$FUGGOKAROSSZ[Find]+V2[Find]*jaradek$FUGGOKARRESZ[Find]
        SFJC <- unlist(lapply(split.default(SFJC,mod[Find]),sum))
        V2   <- unlist(lapply(split.default(V2,mod),sum))
      }
      else SFJC <- rep(0,length(levels(mod)))
    }else{
      V2 <- VK <- SFJC <- rep(0,length(levels(mod)))
    }
    data.frame("MÓDOZAT_KÓD"=levels(mod),VJC=V2+VK,FJC=SFJC,
               "KIFIZETÉS"=KIF,"DÁTUM"=rep (s,length(levels(mod))));
  }
  Vpred <- mapply(Vpredict,honapok,idopontok,SIMPLIFY=FALSE)
  names(Vpred)<- format(idopontok,"%Y.%m.%d")
  pb1$rm()
  list(PREDICT=Vpred,CF=SCF,VSUM=Vsum)
}
prep.df <- function(df){
  rn<-df[[1]]
  df[[1]]<-NULL
  rownames(df)<-rn
  df
}
get.reptype<-function(fn){
    if(grepl("[/\\\\]+$",fn)) return("CONSOLE")
    if(grepl("\\.txt$",fn,ignore.case=TRUE)) return("TXT")
    if(identical(file.info(fn)$isdir,TRUE)) return("CONSOLE")
    return("EXCEL")
}

initReport<-function(filenev,reportTitle="Riport"){
    switch(get.reptype(filenev),
           TEXT={
               if(ext==""){
                 f<-stdout()
                 repEnd<-function()cat("\n")
               }
               else{
                 f<-file(filenev,"w")
                 repEnd<-function(){cat("\n");close(f)}
               }
               pivot<-function(...){
                 wirteLn("-----")
                 writeLn("Pivot tábla: ",...)
                 writeLn("-----")
               }
               writeLn<-function(...) cat(...,"\n",file=f,sep="\t")
               newpage<-writeLn
               writeDF<-function(df,with.names=TRUE,...) {
                 cat("----------------------------------\n",file=f)
                 write.table(df,file=f,row.names=FALSE,col.names=with.names,sep="\t")
                 cat("----------------------------------\n",file=f)
               };
           },
           EXCEL={
               WBS<-THISXL[["workbooks"]]
               WB<-WBS$add()
               WS<-WB[["sheets",1]]
               WS[["name"]]<-"__NOT USED__"
               WSS<-WB[["sheets"]]
               da<-THISXL[["application"]][["displayalerts"]]
               THISXL[["application"]][["displayalerts"]]<-FALSE
               while((n<-WSS[["count"]])>1)
                 WSS[["item",n]]$delete()
               THISXL[["application"]][["displayalerts"]]<-da
               CELL<-WS[["range","$A$1"]]
               WSS<-NULL; WBS<-NULL;WS<-NULL
               repEnd<-function(){
                 WB$SaveAs(filenev)
                 WB<-NULL
                 CELL<-NULL
                 gc()
               ##  WB$close(TRUE)
               } 
               writeLn<-function(...){
                 items<-list(...)
                 CELL1<-CELL; 
                 on.exit({CELL<<-CELL1[["offset",1,0]];CELL1<-NULL;})
                 for(item in items){
                   CELL[["value"]]<-item
                   CELL<-CELL[["offset",0,1]]
                 }
               }
               
               newpage<-function(nev){
                   on.exit(WS<-NULL)
                   if(WB[["sheets",1]][["name"]]=="__NOT USED__")
                       WS<-WB[["sheets",1]]
                   else{
                       WS<<-WB$sheets()$add()
                   }
                   WS[["name"]]<-nev
                   CELL<<-WS[["range","$A$1"]]
               }
               writeDF<-function(df,.decor=FALSE,NAME=NULL,...){
                   XLwritedf(XLrange=CELL,df=df,setname=NAME,...)
                   if(.decor){
                       turnOn<-XLScreenUpdateTurnOff(CELL[["worksheet"]][["application"]])
                       r<-CELL[["worksheet"]][["range",
                                               CELL[["offset",1,0]],
                                               CELL[["offset",nrow(df),0]]]]
                       elln<-names(df)
                       while(length(elln)>1){
                         if(paste(elln[1],".ELL",sep="")==elln[2]){
                           r[["FormatConditions"]]$delete()
                           pos <- 1; r[["numberformat"]]<-"# ##0"
                                     rr<-r[["cells",1,1]]
                                     rr[["select"]]
                                     fm1<-paste("=1+",rr[["offset",0,pos]][["address",F]],sep="")
                                     r[["FormatConditions"]]$add(1,7,fm1)
                                     r[["FormatConditions",1]][["interior"]][["Colorindex"]]<-40
                                     fm1<-paste("=",rr[["offset",0,pos]][["address",F]],"-1",sep="")
                                     r[["FormatConditions"]]$add(1,8,fm1)
                                     r[["FormatConditions",2]][["interior"]][["Colorindex"]]<-37
                                     rr<-NULL;
                           r<-r[["offset",0,1]]
                           pos <- -1; r[["numberformat"]]<-"# ##0"
                                      rr<-r[["cells",1,1]]
                                      rr[["select"]]
                                      fm1<-paste("=1+",rr[["offset",0,pos]][["address",F]],sep="")
                                      r[["FormatConditions"]]$add(1,7,fm1)
                                      r[["FormatConditions",1]][["interior"]][["Colorindex"]]<-40
                                      fm1<-paste("=",rr[["offset",0,pos]][["address",F]],"-1",sep="")
                                      r[["FormatConditions"]]$add(1,8,fm1)
                                      r[["FormatConditions",2]][["interior"]][["Colorindex"]]<-37
                                      rr<-NULL;
                           elln<-elln[2:length(elln)]
                         }
                         elln<-elln[2:length(elln)]
                         r<-r[["offset",0,1]]
                       }
                       r<-NULL
                       turnOn();
                   }
                   turnOn<-XLScreenUpdateTurnOff(CELL[["worksheet"]][["application"]])
                   r<-CELL[["worksheet"]][["range",
                                           CELL,CELL[["offset",0,ncol(df)-1]]]]
                   f<-r[["Font"]]; f[["Bold"]]<-TRUE; f<-NULL
                   racsozas(r); r<-NULL
                   r<-CELL[["worksheet"]][["range",
                                           CELL[["offset",1,0]],
                                           CELL[["offset",nrow(df),ncol(df)-1]] ]]
                   racsozas(r); r<-NULL
                   r<-CELL[["worksheet"]][["range",
                                           CELL,
                                           CELL[["offset",nrow(df),ncol(df)-1]]]]
                   r[["columns"]]$Autofit(); r<-NULL;
                   turnOn();
                   ## if(!missing(NAME)){
                   ##     r<-CELL[["worksheet"]][["range",CELL,
                   ##                             CELL[["offset",nrow(df),ncol(df)-1]]]]
                   ##     r$select()
                   ##     ns<-CELL[["application"]][["activeworkbook"]][["names"]]
                   ##     ns$add(Name=NAME,RefersTo=paste("=",r[["address"]],sep=""))
                   ##     r<-NULL; ns<-NULL
                   ## }
                   CELL<<-CELL[["offset",nrow(df)+1,0]]
               }
               racsozas<-function(r){
                 r[["Borders",5]][["LineStyle"]] <- as.integer(-4142)
                 r[["Borders",6]][["LineStyle"]] <- as.integer(-4142)
                 for(i in 7:10){
                   r[["Borders",i]][["LineStyle"]] <- as.integer(1)
                   r[["Borders",i]][["Weight"]]    <- as.integer(-4138)
                 }
                 for(i in 11:12){
                   r[["Borders",i]][["LineStyle"]] <- as.integer(1)
                   r[["Borders",i]][["Weight"]]    <- as.integer(2)
                 }
                 r<-NULL
               }

               pivot<-function(datasource,rows=NULL,cols=NULL,pages=NULL,
                               data=list(src=NULL,caption=NULL),
                               NumberFormat=
                               "_-* # ##0 Ft_-;-* # ##0 Ft_-;_-* \"-\" Ft_-;_-@_-",
                               datacol=34,
                               col=36){
                 CELL<-CELL[["offset",3,0]]
                 CELL$select()
                 xlDatabase <- 1; 
                 wb<-CELL[["application"]][["activeworkbook"]]
                 pc<-wb$PivotCaches()
                 pc<-pc$add("SourceType"=xlDatabase,
                            "SourceData"=paste("=",datasource,sep=""))
                 pt<-pc$CreatePivotTable("TableDestination"=CELL)
                 pc<-NULL
                 xlDataField <-4; xlColumnField = 2;xlPageField <- 3;xlRowField = 1
                 setfield<-function(pt,xlor,fn){
                   for(i in seq_along(fn)){
                     pf<-pt$pivotfields(fn[i])
                     pf[["Orientation"]]<- xlor
                     pf[["position"]]<-i
                     pf<-NULL
                   }
                 }
                 pt[["ColumnGrand"]]<-FALSE
                 pt[["RowGrand"]]<-FALSE

                 setfield(pt,xlRowField,rows);
                 setfield(pt,xlColumnField,cols);
                 setfield(pt,xlPageField,pages);
                 setfield(pt,xlDataField,data$src);
                 setcolor<-function(pt,fname,col,nf=NULL,caption=NULL){
                   pfs<-pt[[fname]]
                   cnt<-pfs[["count"]]
                   if(cnt>0)
                   for(i in 1:cnt){
                     pf<-pfs[["item",i]]
                     if(!(is.null(caption[i])||is.na(caption[i]))) 
                       pf[["caption"]]<-caption[i]
                     if(!is.null(nf)) pf[["numberformat"]]<- nf
                     inter<-pf[["datarange"]][["interior"]]
                     inter[["colorindex"]]<-col
                     inter<-NULL
                     pf<-NULL
                   }
                   pfs <- NULL
                 }
                 setcolor(pt,"rowfields",col)
                 setcolor(pt,"columnfields",col)
                 setcolor(pt,"pagefields",col)
                 setcolor(pt,"datafields",datacol,nf=NumberFormat,caption=data$caption)
                 pt<-NULL
                 wb[["ShowPivotTableFieldList"]]<-FALSE;  wb<-NULL

                 pt<-CELL[["Application"]][["CommandBars","PivotTable"]]
                 pt[["Visible"]]<-FALSE;  pt<-NULL
               }
               ##pivot(datasource="predict",rows="BIT",cols="DÁTUM",data=list(src="VJC",caption="TART"))
;
           },
           CONSOLE={
               repEnd<-function()cat("\n")
               pivot<-function(...){
                 wirteLn("-----")
                 writeLn("Pivot tábla: ",...)
                 writeLn("-----")
               }
               writeLn<-function(...) cat(...,"\n",sep="\t")
               newpage<-writeLn
               writeDF<-function(df,with.names=TRUE,...) {
                 cat("----------------------------------\n")
                 str(df)
                 cat("----------------------------------\n")
               };
           })
  repWrite<-function(rem,arg){
    writeLn(paste(rem,":",sep=""))
    names(arg)[1]<-"function"
    lapply(names(arg),function(x)
           writeLn("",paste(x,":",sep=""),as.character(arg[x]))) 
  }
  mkrep<-function(df,forras){
    repWrite("Ellenőrzött állomány",forras)
    if(is.null(hibas<-attr(df,"hibasak")))
      writeLn("Hiányzó adat miatt hibás record nem volt.")
    else{
      writeLn(paste("Hiányzó adat miatt hibás rekordok száma:",nrow(hibas)))
      writeDF(df=hibas)
      writeLn("")
    }
    e<-elteresek(df)
    if (nrow(e)==0)
      writeLn(
      "A teljes rekordokon nincs eltérés a rendszer által számolt értékekhez képest")
      else{
        writeLn(
        paste("Az eltérések száma a rendszer által számított értékekhez képest:",
              nrow(e)))
        elln<-grep("\\.ELL$",names(e),value=TRUE) 
        elln<-sort(intersect(c(elln,sub("\\.ELL$","",elln)),names(e)))
        writeDF(df=e[c(elln,setdiff(names(e),elln))],.decor=TRUE)
        writeLn("")
      }
  };
  writeLn("Létrehozás időpontja:")
  writeLn("",format(Sys.time(),"%Y.%m.%d %H:%M:%S %z"))
  
  list("close"=repEnd,"param"=repWrite,
       "newpage"=newpage,"df"=writeDF,
       "rep"=mkrep,"writeLn"=writeLn,"pivot"=pivot)
}
elteresek<-function(jaradek){
  ind<-with(jaradek,abs(VIJC1-VIJC1.ELL)>=1 | abs(VIJC2-VIJC2.ELL)>=1 | 
            ZN !=ZN.ELL | abs(VKJC1-VKJC1.ELL)>=1 |abs(VKJC2-VKJC2.ELL)>=1)
  ind<-is.na(ind) | ind
  jaradek[ind,,drop=FALSE]       
}
