# 
#  RCOM : COM Client and Server for R
#  Copyright (C) 2003-2008 Thomas Baier, Erich Neuwirth
# 
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
# 
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
# 
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# 
#  $Id: create.R 1.2 2003/04/27 16:38:37 baier Exp baier $
#

comCreateObject<-function(progid)
  .Call("com_create",as.character(progid),PACKAGE="com")

comGetObject<-function(progid)
  .Call("com_getobject",as.character(progid),PACKAGE="com")

comInvoke<-function(handle,method,...)
  .Call("com_invoke",handle,as.character(method),list(...),PACKAGE="com")

comIsValidHandle<-function(handle)
  .Call("com_isvalid",handle,PACKAGE="com")

comSetProperty <- function(handle,property,...)
  .Call("com_property_set",handle,as.character(property),
        list(...),PACKAGE="com")

comGetProperty<-function(handle,property,...) 
   .Call("com_property_get",handle,as.character(property),
         list(...),PACKAGE="com")

comTraceObject<-function(handle) 
  .Call("com_object_trace",handle,PACKAGE="com");

comGetObjectInfo<-function(handle)
  .Call("com_object_getinfo",handle,PACKAGE="com");

comRegisterServer<-function() .Call("registerServer",PACKAGE="com")
comUnregisterServer<-function() .Call("unregisterServer",PACKAGE="com")
comRegisterRegistry<-function(){
    tlbpath<-system.file("binary",c("rcom_srv.tlb","StatconnLib.tlb"),
                         package="com")
    tlbpath<-normalizePath(tlbpath,mustWork=TRUE)
    .Call("registerServerInRegistry",tlbpath,PACKAGE="com")
}

comUnregisterRegistry<-function()
  .Call("unregisterServerInRegistry",PACKAGE="com")
comTrace<-function(x) .Call("com_trace",x,PACKAGE="com")
comGetVersion<-function() .Call("com_version_get",PACKAGE="com")
comThis<-function() .Call("com_this",PACKAGE="com")
comGetPicture<-function() .Call("com_get_picture",PACKAGE="com")

## pv 2013-06-05
comCheckRegistry<-function(){
    require(utils)
    if(!exists("readRegistry",mode="function"))
        stop("'readRegistry' function of 'utils' package is missing")

    key<-"CLSID\\{3660C348-DF59-4CA2-83E8-3A913A9FBC77}"

    if (inherits(try(readRegistry(key,"HCR",maxdepth=1)[[1]],silent=TRUE),
                 "try-error")){
        message("Please, register the COM server of R.\n",
                "Start 'R' as root and call'comRegisterRegistry()'")
        return(FALSE)
    }
    key<-"TypeLib\\{38008F95-0BBF-43FD-A884-2DE4B3939429}\\1.0\\0\\win32"
    path<-try(readRegistry(key,"HCR")[[1]],silent=TRUE)
    if (inherits(path,"try-error")){
        key<-paste("Wow6432Node",key,sep="\\")
        ##\\TypeLib\\{38008F95-0BBF-43FD-A884-2DE4B3939429}\\1.0\\0\\win32"
        path<-try(readRegistry(key,"HCR")[[1]],silent=TRUE)
        if(inherits(path,"try-error")){
            message("Please, register the COM server of R.\n",
                    "Start 'R' as root and call'comRegisterRegistry()'")
            return(FALSE)
        }
    }
    
    comtlb<-system.file("binary","rcom_srv.tlb",package="com")
    comtlb<-normalizePath(comtlb)
    path<-normalizePath(path)
    if(!identical(path,comtlb)){
        message("The COM server of 'R' is not registered properly.\n",
                "\tregistry : '",path,"'\n",
                "\ttlb path : '",comtlb,"'\n",
                "Call 'comRegisterRegistry()' as 'root'")
        return(FALSE)
    }
    TRUE
    ## there should be a check that in the registry the path for RCOM 1.0 tlb  points to the right directory.  
}


##HKEY_CLASSES_ROOT\TypeLib\{38008F95-0BBF-43FD-A884-2DE4B3939429}\1.0\0\win32
##HKEY_CLASSES_ROOT\Wow6432Node\TypeLib\{38008F95-0BBF-43FD-A884-2DE4B3939429}\1.0\0\win32
##HKEY_LOCAL_MACHINE\SOFTWARE\Classes\TypeLib\{38008F95-0BBF-43FD-A884-2DE4B3939429}\1.0\0\win32
