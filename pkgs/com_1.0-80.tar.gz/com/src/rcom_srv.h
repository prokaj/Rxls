/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sat Jun 26 18:33:34 2004
 */
/* Compiler settings for rcom_srv.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __rcom_srv_h__
#define __rcom_srv_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IStatConnector_FWD_DEFINED__
#define __IStatConnector_FWD_DEFINED__
typedef interface IStatConnector IStatConnector;
#endif 	/* __IStatConnector_FWD_DEFINED__ */


#ifndef __InternalConnector_FWD_DEFINED__
#define __InternalConnector_FWD_DEFINED__

#ifdef __cplusplus
typedef class InternalConnector InternalConnector;
#else
typedef struct InternalConnector InternalConnector;
#endif /* __cplusplus */

#endif 	/* __InternalConnector_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"
#include "statconn.h"

//javitas PV.
#ifndef __MIDL_user_allocate_free_DEFINED__
#define __MIDL_user_allocate_free_DEFINED__
  void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
  void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 
#endif


/* interface __MIDL_itf_rcom_srv_0000 */
/* [local] */ 

typedef /* [public][public][public][public] */ 
enum __MIDL___MIDL_itf_rcom_srv_0000_0001
    {	itName	= 0,
	itDescription	= itName + 1,
	itCopyright	= itDescription + 1,
	itLicense	= itCopyright + 1,
	itMinorVersion	= itLicense + 1,
	itMajorVersion	= itMinorVersion + 1
    }	InformationType;



extern RPC_IF_HANDLE __MIDL_itf_rcom_srv_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_rcom_srv_0000_v0_0_s_ifspec;

#ifndef __IStatConnector_INTERFACE_DEFINED__
#define __IStatConnector_INTERFACE_DEFINED__

/* interface IStatConnector */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IStatConnector;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("18c8b660-81a2-11d3-9254-00e09812f727")
    IStatConnector : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Init( 
            /* [in] */ BSTR bstrConnectorName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Close( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetSupportedTypes( 
            /* [out] */ LONG __RPC_FAR *pulTypeMask) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetSymbol( 
            /* [in] */ BSTR bstrSymbolName,
            /* [retval][out] */ VARIANT __RPC_FAR *pvData) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetSymbol( 
            /* [in] */ BSTR bstrSymbolName,
            /* [in] */ VARIANT vData) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Evaluate( 
            /* [in] */ BSTR bstrExpression,
            /* [retval][out] */ VARIANT __RPC_FAR *pvData) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE EvaluateNoReturn( 
            /* [in] */ BSTR bstrExpression) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetErrorId( 
            /* [retval][out] */ LONG __RPC_FAR *pulErrorId) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetErrorText( 
            /* [retval][out] */ BSTR __RPC_FAR *pbstrErrorText) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AddGraphicsDevice( 
            /* [in] */ BSTR bstrName,
            /* [in] */ ISGFX __RPC_FAR *pDevice) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RemoveGraphicsDevice( 
            /* [in] */ BSTR bstrName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetUserInterfaceAgent( 
            /* [in] */ IStatConnectorUIAgent __RPC_FAR *pUIAgent) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetCharacterOutputDevice( 
            /* [in] */ IStatConnectorCharacterDevice __RPC_FAR *pCharDevice) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetErrorDevice( 
            /* [in] */ IStatConnectorCharacterDevice __RPC_FAR *pCharDevice) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetTracingDevice( 
            /* [in] */ IStatConnectorCharacterDevice __RPC_FAR *pCharDevice) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetServerInformation( 
            /* [in] */ InformationType lInformationType,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrInfo) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetConnectorInformation( 
            /* [in] */ InformationType lInformationType,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrInfo) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetInterpreterInformation( 
            /* [in] */ InformationType lInformationType,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrInfo) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IStatConnectorVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IStatConnector __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IStatConnector __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IStatConnector __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Init )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ BSTR bstrConnectorName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Close )( 
            IStatConnector __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetSupportedTypes )( 
            IStatConnector __RPC_FAR * This,
            /* [out] */ LONG __RPC_FAR *pulTypeMask);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetSymbol )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ BSTR bstrSymbolName,
            /* [retval][out] */ VARIANT __RPC_FAR *pvData);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetSymbol )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ BSTR bstrSymbolName,
            /* [in] */ VARIANT vData);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Evaluate )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ BSTR bstrExpression,
            /* [retval][out] */ VARIANT __RPC_FAR *pvData);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *EvaluateNoReturn )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ BSTR bstrExpression);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetErrorId )( 
            IStatConnector __RPC_FAR * This,
            /* [retval][out] */ LONG __RPC_FAR *pulErrorId);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetErrorText )( 
            IStatConnector __RPC_FAR * This,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrErrorText);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *AddGraphicsDevice )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ BSTR bstrName,
            /* [in] */ ISGFX __RPC_FAR *pDevice);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RemoveGraphicsDevice )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ BSTR bstrName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetUserInterfaceAgent )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ IStatConnectorUIAgent __RPC_FAR *pUIAgent);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetCharacterOutputDevice )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ IStatConnectorCharacterDevice __RPC_FAR *pCharDevice);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetErrorDevice )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ IStatConnectorCharacterDevice __RPC_FAR *pCharDevice);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetTracingDevice )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ IStatConnectorCharacterDevice __RPC_FAR *pCharDevice);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetServerInformation )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ InformationType lInformationType,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrInfo);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetConnectorInformation )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ InformationType lInformationType,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrInfo);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetInterpreterInformation )( 
            IStatConnector __RPC_FAR * This,
            /* [in] */ InformationType lInformationType,
            /* [retval][out] */ BSTR __RPC_FAR *pbstrInfo);
        
        END_INTERFACE
    } IStatConnectorVtbl;

    interface IStatConnector
    {
        CONST_VTBL struct IStatConnectorVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStatConnector_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStatConnector_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStatConnector_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStatConnector_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IStatConnector_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IStatConnector_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IStatConnector_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IStatConnector_Init(This,bstrConnectorName)	\
    (This)->lpVtbl -> Init(This,bstrConnectorName)

#define IStatConnector_Close(This)	\
    (This)->lpVtbl -> Close(This)

#define IStatConnector_GetSupportedTypes(This,pulTypeMask)	\
    (This)->lpVtbl -> GetSupportedTypes(This,pulTypeMask)

#define IStatConnector_GetSymbol(This,bstrSymbolName,pvData)	\
    (This)->lpVtbl -> GetSymbol(This,bstrSymbolName,pvData)

#define IStatConnector_SetSymbol(This,bstrSymbolName,vData)	\
    (This)->lpVtbl -> SetSymbol(This,bstrSymbolName,vData)

#define IStatConnector_Evaluate(This,bstrExpression,pvData)	\
    (This)->lpVtbl -> Evaluate(This,bstrExpression,pvData)

#define IStatConnector_EvaluateNoReturn(This,bstrExpression)	\
    (This)->lpVtbl -> EvaluateNoReturn(This,bstrExpression)

#define IStatConnector_GetErrorId(This,pulErrorId)	\
    (This)->lpVtbl -> GetErrorId(This,pulErrorId)

#define IStatConnector_GetErrorText(This,pbstrErrorText)	\
    (This)->lpVtbl -> GetErrorText(This,pbstrErrorText)

#define IStatConnector_AddGraphicsDevice(This,bstrName,pDevice)	\
    (This)->lpVtbl -> AddGraphicsDevice(This,bstrName,pDevice)

#define IStatConnector_RemoveGraphicsDevice(This,bstrName)	\
    (This)->lpVtbl -> RemoveGraphicsDevice(This,bstrName)

#define IStatConnector_SetUserInterfaceAgent(This,pUIAgent)	\
    (This)->lpVtbl -> SetUserInterfaceAgent(This,pUIAgent)

#define IStatConnector_SetCharacterOutputDevice(This,pCharDevice)	\
    (This)->lpVtbl -> SetCharacterOutputDevice(This,pCharDevice)

#define IStatConnector_SetErrorDevice(This,pCharDevice)	\
    (This)->lpVtbl -> SetErrorDevice(This,pCharDevice)

#define IStatConnector_SetTracingDevice(This,pCharDevice)	\
    (This)->lpVtbl -> SetTracingDevice(This,pCharDevice)

#define IStatConnector_GetServerInformation(This,lInformationType,pbstrInfo)	\
    (This)->lpVtbl -> GetServerInformation(This,lInformationType,pbstrInfo)

#define IStatConnector_GetConnectorInformation(This,lInformationType,pbstrInfo)	\
    (This)->lpVtbl -> GetConnectorInformation(This,lInformationType,pbstrInfo)

#define IStatConnector_GetInterpreterInformation(This,lInformationType,pbstrInfo)	\
    (This)->lpVtbl -> GetInterpreterInformation(This,lInformationType,pbstrInfo)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_Init_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ BSTR bstrConnectorName);


void __RPC_STUB IStatConnector_Init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_Close_Proxy( 
    IStatConnector __RPC_FAR * This);


void __RPC_STUB IStatConnector_Close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_GetSupportedTypes_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [out] */ LONG __RPC_FAR *pulTypeMask);


void __RPC_STUB IStatConnector_GetSupportedTypes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_GetSymbol_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ BSTR bstrSymbolName,
    /* [retval][out] */ VARIANT __RPC_FAR *pvData);


void __RPC_STUB IStatConnector_GetSymbol_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_SetSymbol_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ BSTR bstrSymbolName,
    /* [in] */ VARIANT vData);


void __RPC_STUB IStatConnector_SetSymbol_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_Evaluate_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ BSTR bstrExpression,
    /* [retval][out] */ VARIANT __RPC_FAR *pvData);


void __RPC_STUB IStatConnector_Evaluate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_EvaluateNoReturn_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ BSTR bstrExpression);


void __RPC_STUB IStatConnector_EvaluateNoReturn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_GetErrorId_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [retval][out] */ LONG __RPC_FAR *pulErrorId);


void __RPC_STUB IStatConnector_GetErrorId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_GetErrorText_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrErrorText);


void __RPC_STUB IStatConnector_GetErrorText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_AddGraphicsDevice_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ BSTR bstrName,
    /* [in] */ ISGFX __RPC_FAR *pDevice);


void __RPC_STUB IStatConnector_AddGraphicsDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_RemoveGraphicsDevice_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ BSTR bstrName);


void __RPC_STUB IStatConnector_RemoveGraphicsDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_SetUserInterfaceAgent_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ IStatConnectorUIAgent __RPC_FAR *pUIAgent);


void __RPC_STUB IStatConnector_SetUserInterfaceAgent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_SetCharacterOutputDevice_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ IStatConnectorCharacterDevice __RPC_FAR *pCharDevice);


void __RPC_STUB IStatConnector_SetCharacterOutputDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_SetErrorDevice_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ IStatConnectorCharacterDevice __RPC_FAR *pCharDevice);


void __RPC_STUB IStatConnector_SetErrorDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_SetTracingDevice_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ IStatConnectorCharacterDevice __RPC_FAR *pCharDevice);


void __RPC_STUB IStatConnector_SetTracingDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_GetServerInformation_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ InformationType lInformationType,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrInfo);


void __RPC_STUB IStatConnector_GetServerInformation_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_GetConnectorInformation_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ InformationType lInformationType,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrInfo);


void __RPC_STUB IStatConnector_GetConnectorInformation_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnector_GetInterpreterInformation_Proxy( 
    IStatConnector __RPC_FAR * This,
    /* [in] */ InformationType lInformationType,
    /* [retval][out] */ BSTR __RPC_FAR *pbstrInfo);


void __RPC_STUB IStatConnector_GetInterpreterInformation_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IStatConnector_INTERFACE_DEFINED__ */



#ifndef __RCOMServerLib_LIBRARY_DEFINED__
#define __RCOMServerLib_LIBRARY_DEFINED__

/* library RCOMServerLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_RCOMServerLib;

EXTERN_C const CLSID CLSID_InternalConnector;

#ifdef __cplusplus

class DECLSPEC_UUID("3660c348-df59-4ca2-83e8-3a913a9fbc77")
InternalConnector;
#endif
#endif /* __RCOMServerLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
