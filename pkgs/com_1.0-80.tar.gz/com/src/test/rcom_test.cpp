/*******************************************************************************
 *  rcom_text: Test program for R (D)COM server and rcom
 *  Copyright (C) 2005 Thomas Baier
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  ---------------------------------------------------------------------------
 *
 *  $Id: rproxy.c,v 1.14 2003/09/13 15:14:09 murdoch Exp $
 *
 ******************************************************************************/

typedef enum {
  xlErrDiv0 = 2007,
  xlErrNA = 2042,
  xlErrName = 2029,
  xlErrNull = 2000,
  xlErrNum = 2036,
  xlErrRef = 2023,
  xlErrValue = 2015
} XlCVError;

#include <windows.h>
#include "rcom_srv.h"
#include <stdio.h>

#define NDEBUG 1

/* tracing */
#ifdef USE_PROXYTRACE
#  include "rproxy.h"
#  define LOG RPROXY_ERR
#  ifdef NDEBUG
#    define TRACE(x)
#  else
#    define TRACE RPROXY_TRACE
#  endif
#  define ERR RPROXY_ERR
#else
#  define LOG(x) x
#  ifdef NDEBUG
#    define TRACE(x)
#  else
#    define TRACE(x) x
#  endif
#  define ERR(x) x
#endif

/* rproxy.dll also exports ANSI2BSTR: duplicate this code if necessary */
#ifdef USE_RPROXYTRACE
#  include "bdx_com.h"
#else
OLECHAR* com_getOLECHAR(char const* str)
{
  int chars;
  OLECHAR* _str;

  chars = MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,str,-1,NULL,0);
  if (chars == 0) {
    return NULL;
  }
  _str = (OLECHAR*) calloc(chars,sizeof (OLECHAR));
  chars = MultiByteToWideChar(CP_ACP,MB_PRECOMPOSED,str,-1,_str,chars);
  return _str;
}
BSTR ANSI2BSTR(char const* str)
{
  OLECHAR* _str = com_getOLECHAR (str);
  BSTR bstr = SysAllocString (_str);
  free (_str);
  return bstr;
}
#endif

/* various GUIDs */
const IID IID_IStatConnector =
  {0x18c8b660,0x81a2,0x11d3,{0x92,0x54,0x00,0xe0,0x98,0x12,0xf7,0x27}};
const CLSID CLSID_InternalConnector =
  {0x3660c348,0xdf59,0x4ca2,{0x83,0xe8,0x3a,0x91,0x3a,0x9f,0xbc,0x77}};

#define INIT_STRING "R"
#define SYMBOL_NAME "testsym"
#define SYMBOL_NAME2 "testsym"
#define SYMBOL_ASSIGN "testsym2<-testsym"
#define EVAL_STRING "testsym<-25"
#define ERR_SYMBOL_NAME "0testsym"
#define ERR_SYMBOL_EMPTY ""
#define ERR_EVAL_STRING "0testsym<-25"
#define ERR_SYMBOL_NOTEXIST "testsym3"
#define ERR_EVAL_NOTEXIST "testfunc()"
#define VT_I2_VAL 257
#define VT_I4_VAL 65537
#define VT_UI1_VAL 255
#define VT_BOOL_VAL VARIANT_TRUE
#define VT_R4_VAL 3.1415
#define VT_R8_VAL 2.7182818
#define VT_BSTR_VAL ANSI2BSTR("a_string")

/* globals */
static char** g_argv;
static int g_argc;


/*@CLASS*********************************************************************/
/** Wrapper for StatConnector using either IDispatch or IStatConnector.
*
* description
*
* @see 
* @version 1.0
*//***************************************************************************
** 05-05-15 | baier | CREATED
*****************************************************************************/
class Connector
{
  //--------------------------------------------------------------------------
  public:
  //--------------------------------------------------------------------------

  //----------------------------------------------------------------------
  // constructor/destructor
  //----------------------------------------------------------------------
  Connector() {}
  virtual ~Connector() {}

  virtual bool Init(char const* pStr) = 0;
  virtual bool Close() = 0;

  virtual bool EvaluateNoReturn(char const* pCmd,bool pExpectErr = false) = 0;
  virtual bool Evaluate(char const* pCmd,VARIANT* pResult,
			bool pExpectErr = false) = 0;

  virtual bool SetSymbol(char const* pSymbol,VARIANT pVal,
			 bool pExpectErr = false) = 0;
  virtual bool GetSymbol(char const* pSymbol,VARIANT* pVal,
			 bool pExpectErr = false) = 0;

  virtual bool isValid() const = 0;

  //--------------------------------------------------------------------------
  protected:
  //--------------------------------------------------------------------------

  //--------------------------------------------------------------------------
  private:
  //--------------------------------------------------------------------------

  //----------------------------------------------------------------------
  // private assignment operator/copy constructor
  //----------------------------------------------------------------------
  Connector(Connector const&);
  Connector& operator=(Connector const&);
};


/*@CLASS*********************************************************************/
/** wrapper for StatConnector using IStatConnector interface.
*
* description
*
* @see 
* @version 1.0
*//***************************************************************************
** 05-05-15 | baier | CREATED
*****************************************************************************/
class CustomConnector
: public Connector
{
  //--------------------------------------------------------------------------
  public:
  //--------------------------------------------------------------------------

  //----------------------------------------------------------------------
  // constructor/destructor
  //----------------------------------------------------------------------
  CustomConnector(CLSID pClsID)
  {
    HRESULT lRc;
    void* lTmp;

    /* create the COM object */
    lRc = CoCreateInstance(pClsID,
			   NULL,
			   CLSCTX_ALL,
			   IID_IStatConnector,
			   &lTmp);
    m_Connector = (IStatConnector*) lTmp;
    if(FAILED(lRc)) {
      m_Connector = 0;
      ERR(printf("%s: failed to create object (rc=%08lx)\n",
		 __PRETTY_FUNCTION__,lRc));
      return;
    }
    TRACE(printf("%s: successfully created object\n",__PRETTY_FUNCTION__));
  }
  virtual ~CustomConnector()
  {
    if(!isValid()) {
      return;
    }

    /* release the COM object */
    ULONG lCount = m_Connector->Release();

    if(lCount != 0) {
      ERR(printf("%s: released object, reference count is %lu (should be 0)\n",
		 __PRETTY_FUNCTION__,lCount));
    }
  }
  
  virtual bool isValid() const
  {
    if(m_Connector) {
      return true;
    }
    return false;
  }

  virtual bool Init(char const* pStr)
  {
    if(!isValid()) {
      return false;
    }

    BSTR lInitString = ANSI2BSTR(pStr);
    HRESULT lRc = m_Connector->Init(lInitString);
    SysFreeString(lInitString);
    if(FAILED(lRc)) {
      ERR(printf("%s: failed to initialize object (rc=%08lx)\n",
		 __PRETTY_FUNCTION__,lRc));
      return false;
    } else {
      TRACE(printf("%s: successfully initialized object (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,lRc));
    }
    return true;
  }
  virtual bool Close()
  {
    if(!isValid()) {
      return false;
    }

    HRESULT lRc = m_Connector->Close();
    if(FAILED(lRc)) {
      ERR(printf("%s: failed to shut down object (rc=%08lx)\n",
		 __PRETTY_FUNCTION__,lRc));
      return false;
    } else {
      TRACE(printf("%s: successfully shut down object (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,lRc));
    }
    
    return true;
  }

  virtual bool EvaluateNoReturn(char const* pCmd,bool pExpectErr = false)
  {
    if(!isValid()) {
      return false;
    }

    BSTR lCmd = ANSI2BSTR(pCmd);
    HRESULT lRc = m_Connector->EvaluateNoReturn(lCmd);
    SysFreeString(lCmd);
    if(FAILED(lRc)) {
      if(!pExpectErr) {
	ERR(printf("%s: failed to evaluate (no return) expression \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pCmd,lRc));
      }
      return false;
    } else {
      TRACE(printf("%s: successfully evaluated (no return) expression \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pCmd,lRc));
    }
    return true;
  }
  virtual bool Evaluate(char const* pCmd,VARIANT* pResult,
			bool pExpectErr = false)
  {
    if(!isValid()) {
      return false;
    }

    BSTR lCmd = ANSI2BSTR(pCmd);
    HRESULT lRc = m_Connector->Evaluate(lCmd,pResult);
    SysFreeString(lCmd);
    if(FAILED(lRc)) {
      if(!pExpectErr) {
	ERR(printf("%s: failed to evaluate expression \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pCmd,lRc));
      }
      return false;
    } else {
      TRACE(printf("%s: successfully evaluated expression \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pCmd,lRc));
    }
    return true;
  }

  virtual bool SetSymbol(char const* pSymbol,VARIANT pVal,
			 bool pExpectErr = false)
  {
    if(!isValid()) {
      return false;
    }

    BSTR lSymbol = ANSI2BSTR(pSymbol);
    HRESULT lRc = m_Connector->SetSymbol(lSymbol,pVal);
    SysFreeString(lSymbol);
    if(FAILED(lRc)) {
      if(!pExpectErr) {
	ERR(printf("%s: failed to set symbol \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pSymbol,lRc));
      }
      return false;
    } else {
      TRACE(printf("%s: successfully set symbol \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pSymbol,lRc));
    }
    return true;
  }
  virtual bool GetSymbol(char const* pSymbol,VARIANT* pVal,
			 bool pExpectErr = false)
  {
    if(!isValid()) {
      return false;
    }

    BSTR lSymbol = ANSI2BSTR(pSymbol);
    HRESULT lRc = m_Connector->GetSymbol(lSymbol,pVal);
    SysFreeString(lSymbol);
    if(FAILED(lRc)) {
      if(!pExpectErr) {
	ERR(printf("%s: failed to get symbol \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pSymbol,lRc));
      }
      return false;
    } else {
      TRACE(printf("%s: successfully got symbol \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pSymbol,lRc));
    }
    return true;
  }

  //--------------------------------------------------------------------------
  protected:
  //--------------------------------------------------------------------------

  //--------------------------------------------------------------------------
  private:
  //--------------------------------------------------------------------------

  //----------------------------------------------------------------------
  // private assignment operator/copy constructor
  //----------------------------------------------------------------------
  CustomConnector(CustomConnector const&);
  CustomConnector& operator=(CustomConnector const&);

  IStatConnector* m_Connector;
};


/*@CLASS*********************************************************************/
/** wrapper for StatConnector using IDispatch interface.
*
* description
*
* @see 
* @version 1.0
*//***************************************************************************
** 05-05-15 | baier | CREATED
*****************************************************************************/
class DispatchConnector
: public Connector
{
  //--------------------------------------------------------------------------
  public:
  //--------------------------------------------------------------------------

  //----------------------------------------------------------------------
  // constructor/destructor
  //----------------------------------------------------------------------
  DispatchConnector(CLSID pClsID)
  {
    HRESULT lRc;
    void* lTmp;

    /* create the COM object */
    lRc = CoCreateInstance(pClsID,
			   NULL,
			   CLSCTX_ALL,
			   IID_IDispatch,
			   &lTmp);
    m_Connector = (IDispatch*) lTmp;
    if(FAILED(lRc)) {
      m_Connector = 0;
      ERR(printf("%s: failed to create object (rc=%08lx)\n",
		 __PRETTY_FUNCTION__,lRc));
      return;
    }

    /* get the disp IDs */
    OLECHAR* lNames[max_disp+1] = {
      ANSI2BSTR("Init"),
      ANSI2BSTR("Close"),
      ANSI2BSTR("GetSymbol"),
      ANSI2BSTR("SetSymbol"),
      ANSI2BSTR("Evaluate"),
      ANSI2BSTR("EvaluateNoReturn")
    };
    int i;
    bool lFailed = false;
    for(i = 0;i < max_disp + 1;i++) {
      lRc = m_Connector->GetIDsOfNames(IID_NULL,&(lNames[i]),
				       1,LOCALE_USER_DEFAULT,
				       &m_DispIDs[i]);
      free(lNames[i]);
      if(FAILED(lRc)) {
	ERR(printf("%s: failed to retrieve DISPIDs (rc=%08lx, index %d)\n",
		   __PRETTY_FUNCTION__,lRc,i));
	lFailed = true;
      }
    }

    if(lFailed) {
      m_Connector->Release();
      m_Connector = 0;
      return;
    }
  }
  virtual ~DispatchConnector()
  {
    if(!isValid()) {
      return;
    }

    /* release the COM object */
    ULONG lCount = m_Connector->Release();

    if(lCount != 0) {
      ERR(printf("%s: released object, reference count is %lu (should be 0)\n",
		 __PRETTY_FUNCTION__,lCount));
    }
  }

  virtual bool isValid() const
  {
    if(m_Connector) {
      return true;
    }
    return false;
  }

  virtual bool Init(char const* pStr)
  {
    if(!isValid()) {
      return false;
    }

    BSTR lInitString = ANSI2BSTR(pStr);

    // prepare DISPPARAMS and call Invoke
    VARIANTARG lArgument;
    VariantInit(&lArgument);
    V_VT(&lArgument) = VT_BSTR;
    V_BSTR(&lArgument) = lInitString;
    DISPPARAMS lParams = { &lArgument,NULL,1,0 };
    HRESULT lRc = m_Connector->Invoke(m_DispIDs[disp_Init],
				      IID_NULL,
				      LOCALE_USER_DEFAULT,
				      DISPATCH_METHOD,
				      &lParams,
				      NULL,
				      NULL,
				      NULL);
    VariantClear(&lArgument); // also frees string
    if(FAILED(lRc)) {
      ERR(printf("%s: failed to initialize object (rc=%08lx)\n",
		 __PRETTY_FUNCTION__,lRc));
      return false;
    } else {
      TRACE(printf("%s: successfully initialized object (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,lRc));
    }
    return true;
  }
  virtual bool Close()
  {
    if(!isValid()) {
      return false;
    }

    // prepare DISPPARAMS and call Invoke
    DISPPARAMS lParams = { NULL,NULL,0,0 };
    HRESULT lRc = m_Connector->Invoke(m_DispIDs[disp_Close],
				      IID_NULL,
				      LOCALE_USER_DEFAULT,
				      DISPATCH_METHOD,
				      &lParams,
				      NULL,
				      NULL,
				      NULL);
    if(FAILED(lRc)) {
      ERR(printf("%s: failed to shut down object (rc=%08lx)\n",
		 __PRETTY_FUNCTION__,lRc));
      return false;
    } else {
      TRACE(printf("%s: successfully shut down object (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,lRc));
    }
    
    return true;
  }

  virtual bool EvaluateNoReturn(char const* pCmd,bool pExpectErr = false)
  {
    if(!isValid()) {
      return false;
    }

    BSTR lCmd = ANSI2BSTR(pCmd);
    // prepare DISPPARAMS and call Invoke
    VARIANTARG lArgument;
    VariantInit(&lArgument);
    V_VT(&lArgument) = VT_BSTR;
    V_BSTR(&lArgument) = lCmd;
    DISPPARAMS lParams = { &lArgument,NULL,1,0 };
    HRESULT lRc = m_Connector->Invoke(m_DispIDs[disp_EvaluateNoReturn],
				      IID_NULL,
				      LOCALE_USER_DEFAULT,
				      DISPATCH_METHOD,
				      &lParams,
				      NULL,
				      NULL,
				      NULL);
    VariantClear(&lArgument); // also frees string
    if(FAILED(lRc)) {
      if(!pExpectErr) {
	ERR(printf("%s: failed to evaluate (no return) expression \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pCmd,lRc));
      }
      return false;
    } else {
      TRACE(printf("%s: successfully evaluated (no return) expression \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pCmd,lRc));
    }
    return true;
  }
  virtual bool Evaluate(char const* pCmd,VARIANT* pResult,
			bool pExpectErr = false)
  {
    if(!isValid()) {
      return false;
    }

    BSTR lCmd = ANSI2BSTR(pCmd);
    // prepare DISPPARAMS and call Invoke
    VARIANTARG lArgument;
    VariantInit(&lArgument);
    V_VT(&lArgument) = VT_BSTR;
    V_BSTR(&lArgument) = lCmd;
    DISPPARAMS lParams = { &lArgument,NULL,1,0 };
    HRESULT lRc = m_Connector->Invoke(m_DispIDs[disp_Evaluate],
				      IID_NULL,
				      LOCALE_USER_DEFAULT,
				      DISPATCH_METHOD,
				      &lParams,
				      pResult,
				      NULL,
				      NULL);
    VariantClear(&lArgument); // also frees string
    if(FAILED(lRc)) {
      if(!pExpectErr) {
	ERR(printf("%s: failed to evaluate expression \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pCmd,lRc));
      }
      return false;
    } else {
      TRACE(printf("%s: successfully evaluated expression \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pCmd,lRc));
    }
    return true;
  }

  virtual bool SetSymbol(char const* pSymbol,VARIANT pVal,
			 bool pExpectErr = false)
  {
    if(!isValid()) {
      return false;
    }

    BSTR lSymbol = ANSI2BSTR(pSymbol);
    // prepare DISPPARAMS and call Invoke
    VARIANTARG lArgument[2]; // reverse order of parameters!
    VariantInit(&(lArgument[1])); /* first parameter */
    V_VT(&(lArgument[1])) = VT_BSTR;
    V_BSTR(&lArgument[1]) = lSymbol;
    VariantInit(&lArgument[0]);
    VariantCopy(&lArgument[0],&pVal); /* second parameter */
    DISPPARAMS lParams = { lArgument,NULL,2,0 };
    unsigned int lError;
    HRESULT lRc = m_Connector->Invoke(m_DispIDs[disp_SetSymbol],
				      IID_NULL,
				      LOCALE_USER_DEFAULT,
				      DISPATCH_METHOD,
				      &lParams,
				      NULL,
				      NULL,
				      &lError);
    VariantClear(&(lArgument[1])); // also frees string
    if(FAILED(lRc)) {
      if(!pExpectErr) {
	ERR(printf("%s: failed to set symbol \"%s\" (rc=%08lx, arg=%u)\n",
		   __PRETTY_FUNCTION__,pSymbol,lRc,lError));
      }
      return false;
    } else {
      TRACE(printf("%s: successfully set symbol \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pSymbol,lRc));
    }
    return true;
  }
  virtual bool GetSymbol(char const* pSymbol,VARIANT* pVal,
			 bool pExpectErr = false)
  {
    if(!isValid()) {
      return false;
    }

    BSTR lSymbol = ANSI2BSTR(pSymbol);
    // prepare DISPPARAMS and call Invoke
    VARIANTARG lArgument;
    VariantInit(&lArgument);
    V_VT(&lArgument) = VT_BSTR;
    V_BSTR(&lArgument) = lSymbol;
    DISPPARAMS lParams = { &lArgument,NULL,1,0 };
    HRESULT lRc = m_Connector->Invoke(m_DispIDs[disp_GetSymbol],
				      IID_NULL,
				      LOCALE_USER_DEFAULT,
				      DISPATCH_METHOD,
				      &lParams,
				      pVal,
				      NULL,
				      NULL);
    VariantClear(&lArgument); // also frees string
    if(FAILED(lRc)) {
      if(!pExpectErr) {
	ERR(printf("%s: failed to get symbol \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pSymbol,lRc));
      }
      return false;
    } else {
      TRACE(printf("%s: successfully got symbol \"%s\" (rc=%08lx)\n",
		   __PRETTY_FUNCTION__,pSymbol,lRc));
    }
    return true;
  }

  //--------------------------------------------------------------------------
  protected:
  //--------------------------------------------------------------------------

  //--------------------------------------------------------------------------
  private:
  //--------------------------------------------------------------------------

  enum {
    disp_Init = 0,
    disp_Close = 1,
    disp_GetSymbol = 2,
    disp_SetSymbol = 3,
    disp_Evaluate = 4,
    disp_EvaluateNoReturn = 5,
    max_disp = disp_EvaluateNoReturn
  } dispids;

  //----------------------------------------------------------------------
  // private assignment operator/copy constructor
  //----------------------------------------------------------------------
  DispatchConnector(DispatchConnector const&);
  DispatchConnector& operator=(DispatchConnector const&);

  IDispatch* m_Connector;
  DISPID m_DispIDs[max_disp+1];
};


/******************************************************************************/
/*                              Test Implementation                           */
/******************************************************************************/


/*@FUNC**********************************************************************/
/** perform simple tests on COM server.
*
* - SetSymbol (VT_I4)
* - GetSymbol
* - EvaluateNoReturn (setting symbol)
* - Evaluate (retrieve symbol)
*
* @param pConnector the COM interface wrapper
* @return bool success indicator
* @exception 
* @see       
*//***************************************************************************
** 05-05-16 | baier | CREATED
*****************************************************************************/
bool simple_tests
(
  Connector* pConnector
)
{
  /* simple SetSymbol() */
  {
    VARIANT lVar;

    VariantInit(&lVar);
    V_VT(&lVar) = VT_I4;
    V_I4(&lVar) = 99;

    if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
      ERR(printf("VT_I4 failed\n"));
      return false;
    }
    VariantClear(&lVar);
  }

  /* simple GetSymbol() */
  {
    VARIANT lVar;
    VariantInit(&lVar);
    if(!pConnector->GetSymbol(SYMBOL_NAME,&lVar)) {
      ERR(printf("VT_I4 failed\n"));
      return false;
    }

    TRACE(printf("%s: successfully got symbol \"%s\", type is %08x (should be %08x), value is %ld, should be 99\n",
		   __PRETTY_FUNCTION__,SYMBOL_NAME,V_VT(&lVar),VT_I4,V_I4(&lVar)));

    if((V_VT(&lVar) != VT_I4)
       || (V_I4(&lVar) != 99)) {
      ERR(printf("GetSymbol() failed to retrieve correct value set by SetSymbol()\n"));
      return false;
    }
    VariantClear(&lVar);
  }

  /* EvaluateNoReturn() */
  if(!pConnector->EvaluateNoReturn(EVAL_STRING)) {
    ERR(printf("VT_I4 failed\n"));
    return false;
  }

  /* simple Evaluate() */
  {
    VARIANT lVar;
    VariantInit(&lVar);
    if(!pConnector->Evaluate(SYMBOL_NAME,&lVar)) {
      ERR(printf("VT_I4 failed\n"));
      return false;
    }
    TRACE(printf("%s: successfully evaluated expression \"%s\", type is %08x (should be %08x), value is %g, should be 25\n",
		 __PRETTY_FUNCTION__,SYMBOL_NAME,V_VT(&lVar),VT_R8,V_R8(&lVar)));
    if((V_VT(&lVar) != VT_R8)
       || (V_R8(&lVar) != 25.0)) {
      ERR(printf("Evaluate() failed to retrieve symbol set by EvaluateNoReturn()\n"));
      return false;
    }
    VariantClear(&lVar);
  }
  return true;
}


/*@FUNC**********************************************************************/
/** test data transfer capabilities: scalars.
*
* to test the data transfer capabilities, transfer various data items using
* SetSymbol, perform some operation on the data (e.g. assignment, arithmetics)
* and read the data back using GetSymbol.
*
* @param pConnector the COM interface wrapper
* @return bool success indicator
* @exception 
* @see       
*//***************************************************************************
** 05-05-18 | baier | CREATED
*****************************************************************************/
bool data_tests_scalar
(
  Connector* pConnector
)
{
  VARIANT lVar;

  /* VT_I2 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_I2;
  V_I2(&lVar) = VT_I2_VAL;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_I2 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_I2 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_I2 failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_I4) || (V_I2(&lVar) != VT_I2_VAL)) {
    ERR(printf("VT_I2: error in SetSymbol()/GetSymbol() pair (type=%d, val=%d)\n",
	       V_VT(&lVar),V_I2(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* VT_I4 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_I4;
  V_I4(&lVar) = VT_I4_VAL;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_I4 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_I4 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_I4 failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_I4) || (V_I4(&lVar) != VT_I4_VAL)) {
    ERR(printf("VT_I4: error in SetSymbol()/GetSymbol() pair (type=%d, val=%ld)\n",
	       V_VT(&lVar),V_I4(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* VT_UI1 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_UI1;
  V_UI1(&lVar) = VT_UI1_VAL;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_UI1 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_UI1 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_UI1 failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_I4) || (V_I4(&lVar) != VT_UI1_VAL)) {
    ERR(printf("VT_UI1: error in SetSymbol()/GetSymbol() pair (type=%d, val=%ld)\n",
	       V_VT(&lVar),V_I4(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* VT_R4 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_R4;
  V_R4(&lVar) = VT_R4_VAL;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_R4 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_R4 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_R4 failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_R8) || (V_R8(&lVar) < VT_R4_VAL - 0.01)
     || (V_R8(&lVar) > VT_R4_VAL + 0.01)) {
    ERR(printf("VT_R4: error in SetSymbol()/GetSymbol() pair (type=%d, val=%g/%g)\n",
	       V_VT(&lVar),V_R8(&lVar),VT_R4_VAL));
    return false;
  }
  VariantClear(&lVar);

  /* VT_R8 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_R8;
  V_R8(&lVar) = VT_R8_VAL;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_R8 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_R8 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_R8 failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_R8) || (V_R8(&lVar) < VT_R8_VAL - 0.01)
     || (V_R8(&lVar) > VT_R8_VAL + 0.01)) {
    ERR(printf("VT_R8: error in SetSymbol()/GetSymbol() pair (type=%d, val=%g)\n",
	       V_VT(&lVar),V_R8(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* VT_BOOL */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BOOL;
  V_BOOL(&lVar) = VT_BOOL_VAL;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BOOL failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BOOL failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BOOL failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_BOOL) || (V_BOOL(&lVar) != VT_BOOL_VAL)) {
    ERR(printf("VT_BOOL: error in SetSymbol()/GetSymbol() pair (type=%d, val=%d)\n",
	       V_VT(&lVar),V_BOOL(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* VT_BSTR */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BSTR;
  V_BSTR(&lVar) = VT_BSTR_VAL;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BSTR failed\n"));
    return false;
  }
  VariantClear(&lVar);
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BSTR failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BSTR failed\n"));
    return false;
  }
  if(V_VT(&lVar) != VT_BSTR) { /* we trust the value if it is a BSTR */
    ERR(printf("VT_BSTR: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* VT_BYREF | VT_I2 */
  SHORT iVal = VT_I2_VAL;
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_I2;
  V_I2REF(&lVar) = &iVal;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_I2 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_I2 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_I2 failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_I4) || (V_I2(&lVar) != VT_I2_VAL)) {
    ERR(printf("VT_BYREF | VT_I2: error in SetSymbol()/GetSymbol() pair (type=%d, val=%d)\n",
	       V_VT(&lVar),V_I2(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* VT_BYREF | VT_I4 */
  LONG lVal = VT_I4_VAL;
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_I4;
  V_I4REF(&lVar) = &lVal;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_I4 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_I4 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_I4 failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_I4) || (V_I4(&lVar) != VT_I4_VAL)) {
    ERR(printf("VT_BYREF | VT_I4: error in SetSymbol()/GetSymbol() pair (type=%d, val=%ld)\n",
	       V_VT(&lVar),V_I4(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* VT_BYREF | VT_UI1 */
  BYTE bVal = VT_UI1_VAL;
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_UI1;
  V_UI1REF(&lVar) = &bVal;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_UI1 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_UI1 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_UI1 failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_I4) || (V_I4(&lVar) != VT_UI1_VAL)) {
    ERR(printf("VT_BYREF | VT_UI1: error in SetSymbol()/GetSymbol() pair (type=%d, val=%ld)\n",
	       V_VT(&lVar),V_I4(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* VT_BYREF | VT_R4 */
  FLOAT fltVal = VT_R4_VAL;
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_R4;
  V_R4REF(&lVar) = &fltVal;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_R4 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_R4 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_R4 failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_R8) || (V_R8(&lVar) < VT_R4_VAL - 0.01)
     || (V_R8(&lVar) > VT_R4_VAL + 0.01)) {
    ERR(printf("VT_BYREF | VT_R4: error in SetSymbol()/GetSymbol() pair (type=%d, val=%g/%g)\n",
	       V_VT(&lVar),V_R8(&lVar),VT_R4_VAL));
    return false;
  }
  VariantClear(&lVar);

  /* VT_BYREF | VT_R8 */
  DOUBLE dblVal = VT_R8_VAL;
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_R8;
  V_R8REF(&lVar) = &dblVal;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_R8 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_R8 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_R8 failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_R8) || (V_R8(&lVar) < VT_R8_VAL - 0.01)
     || (V_R8(&lVar) > VT_R8_VAL + 0.01)) {
    ERR(printf("VT_BYREF | VT_R8: error in SetSymbol()/GetSymbol() pair (type=%d, val=%g)\n",
	       V_VT(&lVar),V_R8(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* VT_BYREF | VT_BOOL */
  VARIANT_BOOL boolVal = VT_BOOL_VAL;
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_BOOL;
  V_BOOLREF(&lVar) = &boolVal;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_BOOL failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_BOOL failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_BOOL failed\n"));
    return false;
  }
  if((V_VT(&lVar) != VT_BOOL) || (V_BOOL(&lVar) != VT_BOOL_VAL)) {
    ERR(printf("VT_BYREF | VT_BOOL: error in SetSymbol()/GetSymbol() pair (type=%d, val=%d)\n",
	       V_VT(&lVar),V_BOOL(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* VT_BYREF | VT_BSTR */
  BSTR bstrVal = VT_BSTR_VAL;
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_BSTR;
  V_BSTRREF(&lVar) = &bstrVal;
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_BSTR failed\n"));
    return false;
  }
  VariantClear(&lVar);
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_BSTR failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_BSTR failed\n"));
    return false;
  }
  if(V_VT(&lVar) != VT_BSTR) { /* we trust the value if it is a BSTR */
    ERR(printf("VT_BYREF | VT_BSTR: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  VariantClear(&lVar);
  SysFreeString(bstrVal);

  return true;
}


/*@FUNC**********************************************************************/
/** test data transfer capabilities: arrays.
*
* to test the data transfer capabilities, transfer various data items using
* SetSymbol, perform some operation on the data (e.g. assignment, arithmetics)
* and read the data back using GetSymbol.
*
* @param pConnector the COM interface wrapper
* @return bool success indicator
* @exception 
* @see       
*//***************************************************************************
** 05-05-18 | baier | CREATED
*****************************************************************************/
bool data_tests_array
(
  Connector* pConnector
)
{
  SAFEARRAYBOUND lBounds[2] = { { 2,0 },{ 3,0 }};
  VARIANT lVar;
  SHORT iVal = VT_I2_VAL;
  LONG lVal = VT_I4_VAL;
  BYTE bVal = VT_UI1_VAL;
  VARIANT_BOOL boolVal = VT_BOOL_VAL;
  FLOAT fltVal = VT_R4_VAL;
  DOUBLE dblVal = VT_R8_VAL;
  long lDims[2];

  /* 2x3 I2 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_ARRAY | VT_I2;
  V_ARRAY(&lVar) = SafeArrayCreate(VT_I2,2,lBounds);
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(V_ARRAY(&lVar),lDims,&iVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_ARRAY | VT_I2 failed\n"));
    return false;
  }
  VariantClear(&lVar);
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_ARRAY | VT_I2 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_ARRAY | VT_I2 failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_I4)) { /* values should be ok */
    ERR(printf("VT_ARRAY | VT_I2: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* 2x3 I4 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_ARRAY | VT_I4;
  V_ARRAY(&lVar) = SafeArrayCreate(VT_I4,2,lBounds);
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_ARRAY | VT_I4 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_ARRAY | VT_I4 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_ARRAY | VT_I4 failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_I4)) { /* values should be ok */
    ERR(printf("VT_ARRAY | VT_I4: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* 2x3 UI1 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_ARRAY | VT_UI1;
  V_ARRAY(&lVar) = SafeArrayCreate(VT_UI1,2,lBounds);
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(V_ARRAY(&lVar),lDims,&bVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_ARRAY | VT_UI1 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_ARRAY | VT_UI1 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_ARRAY | VT_UI1 failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_I4)) { /* values should be ok */
    ERR(printf("VT_ARRAY | VT_UI1: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* 2x3 R4 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_ARRAY | VT_R4;
  V_ARRAY(&lVar) = SafeArrayCreate(VT_R4,2,lBounds);
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(V_ARRAY(&lVar),lDims,&fltVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_ARRAY | VT_R4 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_ARRAY | VT_R4 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_ARRAY | VT_R4 failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_R8)) { /* values should be ok */
    ERR(printf("VT_ARRAY | VT_R4: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* 2x3 R8 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_ARRAY | VT_R8;
  V_ARRAY(&lVar) = SafeArrayCreate(VT_R8,2,lBounds);
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(V_ARRAY(&lVar),lDims,&dblVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_ARRAY | VT_R8 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_ARRAY | VT_R8 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_ARRAY | VT_R8 failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_R8)) { /* values should be ok */
    ERR(printf("VT_ARRAY | VT_R8: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* 2x3 BOOL */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_ARRAY | VT_BOOL;
  V_ARRAY(&lVar) = SafeArrayCreate(VT_BOOL,2,lBounds);
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(V_ARRAY(&lVar),lDims,&boolVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_ARRAY | VT_BOOL failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_ARRAY | VT_BOOL failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_ARRAY | VT_BOOL failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_BOOL)) { /* values should be ok */
    ERR(printf("VT_ARRAY | VT_BOOL: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* 2x3 BSTR */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_ARRAY | VT_BSTR;
  V_ARRAY(&lVar) = SafeArrayCreate(VT_BSTR,2,lBounds);
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(V_ARRAY(&lVar),lDims,VT_BSTR_VAL);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_ARRAY | VT_BSTR failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_ARRAY | VT_BSTR failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_ARRAY | VT_BSTR failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_BSTR)) { /* values should be ok */
    ERR(printf("VT_ARRAY | VT_BSTR: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  SAFEARRAY* paVal;

  /* 2x3 VT_BYREF | VT_ARRAY | VT_I2 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_ARRAY | VT_I2;
  paVal = SafeArrayCreate(VT_I2,2,lBounds);
  V_ARRAYREF(&lVar) = &paVal;
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(paVal,lDims,&iVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_I2 failed\n"));
    return false;
  }
  VariantClear(&lVar);
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_I2 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_I2 failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_I4)) { /* values should be ok */
    ERR(printf("VT_BYREF | VT_ARRAY | VT_I2: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  SafeArrayDestroy(paVal);
  VariantClear(&lVar);

  /* 2x3 VT_BYREF | VT_ARRAY | I4 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_ARRAY | VT_I4;
  paVal = SafeArrayCreate(VT_I4,2,lBounds);
  V_ARRAYREF(&lVar) = &paVal;
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(paVal,lDims,&lVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_I4 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_I4 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_I4 failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_I4)) { /* values should be ok */
    ERR(printf("VT_BYREF | VT_ARRAY | VT_I4: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  SafeArrayDestroy(paVal);
  VariantClear(&lVar);

  /* 2x3 VT_BYREF | VT_ARRAY | UI1 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_ARRAY | VT_UI1;
  paVal = SafeArrayCreate(VT_UI1,2,lBounds);
  V_ARRAYREF(&lVar) = &paVal;
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(paVal,lDims,&bVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_UI1 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_UI1 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_UI1 failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_I4)) { /* values should be ok */
    ERR(printf("VT_BYREF | VT_ARRAY | VT_UI1: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  SafeArrayDestroy(paVal);
  VariantClear(&lVar);

  /* 2x3 VT_BYREF | VT_ARRAY | R4 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_ARRAY | VT_R4;
  paVal = SafeArrayCreate(VT_R4,2,lBounds);
  V_ARRAYREF(&lVar) = &paVal;
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(paVal,lDims,&fltVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_R4 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_R4 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_R4 failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_R8)) { /* values should be ok */
    ERR(printf("VT_BYREF | VT_ARRAY | VT_R4: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  SafeArrayDestroy(paVal);
  VariantClear(&lVar);

  /* 2x3 VT_BYREF | VT_ARRAY | R8 */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_ARRAY | VT_R8;
  paVal = SafeArrayCreate(VT_R8,2,lBounds);
  V_ARRAYREF(&lVar) = &paVal;
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(paVal,lDims,&dblVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_R8 failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_R8 failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_R8 failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_R8)) { /* values should be ok */
    ERR(printf("VT_BYREF | VT_ARRAY | VT_R8: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  SafeArrayDestroy(paVal);
  VariantClear(&lVar);

  /* 2x3 VT_BYREF | VT_ARRAY | BOOL */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_ARRAY | VT_BOOL;
  paVal = SafeArrayCreate(VT_BOOL,2,lBounds);
  V_ARRAYREF(&lVar) = &paVal;
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(paVal,lDims,&boolVal);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_BOOL failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_BOOL failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_BOOL failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_BOOL)) { /* values should be ok */
    ERR(printf("VT_BYREF | VT_ARRAY | VT_BOOL: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  SafeArrayDestroy(paVal);
  VariantClear(&lVar);

  /* 2x3 VT_BYREF | VT_ARRAY | BSTR */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_ARRAY | VT_BSTR;
  paVal = SafeArrayCreate(VT_BSTR,2,lBounds);
  V_ARRAYREF(&lVar) = &paVal;
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(paVal,lDims,VT_BSTR_VAL);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_BSTR failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_BSTR failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_BSTR failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_BSTR)) { /* values should be ok */
    ERR(printf("VT_BYREF | VT_ARRAY | VT_BSTR: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  SafeArrayDestroy(paVal);
  VariantClear(&lVar);

  return true;
}


/*@FUNC**********************************************************************/
/** test data transfer capabilities: variant arrays.
*
* to test the data transfer capabilities, transfer various data items using
* SetSymbol, perform some operation on the data (e.g. assignment, arithmetics)
* and read the data back using GetSymbol.
*
* VT_BYREF | any type is _not_ supported in a VARIANT-Array
*
* @param pConnector the COM interface wrapper
* @return bool success indicator
* @exception 
* @see       
*//***************************************************************************
** 05-05-18 | baier | CREATED
*****************************************************************************/
bool data_tests_variant
(
  Connector* pConnector
)
{
  /* transfer a 2x7 array with mixed data types (including special) */
  SAFEARRAYBOUND lBounds[2] = { { 2,0 },{ 7,0 }};
  VARIANT lVar;
  VARIANT lTmpVar;
  /*SHORT iVal = VT_I2_VAL;
  LONG lVal = VT_I4_VAL;
  BYTE bVal = VT_UI1_VAL;
  VARIANT_BOOL boolVal = VT_BOOL_VAL;
  FLOAT fltVal = VT_R4_VAL;
  DOUBLE dblVal = VT_R8_VAL;*/
  BSTR bstrVal = VT_BSTR_VAL;
  long lDims[2];
  bool lErr = true;

  VariantInit(&lVar);
  V_VT(&lVar) = VT_ARRAY | VT_VARIANT;
  V_ARRAY(&lVar) = SafeArrayCreate(VT_VARIANT,2,lBounds);

  /* VT_I2 -> [0,0] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_I2;
  V_I2(&lTmpVar) = VT_I2_VAL;
  lDims[0] = 0; lDims[1] = 0;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_I4 -> [0,1] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_I4;
  V_I4(&lTmpVar) = VT_I4_VAL;
  lDims[0] = 0; lDims[1] = 1;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_UI1 -> [0,2] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_UI1;
  V_UI1(&lTmpVar) = VT_UI1_VAL;
  lDims[0] = 0; lDims[1] = 2;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_R4 -> [0,3] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_R4;
  V_R4(&lTmpVar) = VT_R4_VAL;
  lDims[0] = 0; lDims[1] = 3;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_R8 -> [0,4] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_R8;
  V_R8(&lTmpVar) = VT_R8_VAL;
  lDims[0] = 0; lDims[1] = 4;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_BOOL -> [0,5] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_BOOL;
  V_BOOL(&lTmpVar) = VT_BOOL_VAL;
  lDims[0] = 0; lDims[1] = 5;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_BSTR -> [0,6] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_BSTR;
  V_BSTR(&lTmpVar) = VT_BSTR_VAL;
  lDims[0] = 0; lDims[1] = 6;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

#if 1
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_ERROR;
  V_ERROR(&lTmpVar) = 0x800a0000 | 2007; /* xlErrDiv0 */
  lDims[0] = 1; lDims[1] = 0;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_ERROR;
  V_ERROR(&lTmpVar) = 0x800a0000 | 2042; /* xlErrNA */
  lDims[0] = 1; lDims[1] = 1;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_ERROR;
  V_ERROR(&lTmpVar) = 0x800a0000 | 2000; /* xlErrNull */
  lDims[0] = 1; lDims[1] = 2;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_ERROR;
  V_ERROR(&lTmpVar) = 0x800a0000 | 2000; /* xlErrNull */
  lDims[0] = 1; lDims[1] = 3;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_ERROR;
  V_ERROR(&lTmpVar) = 0x800a0000 | 2000; /* xlErrNull */
  lDims[0] = 1; lDims[1] = 4;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_ERROR;
  V_ERROR(&lTmpVar) = 0x800a0000 | 2000; /* xlErrNull */
  lDims[0] = 1; lDims[1] = 5;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_ERROR;
  V_ERROR(&lTmpVar) = 0x800a0000 | 2000; /* xlErrNull */
  lDims[0] = 1; lDims[1] = 6;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

#else
  /* VT_BYREF not supported in VARIANT arrays */
  /* VT_BYREF | VT_I2 -> [1,0] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_BYREF | VT_I2;
  V_I2REF(&lTmpVar) = &iVal;
  lDims[0] = 1; lDims[1] = 0;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_BYREF | VT_I4 -> [1,1] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_BYREF | VT_I4;
  V_I4REF(&lTmpVar) = &lVal;
  lDims[0] = 1; lDims[1] = 1;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_BYREF | VT_UI1 -> [1,2] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_BYREF | VT_UI1;
  V_UI1REF(&lTmpVar) = &bVal;
  lDims[0] = 1; lDims[1] = 2;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_BYREF | VT_R4 -> [1,3] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_BYREF | VT_R4;
  V_R4REF(&lTmpVar) = &fltVal;
  lDims[0] = 1; lDims[1] = 3;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_BYREF | VT_R8 -> [1,4] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_BYREF | VT_R8;
  V_R8REF(&lTmpVar) = &dblVal;
  lDims[0] = 1; lDims[1] = 4;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_BYREF | VT_BOOL -> [1,5] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_BYREF | VT_BOOL;
  V_BOOLREF(&lTmpVar) = &boolVal;
  lDims[0] = 1; lDims[1] = 5;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);

  /* VT_BYREF | VT_BSTR -> [1,6] */
  VariantInit(&lTmpVar);
  V_VT(&lTmpVar) = VT_BYREF | VT_BSTR;
  V_BSTRREF(&lTmpVar) = &bstrVal;
  lDims[0] = 1; lDims[1] = 6;
  SafeArrayPutElement(V_ARRAY(&lVar),lDims,&lTmpVar);
#endif

  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_ARRAY | VT_VARIANT failed\n"));
    return false;
  }
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_ARRAY | VT_VARIANT failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_ARRAY | VT_VARIANT failed\n"));
    return false;
  }
  if(V_VT(&lVar) != (VT_ARRAY | VT_VARIANT)) {
    ERR(printf("VT_ARRAY | VT_VARIANT: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  /* check element types */
  lDims[0] = 0;
  for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
    VariantInit(&lTmpVar);
    SafeArrayGetElement(V_ARRAY(&lVar),lDims,&lTmpVar);
    if(V_VT(&lTmpVar) != VT_I4) {
      ERR(printf("VT_ARRAY | VT_VARIANT: error in SetSymbol()/GetSymbol() pair, index [%ld,%ld] has type %d\n",
		 lDims[0],lDims[1],V_VT(&lTmpVar)));
      lErr = false;
    }
  }
  for(lDims[1] = 3;lDims[1] < 5;lDims[1]++) {
    VariantInit(&lTmpVar);
    SafeArrayGetElement(V_ARRAY(&lVar),lDims,&lTmpVar);
    if(V_VT(&lTmpVar) != VT_R8) {
      ERR(printf("VT_ARRAY | VT_VARIANT: error in SetSymbol()/GetSymbol() pair, index [%ld,%ld] has type %d\n",
		 lDims[0],lDims[1],V_VT(&lTmpVar)));
      lErr = false;
    }
  }
  lDims[1] = 5;
  VariantInit(&lTmpVar);
  SafeArrayGetElement(V_ARRAY(&lVar),lDims,&lTmpVar);
  if(V_VT(&lTmpVar) != VT_BOOL) {
    ERR(printf("VT_ARRAY | VT_VARIANT: error in SetSymbol()/GetSymbol() pair, index [%ld,%ld] has type %d\n",
	       lDims[0],lDims[1],V_VT(&lTmpVar)));
    lErr = false;
  }
  lDims[1] = 6;
  VariantInit(&lTmpVar);
  SafeArrayGetElement(V_ARRAY(&lVar),lDims,&lTmpVar);
  if(V_VT(&lTmpVar) != VT_BSTR) {
    ERR(printf("VT_ARRAY | VT_VARIANT: error in SetSymbol()/GetSymbol() pair, index [%ld,%ld] has type %d\n",
	       lDims[0],lDims[1],V_VT(&lTmpVar)));
    lErr = false;
  }
  lDims[0] = 1;
  for(lDims[1] = 0;lDims[1] < 7;lDims[1]++) {
    VariantInit(&lTmpVar);
    SafeArrayGetElement(V_ARRAY(&lVar),lDims,&lTmpVar);
    if(V_VT(&lTmpVar) != VT_ERROR) {
      ERR(printf("VT_ARRAY | VT_VARIANT: error in SetSymbol()/GetSymbol() pair, index [%ld,%ld] has type %d\n",
		 lDims[0],lDims[1],V_VT(&lTmpVar)));
      lErr = false;
    }
  }
  SysFreeString(bstrVal);
  VariantClear(&lVar);
  return lErr;
}


/*@FUNC**********************************************************************/
/** test data transfer capabilities: COM objects.
*
* to test the data transfer capabilities, transfer various data items using
* SetSymbol, perform some operation on the data (e.g. assignment, arithmetics)
* and read the data back using GetSymbol.
*
* @param pConnector the COM interface wrapper
* @return bool success indicator
* @exception 
* @see       
*//***************************************************************************
** 05-05-18 | baier | CREATED
*****************************************************************************/
bool data_tests_object
(
  Connector* pConnector
)
{
  return true;
}


/*@FUNC**********************************************************************/
/** test data transfer capabilities: special values.
*
* to test the data transfer capabilities, transfer various data items using
* SetSymbol, perform some operation on the data (e.g. assignment, arithmetics)
* and read the data back using GetSymbol.
*
* @param pConnector the COM interface wrapper
* @return bool success indicator
* @exception 
* @see       
*//***************************************************************************
** 05-05-18 | baier | CREATED
*****************************************************************************/
bool data_tests_special
(
  Connector* pConnector
)
{
  VARIANT lVar;
  SCODE scodeArray[] = { 0x800a0000 | xlErrDiv0,
			 0x800a0000 | xlErrNA,
			 0x800a0000 | xlErrNull};
  SCODE scodeArrayResult[] = { 0x800a0000 | xlErrDiv0,
			       0x800a0000 | xlErrNA,
			       0x800a0000 | xlErrNA};
  SAFEARRAYBOUND lBounds[2] = { { 2,0 },{ 3,0 }};
  long lDims[2];
  SAFEARRAY* paVal;

  /* VT_ERROR */
  {
    VariantInit(&lVar);
    V_VT(&lVar) = VT_ERROR;
    V_ERROR(&lVar) = 0x800a0000 | xlErrDiv0; /* xlErrDiv0 */
    if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
      ERR(printf("VT_ERROR, xlErrDiv0 failed\n"));
      return false;
    }
    VariantClear(&lVar);
    if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
      ERR(printf("VT_ERROR, xlErrDiv0 failed\n"));
      return false;
    }
    if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
      ERR(printf("VT_ERROR, xlErrDiv0 failed\n"));
      return false;
    }
    if((V_VT(&lVar) != VT_ERROR) || (V_ERROR(&lVar) != (long) (0x800a0000UL | xlErrDiv0))) {
      ERR(printf("VT_ERROR, xlErrDiv0: error in SetSymbol()/GetSymbol() pair (type=%d, val=%08lx)\n",
		 V_VT(&lVar),V_ERROR(&lVar)));
      return false;
    }

    VariantInit(&lVar);
    V_VT(&lVar) = VT_ERROR;
    V_ERROR(&lVar) = 0x800a0000 | xlErrNA; /* xlErrNA */
    if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
      return false;
    }
    VariantClear(&lVar);
    if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
      ERR(printf("VT_ERROR, xlErrNA failed\n"));
      return false;
    }
    if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
      ERR(printf("VT_ERROR, xlErrNA failed\n"));
      return false;
    }
    if((V_VT(&lVar) != VT_ERROR) || (V_ERROR(&lVar) != (long) (0x800a0000 | xlErrNA))) {
      ERR(printf("VT_ERROR, xlErrNA: error in SetSymbol()/GetSymbol() pair (type=%d, val=%08lx)\n",
		 V_VT(&lVar),V_ERROR(&lVar)));
      return false;
    }

    VariantInit(&lVar);
    V_VT(&lVar) = VT_ERROR;
    V_ERROR(&lVar) = 0x800a0000 | xlErrNull; /* xlErrNull */
    if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
      ERR(printf("VT_ERROR, xlErrNull failed\n"));
      return false;
    }
    VariantClear(&lVar);
    if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
      ERR(printf("VT_ERROR, xlErrNull failed\n"));
      return false;
    }
    if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
      ERR(printf("VT_ERROR, xlErrNull failed\n"));
      return false;
    }
    if((V_VT(&lVar) != VT_ERROR) || (V_ERROR(&lVar) != (long) (0x800a0000 | xlErrNA))) {
      ERR(printf("VT_ERROR, xlErrNull: error in SetSymbol()/GetSymbol() pair (type=%d, val=%08lx)\n",
		 V_VT(&lVar),V_ERROR(&lVar)));
      return false;
    }
  }

  /* VT_ERROR | VT_BYREF */
  {
    SCODE lSCode;

    VariantInit(&lVar);
    V_VT(&lVar) = VT_BYREF | VT_ERROR;
    lSCode = 0x800a0000 | xlErrDiv0; /* xlErrDiv0 */
    V_ERRORREF(&lVar) = &lSCode;
    if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrDiv0 failed\n"));
      return false;
    }
    VariantClear(&lVar);
    if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrDiv0 failed\n"));
      return false;
    }
    if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrDiv0 failed\n"));
      return false;
    }
    if((V_VT(&lVar) != VT_ERROR) || (V_ERROR(&lVar) != (long) (0x800a0000UL | xlErrDiv0))) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrDiv0: error in SetSymbol()/GetSymbol() pair (type=%d, val=%08lx)\n",
		 V_VT(&lVar),V_ERROR(&lVar)));
      return false;
    }

    VariantInit(&lVar);
    V_VT(&lVar) = VT_BYREF | VT_ERROR;
    lSCode = 0x800a0000 | xlErrNA; /* xlErrNA */
    V_ERRORREF(&lVar) = &lSCode;
    if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrNA failed\n"));
      return false;
    }
    VariantClear(&lVar);
    if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrNA failed\n"));
      return false;
    }
    if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrNA failed\n"));
      return false;
    }
    if((V_VT(&lVar) != VT_ERROR) || (V_ERROR(&lVar) != (long) (0x800a0000 | xlErrNA))) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrNA: error in SetSymbol()/GetSymbol() pair (type=%d, val=%08lx)\n",
		 V_VT(&lVar),V_ERROR(&lVar)));
      return false;
    }

    VariantInit(&lVar);
    V_VT(&lVar) = VT_BYREF | VT_ERROR;
    lSCode = 0x800a0000 | xlErrNull; /* xlErrNull */
    V_ERRORREF(&lVar) = &lSCode;
    if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrNull failed\n"));
      return false;
    }
    VariantClear(&lVar);
    if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrNull failed\n"));
      return false;
    }
    if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrNull failed\n"));
      return false;
    }
    if((V_VT(&lVar) != VT_ERROR) || (V_ERROR(&lVar) != (long) (0x800a0000 | xlErrNA))) {
      ERR(printf("VT_BYREF | VT_ERROR, xlErrNull: error in SetSymbol()/GetSymbol() pair (type=%d, val=%08lx)\n",
		 V_VT(&lVar),V_ERROR(&lVar)));
      return false;
    }
  }

  /* 2x3 ERROR */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_ARRAY | VT_ERROR;
  V_ARRAY(&lVar) = SafeArrayCreate(VT_ERROR,2,lBounds);
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(V_ARRAY(&lVar),lDims,&scodeArray[lDims[1]]);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_ARRAY | VT_ERROR failed\n"));
    return false;
  }
  VariantClear(&lVar);
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_ARRAY | VT_ERROR failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_ARRAY | VT_ERROR failed\n"));
    return false;
  }
  if(V_VT(&lVar) == (VT_ARRAY | VT_VARIANT)) {
    for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
      for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
	VARIANT lVarElem;
	VariantInit(&lVarElem);
	SafeArrayGetElement(V_ARRAY(&lVar),lDims,&lVarElem);
	if((V_VT(&lVarElem) != VT_ERROR)
	   || (V_ERROR(&lVarElem) != scodeArrayResult[lDims[1]])) {
	  ERR(printf("VT_ARRAY | VT_ERROR: error at index (%ld/%ld), type=%08x, value=%08lx should be %08lx\n",
		     lDims[0],lDims[1],V_VT(&lVarElem),
		     V_ERROR(&lVarElem),scodeArrayResult[lDims[1]]));
	}
	VariantClear(&lVarElem);
      }
    }
  } else if(V_VT(&lVar) == (VT_ARRAY | VT_ERROR)) {
    for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
      for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
	SCODE scode;
	SafeArrayGetElement(V_ARRAY(&lVar),lDims,&scode);
	if(scode != scodeArrayResult[lDims[1]]) {
	  ERR(printf("VT_ARRAY | VT_ERROR: error at index (%ld/%ld), value=%08lx should be %08lx\n",
		     lDims[0],lDims[1],scode,scodeArrayResult[lDims[1]]));
	}
      }
    }
  } else {
    ERR(printf("VT_ARRAY | VT_ERROR: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  /* 2x3 VT_BYREF | VT_ARRAY | ERROR */
  VariantInit(&lVar);
  V_VT(&lVar) = VT_BYREF | VT_ARRAY | VT_ERROR;
  paVal = SafeArrayCreate(VT_ERROR,2,lBounds);
  V_ARRAYREF(&lVar) = &paVal;
  for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
    for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
      SafeArrayPutElement(paVal,lDims,&scodeArray[lDims[1]]);
    }
  }
  if(!pConnector->SetSymbol(SYMBOL_NAME,lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_ERROR failed\n"));
    return false;
  }
  VariantClear(&lVar);
  if(!pConnector->EvaluateNoReturn(SYMBOL_ASSIGN)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_ERROR failed\n"));
    return false;
  }
  if(!pConnector->GetSymbol(SYMBOL_NAME2,&lVar)) {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_ERROR failed\n"));
    return false;
  }
  if(V_VT(&lVar) == (VT_ARRAY | VT_VARIANT)) {
    for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
      for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
	VARIANT lVarElem;
	VariantInit(&lVarElem);
	SafeArrayGetElement(V_ARRAY(&lVar),lDims,&lVarElem);
	if((V_VT(&lVarElem) != VT_ERROR)
	   || (V_ERROR(&lVarElem) != scodeArrayResult[lDims[1]])) {
	  ERR(printf("VT_BYREF | VT_ARRAY | VT_ERROR: error at index (%ld/%ld), type=%08x, value=%08lx should be %08lx\n",
		     lDims[0],lDims[1],V_VT(&lVarElem),
		     V_ERROR(&lVarElem),scodeArrayResult[lDims[1]]));
	}
	VariantClear(&lVarElem);
      }
    }
  } else if(V_VT(&lVar) == (VT_ARRAY | VT_ERROR)) {
    for(lDims[0] = 0;lDims[0] < 2;lDims[0]++) {
      for(lDims[1] = 0;lDims[1] < 3;lDims[1]++) {
	SCODE scode;
	SafeArrayGetElement(V_ARRAY(&lVar),lDims,&scode);
	if(scode != scodeArrayResult[lDims[1]]) {
	  ERR(printf("VT_BYREF | VT_ARRAY | VT_ERROR: error at index (%ld/%ld), value=%08lx should be %08lx\n",
		     lDims[0],lDims[1],scode,scodeArrayResult[lDims[1]]));
	}
      }
    }
  } else {
    ERR(printf("VT_BYREF | VT_ARRAY | VT_ERROR: error in SetSymbol()/GetSymbol() pair (type=%d)\n",
	       V_VT(&lVar)));
    return false;
  }
  VariantClear(&lVar);

  return true;
}


/*@FUNC**********************************************************************/
/** test error handling on R side.
*
* @param pConnector the COM interface wrapper
* @return bool success indicator
* @exception 
* @see       
*//***************************************************************************
** 05-05-15 | baier | CREATED
*****************************************************************************/
bool error_tests
(
  Connector* pConnector
)
{
  /* set a symbol that can't exist (name starts with digit) */
  VARIANT lVar;
  VariantInit(&lVar);
  V_VT(&lVar) = VT_I4;
  V_I4(&lVar) = 99;

#if 0
  /* the following works: R's symbol install() returns an SEXP even if 
   * the name of the symbol is not valid */
  if(pConnector->SetSymbol(ERR_SYMBOL_NAME,lVar,true)) {
    ERR(printf("error should occur setting symbol \"%s\" but succeeded\n",
	       ERR_SYMBOL_NAME));
    return false;
  }
#endif
  if(pConnector->SetSymbol(ERR_SYMBOL_EMPTY,lVar,true)) {
    ERR(printf("error should occur setting symbol \"%s\" but succeeded\n",
	       ERR_SYMBOL_EMPTY));
    return false;
  }
  VariantClear(&lVar);

  /* retrieve a symbol that can't exist (name starts with digit) */
  if(pConnector->GetSymbol(ERR_SYMBOL_NAME,&lVar,true)) {
    ERR(printf("error should occur getting symbol \"%s\" but succeeded\n",
	       ERR_SYMBOL_NAME));
    return false;
  }
  if(pConnector->GetSymbol(ERR_SYMBOL_EMPTY,&lVar,true)) {
    ERR(printf("error should occur getting symbol \"%s\" but succeeded\n",
	       ERR_SYMBOL_EMPTY));
    return false;
  }

  /* retrieve a not existing symbol */
  if(pConnector->GetSymbol(ERR_SYMBOL_NOTEXIST,&lVar,true)) {
    ERR(printf("error should occur getting symbol \"%s\" but succeeded\n",
	       ERR_SYMBOL_NOTEXIST));
    return false;
  }

  /* set a symbol that can't exist using Evaluate (name starts with digit) */
  if(pConnector->Evaluate(ERR_EVAL_STRING,&lVar,true)) {
    ERR(printf("error should occur evaluating expression \"%s\" but succeeded\n",
	       ERR_EVAL_STRING));
    return false;
  }

  /* retrieve a symbol that can't exist using Evaluate */
  if(pConnector->Evaluate(ERR_SYMBOL_NAME,&lVar,true)) {
    ERR(printf("error should occur evaluating expression \"%s\" but succeeded\n",
	       ERR_SYMBOL_NAME));
    return false;
  }
  if(pConnector->Evaluate(ERR_SYMBOL_EMPTY,&lVar,true)) {
    ERR(printf("error should occur evaluating expression \"%s\" but succeeded\n",
	       ERR_SYMBOL_EMPTY));
    return false;
  }

  /* retrieve a not existing symbol using Evaluate */
  if(pConnector->Evaluate(ERR_SYMBOL_NOTEXIST,&lVar,true)) {
    ERR(printf("error should occur evaluating expression \"%s\" but succeeded\n",
	       ERR_SYMBOL_NOTEXIST));
    return false;
  }

  /* set a symbol that can't exist using EvaluateNoReturn (starts with digit) */
  if(pConnector->EvaluateNoReturn(ERR_EVAL_STRING,true)) {
    ERR(printf("error should occur evaluating (no return) expression \"%s\" but succeeded\n",
	       ERR_EVAL_STRING));
    return false;
  }

  /* call a non-existing function using Evaluate */
  if(pConnector->Evaluate(ERR_EVAL_NOTEXIST,&lVar,true)) {
    ERR(printf("error should occur evaluating expression \"%s\" but succeeded\n",
	       ERR_EVAL_NOTEXIST));
    return false;
  }

  /* call a non-existing function using EvaluateNoReturn */
  if(pConnector->EvaluateNoReturn(ERR_EVAL_NOTEXIST,true)) {
    ERR(printf("error should occur evaluating expression \"%s\" but succeeded\n",
	       ERR_EVAL_NOTEXIST));
    return false;
  }

  return true;
}


/*@FUNC**********************************************************************/
/** perform the tests using the interface wrapper passed here.
*
* @return void
* @exception 
* @see       
*//***************************************************************************
** 05-05-13 | baier | CREATED
*****************************************************************************/
bool do_test(Connector* pConnector)
{
  if(!pConnector->Init(INIT_STRING)) {
    return false;
  }
  if(!simple_tests(pConnector)) {
    return false;
  }
  if(!data_tests_scalar(pConnector)) {
    return false;
  }
  if(!data_tests_array(pConnector)) {
    return false;
  }
  if(!data_tests_variant(pConnector)) {
    return false;
  }
  if(!data_tests_object(pConnector)) {
    return false;
  }
  if(!data_tests_special(pConnector)) {
    return false;
  }
  if(!error_tests(pConnector)) {
    return false;
  }

  /* shut down R (or at least the COM server) */
  if(!pConnector->Close()) {
    return false;
  }

  return true;
}


/*@FUNC**********************************************************************/
/** test the IStatConnector custom interface.
*
* @return void
* @exception 
* @see       
*//***************************************************************************
** 05-05-13 | baier | CREATED
*****************************************************************************/
void custom_test(CLSID pClsId)
{
  LOG(printf("Tests with custom interface start\n"));
  Connector* lConnector = new CustomConnector(pClsId);

  if(lConnector->isValid()) {
    if(do_test(lConnector)) {
      LOG(printf("Tests with custom interface ended successfully\n"));
    }
  }

  delete lConnector;
}

/*@FUNC**********************************************************************/
/** test functions using IDispatch.
*
* @param pClsId the CLSID
* @return void
* @exception 
* @see       
*//***************************************************************************
** 05-05-15 | baier | CREATED
*****************************************************************************/
void dispatch_test
(
  CLSID pClsId
)
{
  LOG(printf("Tests with dispatch interface start\n"));
  Connector* lConnector = new DispatchConnector(pClsId);

  if(lConnector->isValid()) {
    if(do_test(lConnector)) {
      LOG(printf("Tests with dispatch interface ended successfully\n"));
    }
  }

  delete lConnector;
}


/*@FUNC**********************************************************************/
/** program entry.
*
* @param argc the number of command line parameters
* @param argv the array of command line parameters
* @param envp the array of environment settings
* @return int exit code
* @exception 
* @see       
*//***************************************************************************
** 05-05-13 | baier | CREATED
*****************************************************************************/
int main
(
  int argc
 ,char ** argv
 ,char ** envp
)
{
  CLSID lClsIdServer = CLSID_InternalConnector;
  HRESULT lRc;

  g_argc = argc;
  g_argv = argv;

  /* check parameters */
  if(argc == 2) {
    /* parameter is class id/prog name */
    LPOLESTR lServer = com_getOLECHAR(g_argv[1]);
    lRc = CLSIDFromString(lServer,&lClsIdServer);

    if(FAILED(lRc)) {
      /* maybe a prog id was passed */
      lRc = CLSIDFromProgID(lServer,&lClsIdServer);
    }
    free(lServer);

    /* still not found? */
    if(FAILED(lRc)) {
      ERR(printf("%s: %s is not a valid CLSID or ProgID\n",
		 g_argv[0],g_argv[1]));
      return -1;
    }
  }

  LOG(printf("%s: using {%08lu-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x} as COM server\n",
	     g_argv[0],
	     lClsIdServer.Data1,
	     lClsIdServer.Data2,
	     lClsIdServer.Data3,
	     lClsIdServer.Data4[0],lClsIdServer.Data4[1],
	     lClsIdServer.Data4[2],lClsIdServer.Data4[3],
	     lClsIdServer.Data4[4],lClsIdServer.Data4[5],
	     lClsIdServer.Data4[6],lClsIdServer.Data4[7]));

  CoInitializeEx(NULL,COINIT_MULTITHREADED);

  custom_test(lClsIdServer); /* test functions with IStatConnector */
  dispatch_test(lClsIdServer); /* test functions with IDispatch */

  CoUninitialize();
  return 0;
}
