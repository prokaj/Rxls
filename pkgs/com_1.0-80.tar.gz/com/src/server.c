/*******************************************************************************
 *  RCOM : COM Client and Server for R
 *  Copyright (C) 2003-2005 Thomas Baier
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  ---------------------------------------------------------------------------
 *
 *  $Id: server.c 1.1 2003/04/27 16:34:17 baier Exp $
 *
 ******************************************************************************/

//#define CONTEXT

#include "rcom.h"
#include <stdio.h>
#include <SC_Proxy.h>
#include "Rversion.h"
#include "server.h"
//#include <SC_Proxy.h>
#include <bdx.h>
#include "bdx_util.h"
#include "bdx_com.h"

#define USE_SCPROXY 1

#define SERVER_BINARY "rcom.dll"
#define TLB_MAJOR_VERSION 1
#define TLB_MINOR_VERSION 0
#define TLB_LCID 1
#define SERVER_FRIENDLY_NAME "Internal R COM Server"
#define SERVER_INDEP_PROGID "RCOMServerLib.StatConnector"
#define SERVER_DEP_PROGID "RCOMServerLib.StatConnector.1"
#define SERVER_CLSID CLSID_InternalConnector
#define SERVER_LIBID LIBID_RCOMServerLib
#if defined(USE_SCPROXY)
#define PROXY_PATH "library\\comproxy\\libs"
#define PROXY_BINARY "comproxy.dll"
#else
#define PROXY_BINARY "Rproxy.dll"
#endif

#define PARAMPREFIX "REUSER"

#define	SCN_IERR_INTERFACENOTFOUND      0x81000000
#define	SCN_IERR_LIBRARYNOTFOUND        0x81000001
#define	SCN_IERR_INVALIDLIBRARY         0x81000002
#define	SCN_IERR_INITIALIZATIONFAILED   0x81000003
#define	SCN_IERR_INVALIDCONNECTORNAME   0x81000004
#define SCN_ERR_INITIALIZED             0x81000005
#define SCN_ERR_NOTINITIALIZED          0x81000006

static HINSTANCE s_HModule = 0;
static HINSTANCE s_ProxyModule = NULL;
static struct _SC_Proxy_Object* s_ProxyObject = NULL;

static IClassFactoryVtbl s_IClassFactory = {
  (__IClassFactory_QueryInterface) _IClassFactory_QueryInterface,
  (__IClassFactory_AddRef) _IUnknown_AddRef,
  (__IClassFactory_Release) _IUnknown_Release,
  (__IClassFactory_CreateInstance) _IClassFactory_CreateInstance,
  (__IClassFactory_LockServer) _IClassFactory_LockServer
};

static IStatConnectorVtbl s_IStatConnector = {
  (__IStatConnector_QueryInterface) _IStatConnector_QueryInterface,
  (__IStatConnector_AddRef) _IUnknown_AddRef,
  (__IStatConnector_Release) _IUnknown_Release,
  (__IStatConnector_GetTypeInfoCount) _IDispatch_GetTypeInfoCount,
  (__IStatConnector_GetTypeInfo) _IDispatch_GetTypeInfo,
  (__IStatConnector_GetIDsOfNames) _IDispatch_GetIDsOfNames,
  (__IStatConnector_Invoke) _IDispatch_Invoke,
  (__IStatConnector_Init) _IStatConnector_Init,
  (__IStatConnector_Close) _IStatConnector_Close,
  (__IStatConnector_GetSupportedTypes) _IStatConnector_GetSupportedTypes,
  (__IStatConnector_GetSymbol) _IStatConnector_GetSymbol,
  (__IStatConnector_SetSymbol) _IStatConnector_SetSymbol,
  (__IStatConnector_Evaluate) _IStatConnector_Evaluate,
  (__IStatConnector_EvaluateNoReturn) _IStatConnector_EvaluateNoReturn,
  (__IStatConnector_GetErrorId) _IStatConnector_GetErrorId,
  (__IStatConnector_GetErrorText) _IStatConnector_GetErrorText,
  (__IStatConnector_AddGraphicsDevice) _IStatConnector_AddGraphicsDevice,
  (__IStatConnector_RemoveGraphicsDevice) _IStatConnector_RemoveGraphicsDevice,
  (__IStatConnector_SetUserInterfaceAgent) _IStatConnector_SetUserInterfaceAgent,
  (__IStatConnector_SetCharacterOutputDevice) _IStatConnector_SetCharacterOutputDevice,
  (__IStatConnector_SetErrorDevice) _IStatConnector_SetErrorDevice,
  (__IStatConnector_SetTracingDevice) _IStatConnector_SetTracingDevice,
  (__IStatConnector_GetServerInformation) _IStatConnector_GetServerInformation,
  (__IStatConnector_GetConnectorInformation) _IStatConnector_GetConnectorInformation,
  (__IStatConnector_GetInterpreterInformation) _IStatConnector_GetInterpreterInformation
};

struct tagStatConnectorFactory* _IClassFactory_Create()
{
  struct tagStatConnectorFactory* _this =
    (struct tagStatConnectorFactory*) malloc(sizeof(struct tagStatConnectorFactory));
  _this->obj.lpVtbl = &s_IClassFactory;
  _this->m_RefCount = 1;
  /*  _this->m_ptinfo = 0; */
  _this->Delete = (__IUnknown_Delete) _IClassFactory_Delete;
  /*  _IStatConnector_loadTypeInfo(_this); */
  RCOM_TRACE(printf("IClassFactory object at %p created\n",_this));

#ifndef NDEBUG
  if(getenv("DBG_RCOM")) { DebugBreak(); }
#endif

  return _this;
}

void _IClassFactory_Delete(struct tagStatConnectorFactory* _this)
{
  RCOM_TRACE(printf("IClassFactory object at %p deleted\n",_this));
  free(_this);
}

HRESULT STDMETHODCALLTYPE
_IClassFactory_QueryInterface(struct tagStatConnectorFactory* _this,
			      REFIID riid,
			      LPVOID* ppvObj)
{
  /*  printf("IClassFactory::QueryInterface()\n"); */
  if(IsEqualIID(riid,&IID_IClassFactory)) {
    /*printf ("_IStatConnector_QueryInterface(IID_IStatConnector)\n"); */
    _IUnknown_AddRef((struct tagUnknown*) _this);
    *ppvObj = (LPVOID) _this;
    return S_OK;
  }
  return _IUnknown_QueryInterface((struct tagUnknown*) _this,
				  riid,ppvObj);
}

HRESULT STDMETHODCALLTYPE
_IClassFactory_CreateInstance(struct tagStatConnectorFactory* _this,
			      LPUNKNOWN pUnkO,
			      REFIID riid,
			      LPVOID* ppvObj)
{
  HRESULT hr = S_OK;
  struct tagStatConnector* sc;
  /*printf("IClassFactory::CreateInstance()\n"); */
  if(pUnkO) {
    return CLASS_E_NOAGGREGATION;
  }
  sc = _IStatConnector_Create();
  hr = sc->obj.lpVtbl->QueryInterface(&(sc->obj),riid,ppvObj);
  sc->obj.lpVtbl->Release(&(sc->obj));
  return hr;
}

HRESULT STDMETHODCALLTYPE
_IClassFactory_LockServer(struct tagStatConnectorFactory* _this,
			  BOOL bVal)
{
  /*printf("IClassFactory::LockServer()\n"); */
  return S_OK;
}

void _IStatConnector_loadTypeInfo(struct tagStatConnector* _this)
{
  ITypeLib* pITypeLib = 0;
  HRESULT hr = _C_loadTypeLib(&SERVER_LIBID,
			      TLB_MAJOR_VERSION, /* ver_major */
			      TLB_MINOR_VERSION, /* ver_minor */
			      TLB_LCID, /* lcid */
			      &pITypeLib,
			      NULL); /* */
  /*  RCOM_TRACE(printf("Type Lib loaded\n")); */
  if(FAILED(hr)) {
    RCOM_ERR(printf("error %10lx loading type library\n",hr));
    return;
  }
  /*printf("successfully loaded type library \"%s\"\n",SERVER_TLB); */
  hr = _C_getTypeInfo(&IID_IStatConnector,
		      pITypeLib,&(_this->m_ptinfo));
  pITypeLib->lpVtbl->Release(pITypeLib);
  if(FAILED(hr)) {
    RCOM_ERR(printf("error %10lx retrieving type info\n",hr));
    return;
  }
  /*printf("successfully got type info\n"); */
}

struct tagStatConnector* _IStatConnector_Create()
{
  struct tagStatConnector* _this =
    (struct tagStatConnector*) malloc(sizeof(struct tagStatConnector));
  _this->obj.lpVtbl = &s_IStatConnector;
  _this->m_RefCount = 1;
  _this->Delete = (__IUnknown_Delete) _IStatConnector_Delete;
  _this->m_ptinfo = 0;
  _IStatConnector_loadTypeInfo(_this);
  _this->m_ErrorCode = 0;
  _this->m_ErrorText = NULL;
  RCOM_TRACE(printf("IStatConnector object at %p created\n",_this));
  return _this;
}

void _IStatConnector_Delete(struct tagStatConnector* _this)
{
  RCOM_TRACE(printf("IStatConnector object at %p deleted\n",_this));
  if (_this->m_ptinfo) {
    _this->m_ptinfo->lpVtbl->Release(_this->m_ptinfo);
  }
  free(_this);
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_QueryInterface(struct tagStatConnector* _this,
			       REFIID riid,
			       LPVOID* ppvObj)
{
  /*printf("IStatConnector::QueryInterface()\n"); */
  if(IsEqualIID(riid,&IID_IStatConnector)) {
    /*printf ("_IStatConnector_QueryInterface(IID_IStatConnector)\n"); */
    _IUnknown_AddRef((struct tagUnknown*) _this);
    *ppvObj = (LPVOID) _this;
    return S_OK;
  }
  return _IDispatch_QueryInterface((struct tagDispatch*) _this,
				   riid,ppvObj);
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_Init(struct tagStatConnector* _this,
		     BSTR bstrConnectorName)
{
  char* lConnectorName = NULL;
  char* lParams = NULL;

  if(bstrConnectorName == 0) {
    return _IStatConnector__SetErrorCode(_this,E_INVALIDARG);
  }

  lConnectorName = BSTR2ANSI(bstrConnectorName);

  if(strcmp(lConnectorName,"R") == 0) {
    lParams = strdup(PARAMPREFIX);
  } else if(strncmp(lConnectorName,"R:",2) == 0) {
    lParams = (char*) malloc(strlen(lConnectorName) - 2 + strlen(PARAMPREFIX ";"));
    sprintf(lParams,"%s;%s",PARAMPREFIX,lConnectorName + 2);
  } else {
    free(lConnectorName);
    return _IStatConnector__ConvertErrorCode(_this,
					     SCN_IERR_INVALIDCONNECTORNAME);
  }
  free(lConnectorName);
  s_ProxyObject->vtbl->init(s_ProxyObject,lParams);
  free(lParams);
  /*  RCOM_TRACE(printf("_IStatConnector_Init\n")); */
  return S_FALSE;
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_Close(struct tagStatConnector* _this)
{
  /*  RCOM_TRACE(printf("_IStatConnector_Close\n")); */
  return S_FALSE;
}

/* 04-11-16 | baier | rproxy based implementation */
HRESULT STDMETHODCALLTYPE
_IStatConnector_GetSupportedTypes(struct tagStatConnector* _this,
				  LONG *pulTypeMask)
{
  /*  RCOM_TRACE(printf("_IStatConnector_GetSupportedTypes\n")); */
  /* parameter checks: type mask buffer must not be 0 */
  if (pulTypeMask == 0) {
    return _IStatConnector__SetErrorCode(_this,E_INVALIDARG);
  }
    
  {    
    long lProxyTypes = 0;
    ULONG lRc;
    *pulTypeMask = 0;
    
    lRc = s_ProxyObject->vtbl->query_supported_types(s_ProxyObject,&lProxyTypes);
    
    if (lRc != SC_PROXY_OK) {
      return _IStatConnector__ConvertErrorCode(_this,lRc);
    }
    
    /* we got the types, now return them */
    *pulTypeMask = (lProxyTypes
		    & (SCN_TM_SCALAR_ALL
		       | SCN_TM_ARRAY_ALL
		       | SCN_TM_VECTOR_ALL));
  }
    
  return _IStatConnector__SetErrorCode(_this,S_OK);
}

/* 04-11-16 | baier | rproxy based implementation */
HRESULT STDMETHODCALLTYPE
_IStatConnector_GetSymbol(struct tagStatConnector* _this,
			  BSTR bstrSymbolName,
			  VARIANT *pvData)
{
  /*  RCOM_TRACE(printf("_IStatConnector_GetSymbol\n")); */

  if ((bstrSymbolName == 0)
      || (pvData == 0)) {
    return _IStatConnector__SetErrorCode (_this,E_INVALIDARG);
  }

  {
    HRESULT lRet = S_OK;
    char* lSymbolName = BSTR2ANSI(bstrSymbolName);
    BDX_Data* lData = NULL;
    ULONG lRc = 0;

    if(*lSymbolName == 0x0) {
      free(lSymbolName);
      return _IStatConnector__SetErrorCode(_this,E_INVALIDARG);
    }
    
    lRc = s_ProxyObject->vtbl->get_symbol(s_ProxyObject,lSymbolName,&lData);
    
    free(lSymbolName);

    if (lRc == SC_PROXY_OK) {
      if (lData == NULL) {
	return _IStatConnector__SetErrorCode(_this,E_FAIL);
      }
    
      /* init the variant */
      VariantInit(pvData);
    
      if (BDX2Variant(lData,pvData) != 0) {
	lRet = SCN_E_UNSUPPORTEDTYPE;
      }
      s_ProxyObject->vtbl->free_data_buffer(s_ProxyObject,lData);
    } else {
      return _IStatConnector__ConvertErrorCode(_this,lRc);
    }
    return _IStatConnector__SetErrorCode(_this,lRet);
  }
}

/* 04-11-16 | baier | rproxy based implementation */
HRESULT STDMETHODCALLTYPE
_IStatConnector_SetSymbol(struct tagStatConnector* _this,
			  BSTR bstrSymbolName,
			  VARIANT vData)
{
  char* lSymbolName;
  BDX_Data* lData = 0;
  ULONG lRc = 0;

  /*  RCOM_TRACE(printf("_IStatConnector_SetSymbol\n")); */
  if (bstrSymbolName == NULL) {
    return _IStatConnector__SetErrorCode(_this,E_INVALIDARG);
  }
  lSymbolName = BSTR2ANSI(bstrSymbolName);

  if (*lSymbolName == 0x0) {
    free(lSymbolName);
    return _IStatConnector__SetErrorCode(_this,E_INVALIDARG);
  }

  if(Variant2BDX(vData,&lData) != 0) {
    free(lSymbolName);
    return _IStatConnector__SetErrorCode(_this,E_INVALIDARG);
  }
    	    
  /*  bdx_trace(lData); */

  lData->version = BDX_VERSION; /* will be removed */
    
  /*  RPROXY_ERR(printf("calling set_symbol\n")); */
  lRc = s_ProxyObject->vtbl->set_symbol (s_ProxyObject,lSymbolName,lData);
  /*  RPROXY_ERR(printf("set_symbol returned code %08x\n",lRc)); */

  /* free the data */
  free(lSymbolName);
  bdx_free (lData);
  
  if (lRc == SC_PROXY_OK) {
    return _IStatConnector__SetErrorCode(_this,S_OK);
  }

  return _IStatConnector__ConvertErrorCode(_this,lRc);
}

/* 04-08-01 | baier | fixed error codes, ref-counting (PROTECT) on errors */
/* 04-08-01 | baier | return code S_OK for unsupported types -> fixed */
/* 04-11-16 | baier | rproxy based implementation */
HRESULT STDMETHODCALLTYPE
_IStatConnector_Evaluate(struct tagStatConnector* _this,
			 BSTR bstrExpression,
			 VARIANT *pvData)
{
  HRESULT lRet = E_FAIL;
  char* lExpression;
  BDX_Data* lData = 0;
  ULONG lRc = 0;

  if ((bstrExpression == 0)
      || (pvData == 0)) {
    return _IStatConnector__SetErrorCode(_this,E_INVALIDARG);
  }
    
  lExpression = BSTR2ANSI(bstrExpression);
    	    
  if (*lExpression == 0x0) {
    free(lExpression);
    return _IStatConnector__SetErrorCode(_this,E_INVALIDARG);
  }
    
  lRc = s_ProxyObject->vtbl->evaluate (s_ProxyObject,lExpression,&lData);
    
  free(lExpression);

  if (lRc == SC_PROXY_OK) {
    if (lData == 0) {
      return _IStatConnector__SetErrorCode(_this,E_FAIL);
    }
    
    /* init the variant */
    VariantInit (pvData);
    
    if (BDX2Variant(lData,pvData) == 0) {
      lRet = S_OK;
    }
    
    s_ProxyObject->vtbl->free_data_buffer(s_ProxyObject,lData);
    
    return _IStatConnector__SetErrorCode(_this,S_OK);
  } else {
    return _IStatConnector__ConvertErrorCode(_this,lRc);
  }
}

/* 04-08-01 | baier | fixed error codes, ref-counting (PROTECT) on errors */
/* 04-11-16 | baier | rproxy based implementation */
HRESULT STDMETHODCALLTYPE
_IStatConnector_EvaluateNoReturn(struct tagStatConnector* _this,
				 BSTR bstrExpression)
{
  HRESULT lRc = S_OK;

  char* lCmd = BSTR2ANSI(bstrExpression);

  if(lCmd == NULL) {
    return _IStatConnector__SetErrorCode(_this,E_INVALIDARG);
  }

  /*  RCOM_TRACE(printf("calling rproxy::evaluate_noreturn()\n")); */
  lRc = s_ProxyObject->vtbl->evaluate_noreturn (s_ProxyObject,lCmd);
  free(lCmd);
  if (lRc == SC_PROXY_OK) {
    return _IStatConnector__SetErrorCode(_this,S_OK);
  }
  return _IStatConnector__ConvertErrorCode(_this,lRc);
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_GetErrorId(struct tagStatConnector* _this,
			   LONG *pulErrorId)
{
  /*  RCOM_TRACE(printf("_IStatConnector_GetErrorId\n")); */
  /* parameter checks: error id must not point to 0 */
  if (pulErrorId == 0)
    {
      return _IStatConnector__SetErrorCode (_this,E_INVALIDARG);
    }
    
  *pulErrorId = _this->m_ErrorCode;

  return S_OK;
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_GetErrorText(struct tagStatConnector* _this,
			     BSTR *pbstrErrorText)
{
  /* RCOM_TRACE(printf("_IStatConnector_GetErrorText\n")); */
  /* parameter checks: error text must not point to 0 */
  if (pbstrErrorText == 0)
    {
      return _IStatConnector__SetErrorCode (_this,E_INVALIDARG);
    }

  *pbstrErrorText = ANSI2BSTR(_this->m_ErrorText);

  return S_OK;
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_AddGraphicsDevice(struct tagStatConnector* _this,
				  BSTR bstrName,
				  ISGFX *pDevice)
{
  /*RCOM_TRACE(printf("_IStatConnector_AddGraphicsDevice\n")); */
  return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_RemoveGraphicsDevice(struct tagStatConnector* _this,
				     BSTR bstrName)
{
  /*RCOM_TRACE(printf("_IStatConnector_RemoveGraphicsDevice\n")); */
  return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_SetUserInterfaceAgent(struct tagStatConnector* _this,
				      IStatConnectorUIAgent *pUIAgent)
{
  /*RCOM_TRACE(printf("_IStatConnector_SetUserInterfaceAgent\n")); */
  return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_SetCharacterOutputDevice(struct tagStatConnector* _this,
					 IStatConnectorCharacterDevice *pCharDevice)
{
  /*RCOM_TRACE(printf("_IStatConnector_SetCharacterOutputDevice\n")); */
  return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_SetErrorDevice(struct tagStatConnector* _this,
			       IStatConnectorCharacterDevice *pCharDevice)
{
  /*RCOM_TRACE(printf("_IStatConnector_SetErrorDevice\n")); */
  return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_SetTracingDevice(struct tagStatConnector* _this,
				 IStatConnectorCharacterDevice *pCharDevice)
{
  /*RCOM_TRACE(printf("_IStatConnector_SetTracingDevice\n")); */
  return E_NOTIMPL;
}

/* 04-07-06 | baier | use #defines for texts/versions (see rcom.h) */
HRESULT STDMETHODCALLTYPE
_IStatConnector_GetServerInformation(struct tagStatConnector* _this,
				     InformationType lInformationType,
				     BSTR *pbstrInfo)
{
  /*RCOM_TRACE(printf("_IStatConnector_GetServerInformation\n")); */
  if (pbstrInfo == 0)
    {
      return _IStatConnector__SetErrorCode (_this,E_INVALIDARG);
    }

  switch (lInformationType)
    {
    case itName:
      {
	*pbstrInfo = ANSI2BSTR(RCOM_SERVER_NAME);
	break;
      }
    case itDescription:
      {
	*pbstrInfo = ANSI2BSTR(RCOM_SERVER_DESCRIPTION);
	break;
      }
    case itCopyright:
      {
	*pbstrInfo = ANSI2BSTR(RCOM_SERVER_COPYRIGHT);
	break;
      }
    case itLicense:
      {
	*pbstrInfo = ANSI2BSTR(RCOM_SERVER_LICENSE);
	break;
      }
    case itMinorVersion:
      {
	*pbstrInfo = ANSI2BSTR(STRINGIFY(RCOM_VERSION_MINOR));
	break;
      }
    case itMajorVersion:
      {
	*pbstrInfo = ANSI2BSTR(STRINGIFY(RCOM_VERSION_MAJOR));
	break;
      }
    default:
      *pbstrInfo = ANSI2BSTR("");
    }
  return _IStatConnector__SetErrorCode (_this,S_OK);
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_GetConnectorInformation(struct tagStatConnector* _this,
					InformationType lInformationType,
					BSTR *pbstrInfo)
{
  /*  RCOM_TRACE(printf("_IStatConnector_GetConnectorInformation\n")); */
  return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE
_IStatConnector_GetInterpreterInformation(struct tagStatConnector* _this,
					  InformationType lInformationType,
					  BSTR *pbstrInfo)
{
  /*RCOM_TRACE(printf("_IStatConnector_GetInterpreterInformation\n")); */
  return E_NOTIMPL;
}

static DWORD s_clsobj = 0;

SEXP registerServerInRegistry(SEXP sexp)
{
  char lFNBuffer[MAX_PATH];

  com_initialize();
  RCOM_TRACE(printf("registering server in registry\n"));
  _C_RegisterServer(GetModuleHandle(0),
		    &SERVER_CLSID,
		    SERVER_FRIENDLY_NAME,
		    SERVER_INDEP_PROGID,
		    SERVER_DEP_PROGID,
		    &SERVER_LIBID);
  RCOM_TRACE(printf("registering type libraries\n"));
  if(TYPEOF(sexp)==STRSXP){
    for(int i=0;i<length(sexp);i++){
      _C_registerTypeLib(CHAR(STRING_ELT(sexp,i)));
    }
  }
  /* if(s_HModule && GetModuleFileName(s_HModule,lFNBuffer,sizeof(lFNBuffer))) { */
  /*   char* lLastBS = strrchr(lFNBuffer,'\\'); */
  /*   if(lLastBS) { */
  /*     lLastBS++; /\* advance pointer to beginning of filename *\/ */

  /*     /\* add rcom_srv.tlb *\/ */
  /*     strcpy(lLastBS,"rcom_srv.tlb"); */
  /*     _C_registerTypeLib(lFNBuffer); */

  /*     /\* add StatConnLib.tlb *\/ */
  /*     strcpy(lLastBS,"StatConnLib.tlb"); */
  /*     _C_registerTypeLib(lFNBuffer); */
  /*   } else { */
  /*     RCOM_ERR(printf("error parsing path \"%s\"\n",lFNBuffer)); */
  /*   } */
  /* } */ else {
    RCOM_ERR(printf("error getting path for \"com.dll\"\n"));
  }
  return R_NilValue;
}
SEXP unregisterServerInRegistry(SEXP sexp)
{
  com_initialize();
  RCOM_TRACE(printf("unregistering server from registry\n"));
  _C_UnregisterServer(&SERVER_CLSID,
		      SERVER_INDEP_PROGID,
		      SERVER_DEP_PROGID);
  return R_NilValue;
}

/* 02-10-18 | baier | CREATED */
SEXP registerServer(SEXP sexp)
{
  IUnknown* obj = 0;
  struct tagStatConnectorFactory* myfac = NULL;
  HRESULT hr;

  com_initialize();

  /* load proxy library (common server back-end) */
  if(s_ProxyModule == NULL) {
    SC_PROXY_GET_OBJECT lFunc;
    ULONG lRc = 0;

#if defined(USE_SCPROXY)
#if 0
    char lDLLNameBuffer[MAX_PATH];
    snprintf(lDLLNameBuffer,sizeof(lDLLNameBuffer) - 1,
	     "%s\\" PROXY_PATH "\\" PROXY_BINARY,rpath);
#endif
    s_ProxyModule = LoadLibrary(PROXY_BINARY);
#else
    s_ProxyModule = LoadLibrary(PROXY_BINARY);
#endif
    if(s_ProxyModule == NULL) {
      RCOM_ERR(printf("SERVER: could not load \"%s\", rc=%d\n",
		      PROXY_BINARY,GetLastError()));
      return R_NilValue;
    }
    lFunc = (SC_PROXY_GET_OBJECT) GetProcAddress (s_ProxyModule,
						  SC_PROXY_GET_OBJECT_FUN);
    if(lFunc == NULL) {
      RCOM_ERR(printf("SERVER: entry point \"%s\" not found in module \"%s\"\n",
		      SC_PROXY_GET_OBJECT_FUN,PROXY_BINARY));
      FreeLibrary(s_ProxyModule);
      s_ProxyModule = NULL;
      return R_NilValue;
    }

    lRc = lFunc(&s_ProxyObject,SC_PROXY_INTERFACE_VERSION);
    if((lRc != SC_PROXY_OK) || (s_ProxyObject == 0)) {
      FreeLibrary (s_ProxyModule);
      s_ProxyModule = NULL;
      RCOM_ERR(printf("SERVER: getting proxy object failed (rc=%08x)\n",
		      lRc));
      return R_NilValue;
    }
    lRc = s_ProxyObject->vtbl->init(s_ProxyObject,PARAMPREFIX);
    if(lRc != SC_PROXY_OK) {
      FreeLibrary (s_ProxyModule);
      s_ProxyModule = NULL;
      RCOM_ERR(printf("SERVER: error initializing R (rc=%08x)\n",
		      lRc));
      return R_NilValue;
    }
    RCOM_TRACE(printf("SERVER: \"%s\" successfully loaded\n",PROXY_BINARY));
  }

  RCOM_TRACE(printf ("Registering COM server\n"));
  if (s_clsobj != 0) {
    RCOM_ERR(printf("Server already registered\n"));
    return R_NilValue;
  }
  myfac = _IClassFactory_Create();
  hr = CoRegisterClassObject(&CLSID_InternalConnector,
			     (LPUNKNOWN) myfac,
			     CLSCTX_LOCAL_SERVER,
			     REGCLS_MULTIPLEUSE,
			     &s_clsobj);
  if(FAILED(hr)) {
    RCOM_ERR(printf("failed code %10lx registering class object\n",hr));
    s_clsobj=0;
    return R_NilValue;
    /*  } else {
	RCOM_TRACE(printf("class object registered\n"));*/
  }

  hr = CoGetClassObject(&CLSID_InternalConnector,CLSCTX_ALL,0,
			&IID_IClassFactory,((void*)&obj));
  if(FAILED(hr)) {
    RCOM_ERR(printf("failed code %10lx getting class object\n",hr));
  } else {
    /*    RCOM_TRACE(printf("class object got\n")); */
    obj->lpVtbl->Release(obj);
  }
  return R_NilValue;
}

/* 02-10-18 | baier | CREATED */
SEXP unregisterServer(SEXP sexp)
{
  HRESULT hr;
  RCOM_TRACE(printf ("Unregistering COM server\n"));
  if(s_clsobj == 0) {
    RCOM_ERR(printf("class not registered\n"));
    return R_NilValue;
  }
  hr = CoRevokeClassObject(s_clsobj);
  if(FAILED(hr)) {
    RCOM_ERR(printf("error %10lx unregistering class object\n",hr));
  } else {
    RCOM_TRACE(printf("class object revoked\n"));
    s_clsobj = 0; // added by PV 2010.12.17.
  }
  return R_NilValue;
}


/* 04-10-20 | baier | convert the rproxy-error code to HRESULT */
HRESULT _IStatConnector__ConvertErrorCode (struct tagStatConnector* _this,
					   LONG lErrorCode)
{
  switch (lErrorCode) {
  case SC_PROXY_ERR_INVALIDARG:
    return _IStatConnector__SetErrorCode(_this,SCN_E_INVALIDARG);
  case SC_PROXY_ERR_INVALIDFORMAT:
    return _IStatConnector__SetErrorCode(_this,SCN_E_INVALIDFORMAT);
  case SC_PROXY_ERR_NOTIMPL:
    return _IStatConnector__SetErrorCode(_this,SCN_E_NOTIMPL);
      
    /* initialization and termination */
  case SC_PROXY_ERR_INITIALIZED:
  case SC_PROXY_ERR_NOTINITIALIZED:
    return _IStatConnector__SetErrorCode(_this,SCN_E_INVALIDINTERPRETERSTATE);

    /* evaluation, getting and setting symbols */
  case SC_PROXY_ERR_INVALIDSYMBOL:
    return _IStatConnector__SetErrorCode(_this,SCN_E_INVALIDSYMBOL);
  case SC_PROXY_ERR_PARSE_INVALID:
    return _IStatConnector__SetErrorCode(_this,SCN_E_PARSE_INVALID);
  case SC_PROXY_ERR_PARSE_INCOMPLETE:
    return _IStatConnector__SetErrorCode(_this,SCN_E_PARSE_INCOMPLETE);
  case SC_PROXY_ERR_UNSUPPORTEDTYPE:
    return _IStatConnector__SetErrorCode(_this,SCN_E_UNSUPPORTEDTYPE);
  case SC_PROXY_ERR_EVALUATE_STOP:
    return _IStatConnector__SetErrorCode(_this,SCN_E_EVALUATE_STOP);
    
    /* version mismatch */
  case SC_PROXY_ERR_INVALIDINTERFACEVERSION:
    return _IStatConnector__SetErrorCode(_this,SCN_E_INVALIDINTERFACEVERSION);
  case SC_PROXY_ERR_INVALIDINTERPRETERVERSION:
    return _IStatConnector__SetErrorCode(_this,SCN_E_INVALIDINTERPRETERVERSION);
    
    /* internal errors */
  case SCN_IERR_INTERFACENOTFOUND:
    return _IStatConnector__SetErrorCode(_this,SCN_E_INTERFACENOTFOUND);
  case SCN_IERR_LIBRARYNOTFOUND:
    return _IStatConnector__SetErrorCode(_this,SCN_E_LIBRARYNOTFOUND);
  case SCN_IERR_INVALIDLIBRARY:
    return _IStatConnector__SetErrorCode(_this,SCN_E_INVALIDLIBRARY);
  case SCN_IERR_INITIALIZATIONFAILED:
    return _IStatConnector__SetErrorCode(_this,SCN_E_INITIALIZATIONFAILED);
  case SCN_IERR_INVALIDCONNECTORNAME:
    return _IStatConnector__SetErrorCode(_this,SCN_E_INVALIDCONNECTORNAME);
    /* unknown error */
  default:
    return _IStatConnector__SetErrorCode(_this,SCN_E_UNKNOWN);
  }
}

HRESULT _IStatConnector__SetErrorCode (struct tagStatConnector* _this,
				       HRESULT hrErrorCode)
{
  _this->m_ErrorCode = hrErrorCode;

  switch (hrErrorCode)
    {
    case SCN_E_INVALIDARG:
      _this->m_ErrorText = "internal error: invalid argument passed to interpreter";
      break;
    case SCN_E_INVALIDFORMAT:
      _this->m_ErrorText = "internal error: unsupported data format passed to interpreter";
      break;
    case SCN_E_NOTIMPL:
      _this->m_ErrorText = "internal error: interpreter function not implemented";
      break;
      
      /* initialization and termination */
    case SCN_E_INVALIDINTERPRETERSTATE:
      _this->m_ErrorText = "internal error: invalid interpreter state";
      break;

      /* evaluation, getting and setting symbols */
    case SCN_E_INVALIDSYMBOL:
      _this->m_ErrorText = "symbol not found";
      break;
    case SCN_E_PARSE_INVALID:
      _this->m_ErrorText = "invalid expression";
      break;
    case SCN_E_PARSE_INCOMPLETE:
      _this->m_ErrorText = "incomplete expression";
      break;
    case SCN_E_EVALUATE_STOP:
      _this->m_ErrorText = "evaluation stopped because of an error";
      break;
    case SCN_E_UNSUPPORTEDTYPE:
      _this->m_ErrorText = "symbol not found or internal error: unsupported data format";
      break;
      
      /* version mismatch */
    case SCN_E_INVALIDINTERFACEVERSION:
      _this->m_ErrorText = "installation problem: interpreter interface version mismatch";
      break;
    case SCN_E_INVALIDINTERPRETERVERSION:
      _this->m_ErrorText = "installation problem: interpreter version mismatch";
      break;

      /* internal errors */
    case SCN_E_INTERFACENOTFOUND:
      _this->m_ErrorText = "installation problem: unable to load interpreter interface";
      break;
    case SCN_E_LIBRARYNOTFOUND:
      _this->m_ErrorText = "installation problem: unable to load connector";
      break;
    case SCN_E_INVALIDLIBRARY:
      _this->m_ErrorText = "installation problem: invalid connector library";
      break;
    case SCN_E_INITIALIZATIONFAILED:
      _this->m_ErrorText = "installation problem: interpreter initialization failed";
      break;
    case SCN_E_INVALIDCONNECTORNAME:
      _this->m_ErrorText = "invalid connector name specified";
      break;
    case SCN_E_FATALBACKEND:
      _this->m_ErrorText = "unexpected fatal error in back-end implementation. release the object!";
      break;

      /* standard (COM) errors and success codes */
    case S_OK:
      _this->m_ErrorText = "no error";
      break;

    case E_INVALIDARG:
      _this->m_ErrorText = "invalid argument passed in function call";
      break;
    case E_NOTIMPL:
      _this->m_ErrorText = "function not implemented";
      break;
    case E_FAIL:
      _this->m_ErrorText = "unspecified error occurred in function call";
      break;

      /* unknown error */
    default:
      _this->m_ErrorCode = SCN_E_UNKNOWN;
      _this->m_ErrorText = "unknown (internal) error";
    }

  return _this->m_ErrorCode;
}

/* 04-07-13 | baier | new: store instance handle for later use on attach */
BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD dwReason,LPVOID lpvReserved)
{
  switch(dwReason) {
  case DLL_PROCESS_ATTACH:
    s_HModule = hinstDLL;
    break;
  case DLL_PROCESS_DETACH:
    s_HModule = NULL;
    break;
  }
  return TRUE;
}
