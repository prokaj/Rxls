/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sat Jun 26 18:33:34 2004
 */
/* Compiler settings for rcom_srv.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IStatConnector = {0x18c8b660,0x81a2,0x11d3,{0x92,0x54,0x00,0xe0,0x98,0x12,0xf7,0x27}};


const IID LIBID_RCOMServerLib = {0x38008f95,0x0bbf,0x43fd,{0xa8,0x84,0x2d,0xe4,0xb3,0x93,0x94,0x29}};


const CLSID CLSID_InternalConnector = {0x3660c348,0xdf59,0x4ca2,{0x83,0xe8,0x3a,0x91,0x3a,0x9f,0xbc,0x77}};


#ifdef __cplusplus
}
#endif

