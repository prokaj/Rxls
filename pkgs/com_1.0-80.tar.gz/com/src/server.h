/*******************************************************************************
 *  RCOM : COM Client and Server for R
 *  Copyright (C) 2003-2005 Thomas Baier
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  ---------------------------------------------------------------------------
 *
 *  $Id: server.c 1.1 2003/04/27 16:34:17 baier Exp $
 *
 ******************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

#include "SC_Proxy.h"

/*
 * success and error identifiers returned by ::GetErrorId()
 */
#define SCN_ERROR 0x80000000 | (FACILITY_ITF << 16)

  /* internal errors */
#define SCN_E_INVALIDARG         SCN_ERROR | 0x0001
#define SCN_E_INVALIDFORMAT      SCN_ERROR | 0x0002
#define SCN_E_NOTIMPL            SCN_ERROR | 0x0003
#define SCN_E_UNKNOWN            SCN_ERROR | 0x0004

  /* initialization and termination: wrong state (usage errors) */
#define SCN_E_INITIALIZED        SCN_ERROR | 0x0005
#define SCN_E_NOTINITIALIZED     SCN_ERROR | 0x0006

  /* evaluation, getting and setting symbols */
/* 04-08-01 | TB | added SCN_E_EVALUATE_STOP */
#define SCN_E_INVALIDSYMBOL      SCN_ERROR | 0x0007
#define SCN_E_PARSE_INVALID      SCN_ERROR | 0x0008
#define SCN_E_PARSE_INCOMPLETE   SCN_ERROR | 0x0009
#define SCN_E_UNSUPPORTEDTYPE    SCN_ERROR | 0x000a
#define SCN_E_EVALUATE_STOP      SCN_ERROR | 0x000b

  /* version mismatch: wrong interface version */
#define SCN_E_INVALIDINTERFACEVERSION   SCN_ERROR | 0x0010
#define SCN_E_INVALIDINTERPRETERVERSION SCN_ERROR | 0x0011

  /* error codes on startup */
#define SCN_E_INTERFACENOTFOUND        SCN_ERROR | 0x0012
#define SCN_E_LIBRARYNOTFOUND          SCN_ERROR | 0x0013
#define SCN_E_INVALIDLIBRARY           SCN_ERROR | 0x0014
#define SCN_E_INITIALIZATIONFAILED     SCN_ERROR | 0x0015
#define SCN_E_INVALIDCONNECTORNAME     SCN_ERROR | 0x0016
#define SCN_E_INVALIDINTERPRETERSTATE  SCN_ERROR | 0x0017

  /* fatal back-end error (caught "exception", i.e. access violation) */
#define SCN_E_FATALBACKEND       SCN_ERROR | 0x0020

  /* defines for data type flags */
#define SCN_TM_SCALAR_BOOL   (SC_TM_SCALAR_BOOL)
#define SCN_TM_SCALAR_INT    (SC_TM_SCALAR_INT)
#define SCN_TM_SCALAR_DOUBLE (SC_TM_SCALAR_DOUBLE)
#define SCN_TM_SCALAR_STRING (SC_TM_SCALAR_STRING)
#define SCN_TM_SCALAR_ALL    (SCN_TM_SCALAR_BOOL     \
                             | SCN_TM_SCALAR_INT    \
                             | SCN_TM_SCALAR_DOUBLE \
                             | SCN_TM_SCALAR_STRING)

#define SCN_TM_ARRAY_BOOL    (SC_TM_ARRAY_BOOL)
#define SCN_TM_ARRAY_INT     (SC_TM_ARRAY_INT)
#define SCN_TM_ARRAY_DOUBLE  (SC_TM_ARRAY_DOUBLE)
#define SCN_TM_ARRAY_STRING  (SC_TM_ARRAY_STRING)
#define SCN_TM_ARRAY_ALL     (SCN_TM_ARRAY_BOOL     \
                             | SCN_TM_ARRAY_INT    \
                             | SCN_TM_ARRAY_DOUBLE \
                             | SCN_TM_ARRAY_STRING)

#define SCN_TM_VECTOR_BOOL   (SC_TM_VECTOR_BOOL)
#define SCN_TM_VECTOR_INT    (SC_TM_VECTOR_INT)
#define SCN_TM_VECTOR_DOUBLE (SC_TM_VECTOR_DOUBLE)
#define SCN_TM_VECTOR_STRING (SC_TM_VECTOR_STRING)
#define SCN_TM_VECTOR_ALL    (SCN_TM_VECTOR_BOOL     \
                             | SCN_TM_VECTOR_INT    \
                             | SCN_TM_VECTOR_DOUBLE \
                             | SCN_TM_VECTOR_STRING)

#include "rcom.h"
  /*#include <R.h>
    #include <Rinternals.h>
    #undef Free
    #undef ERROR
  */
#include "com_helpers.h"
#include "rcom_srv.h"

SEXP registerServer(SEXP);
SEXP unregisterServer(SEXP);
SEXP registerServerInRegistry(SEXP);
SEXP unregisterServerInRegistry(SEXP);

struct tagStatConnector {
  IStatConnector obj;
  ULONG m_RefCount;
  __IUnknown_Delete Delete;
  ITypeInfo* m_ptinfo;
  LONG  m_ErrorCode;
  char* m_ErrorText;
};
struct tagStatConnectorFactory {
  IClassFactory obj;
  ULONG m_RefCount;
  __IUnknown_Delete Delete;
};

typedef HRESULT (WINAPI *__IClassFactory_QueryInterface)(IClassFactory*,
							 REFIID,LPVOID*);
typedef ULONG (WINAPI *__IClassFactory_AddRef)(IClassFactory*);
typedef ULONG (WINAPI *__IClassFactory_Release)(IClassFactory*);
typedef HRESULT (WINAPI *__IClassFactory_CreateInstance)(IClassFactory*,
							 LPUNKNOWN,
							 REFIID,LPVOID*);
typedef HRESULT (WINAPI *__IClassFactory_LockServer)(IClassFactory*,BOOL);

typedef HRESULT (WINAPI *__IStatConnector_QueryInterface)(IStatConnector*,
							  REFIID,LPVOID*);
typedef ULONG (WINAPI *__IStatConnector_AddRef)(IStatConnector*);
typedef ULONG (WINAPI *__IStatConnector_Release)(IStatConnector*);
typedef HRESULT (WINAPI *__IStatConnector_GetTypeInfoCount)(IStatConnector*,
							    UINT*);
typedef HRESULT (WINAPI *__IStatConnector_GetTypeInfo)(IStatConnector*,UINT,
						       LCID,ITypeInfo**);
typedef HRESULT (WINAPI *__IStatConnector_GetIDsOfNames)(IStatConnector*,REFIID,
							 LPOLESTR*,UINT,LCID,
							 DISPID*);
typedef HRESULT (WINAPI *__IStatConnector_Invoke)(IStatConnector*,DISPID,REFIID,
						  LCID,WORD,DISPPARAMS*,
						  VARIANT*,EXCEPINFO*,UINT*);
typedef HRESULT (WINAPI *__IStatConnector_Init)(IStatConnector*,BSTR);
typedef HRESULT (WINAPI *__IStatConnector_Close)(IStatConnector*);
typedef HRESULT (WINAPI *__IStatConnector_GetSupportedTypes)(IStatConnector*,
							     LONG*);
typedef HRESULT (WINAPI *__IStatConnector_GetSymbol)(IStatConnector*,BSTR,
						     VARIANT*);
typedef HRESULT (WINAPI *__IStatConnector_SetSymbol)(IStatConnector*,BSTR,
						     VARIANT);
typedef HRESULT (WINAPI *__IStatConnector_Evaluate)(IStatConnector*,BSTR,
						    VARIANT*);
typedef HRESULT (WINAPI *__IStatConnector_EvaluateNoReturn)(IStatConnector*,
							    BSTR);
typedef HRESULT (WINAPI *__IStatConnector_GetErrorId)(IStatConnector*,LONG*);
typedef HRESULT (WINAPI *__IStatConnector_GetErrorText)(IStatConnector*,BSTR*);
typedef HRESULT (WINAPI *__IStatConnector_AddGraphicsDevice)(IStatConnector*,
							     BSTR,ISGFX*);
typedef HRESULT (WINAPI *__IStatConnector_RemoveGraphicsDevice)(IStatConnector*,
								BSTR);
typedef HRESULT (WINAPI *__IStatConnector_SetUserInterfaceAgent)(IStatConnector*,
								 IStatConnectorUIAgent*);
typedef HRESULT (WINAPI *__IStatConnector_SetCharacterOutputDevice)(IStatConnector*,
								    IStatConnectorCharacterDevice*);
typedef HRESULT (WINAPI *__IStatConnector_SetErrorDevice)(IStatConnector*,
							  IStatConnectorCharacterDevice*);
typedef HRESULT (WINAPI *__IStatConnector_SetTracingDevice)(IStatConnector*,
							    IStatConnectorCharacterDevice*);
typedef HRESULT (WINAPI *__IStatConnector_GetServerInformation)(IStatConnector*,
								InformationType,
								BSTR*);
typedef HRESULT (WINAPI *__IStatConnector_GetConnectorInformation)(IStatConnector*,
								   InformationType,
								   BSTR*);
typedef HRESULT (WINAPI *__IStatConnector_GetInterpreterInformation)(IStatConnector*,
								     InformationType,
								     BSTR*);

struct tagStatConnectorFactory* _IClassFactory_Create();
void _IClassFactory_Delete(struct tagStatConnectorFactory* _this);

HRESULT STDMETHODCALLTYPE
_IClassFactory_QueryInterface(struct tagStatConnectorFactory* _this,
			      REFIID riid,
			      LPVOID* ppvObj);
HRESULT STDMETHODCALLTYPE
_IClassFactory_CreateInstance(struct tagStatConnectorFactory* _this,
			      LPUNKNOWN pUnkO,
			      REFIID riid,
			      LPVOID* ppvObj);
HRESULT STDMETHODCALLTYPE
_IClassFactory_LockServer(struct tagStatConnectorFactory* _this,
			  BOOL bVal);

void _IStatConnector_loadTypeInfo(struct tagStatConnector* _this);
struct tagStatConnector* _IStatConnector_Create();
void _IStatConnector_Delete(struct tagStatConnector* _this);

HRESULT STDMETHODCALLTYPE
_IStatConnector_QueryInterface(struct tagStatConnector* _this,
			       REFIID riid,
			       LPVOID* ppvObj);
HRESULT STDMETHODCALLTYPE
_IStatConnector_Init(struct tagStatConnector* _this,
		     BSTR bstrConnectorName);
HRESULT STDMETHODCALLTYPE
_IStatConnector_Close(struct tagStatConnector* _this);
HRESULT STDMETHODCALLTYPE
_IStatConnector_GetSupportedTypes(struct tagStatConnector* _this,
				  LONG *pulTypeMask);
HRESULT STDMETHODCALLTYPE
_IStatConnector_GetSymbol(struct tagStatConnector* _this,
			  BSTR bstrSymbolName,
			  VARIANT *pvData);
HRESULT STDMETHODCALLTYPE
_IStatConnector_SetSymbol(struct tagStatConnector* _this,
			  BSTR bstrSymbolName,
			  VARIANT vData);
HRESULT STDMETHODCALLTYPE
_IStatConnector_Evaluate(struct tagStatConnector* _this,
			 BSTR bstrExpression,
			 VARIANT *pvData);
HRESULT STDMETHODCALLTYPE
_IStatConnector_EvaluateNoReturn(struct tagStatConnector* _this,
				 BSTR bstrExpression);
HRESULT STDMETHODCALLTYPE
_IStatConnector_GetErrorId(struct tagStatConnector* _this,
			   LONG *pulErrorId);
HRESULT STDMETHODCALLTYPE
_IStatConnector_GetErrorText(struct tagStatConnector* _this,
			     BSTR *pbstrErrorText);
HRESULT STDMETHODCALLTYPE
_IStatConnector_AddGraphicsDevice(struct tagStatConnector* _this,
				  BSTR bstrName,
				  ISGFX *pDevice);
HRESULT STDMETHODCALLTYPE
_IStatConnector_RemoveGraphicsDevice(struct tagStatConnector* _this,
				     BSTR bstrName);
HRESULT STDMETHODCALLTYPE
_IStatConnector_SetUserInterfaceAgent(struct tagStatConnector* _this,
				      IStatConnectorUIAgent *pUIAgent);
HRESULT STDMETHODCALLTYPE
_IStatConnector_SetCharacterOutputDevice(struct tagStatConnector* _this,
					 IStatConnectorCharacterDevice *pCharDevice);
HRESULT STDMETHODCALLTYPE
_IStatConnector_SetErrorDevice(struct tagStatConnector* _this,
			       IStatConnectorCharacterDevice *pCharDevice);
HRESULT STDMETHODCALLTYPE
_IStatConnector_SetTracingDevice(struct tagStatConnector* _this,
				 IStatConnectorCharacterDevice *pCharDevice);
HRESULT STDMETHODCALLTYPE
_IStatConnector_GetServerInformation(struct tagStatConnector* _this,
				     InformationType lInformationType,
				     BSTR *pbstrInfo);
HRESULT STDMETHODCALLTYPE
_IStatConnector_GetConnectorInformation(struct tagStatConnector* _this,
					InformationType lInformationType,
					BSTR *pbstrInfo);
HRESULT STDMETHODCALLTYPE
_IStatConnector_GetInterpreterInformation(struct tagStatConnector* _this,
					  InformationType lInformationType,
					  BSTR *pbstrInfo);
        
HRESULT _IStatConnector__ConvertErrorCode(struct tagStatConnector* _this,
					  LONG code);
HRESULT _IStatConnector__SetErrorCode(struct tagStatConnector* _this,
				      HRESULT code);
#ifdef __cplusplus
}
#endif
