/*******************************************************************************
 *  RCOM : COM Client and Server for R
 *  Copyright (C) 2003-2005 Thomas Baier
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  ---------------------------------------------------------------------------
 *
 *  $Id: com_helpers.c 1.1 2003/04/27 16:32:20 baier Exp $
 *
 ******************************************************************************/

#include <stdio.h>
#include "com_helpers.h"
#include "rcom.h"

/* Size of a CLSID as a */
const int GUID_STRING_SIZE = 39;

/* max length of a typelib name
 * maxpath for absolute physical path
 * +32 for maximal decimal number (tlib-resource id)
 * +1 for \\
 * +1 for 0x00
 */
#define _MAXTLIB_NAME    (_MAX_PATH+32+1+1)

HRESULT _C_registerTypeLib(char const* szTypeLibFullName)
{
  ITypeLib* lTypeLib = NULL;
  wchar_t wszTypeLibFullName[_MAXTLIB_NAME];
  HRESULT lHr;

  mbstowcs(wszTypeLibFullName, szTypeLibFullName, _MAXTLIB_NAME);
  lHr = LoadTypeLibEx(wszTypeLibFullName,REGKIND_REGISTER,&lTypeLib);

  if(SUCCEEDED(lHr)) {
    lTypeLib->lpVtbl->Release(lTypeLib);
    RCOM_TRACE(printf("type library \"%s\" registered successfully\n",
		      szTypeLibFullName));
  } else {
    RCOM_ERR(printf("error 0x%08x registering type library \"%s\"\n",
		    lHr,szTypeLibFullName));
  }
  return lHr;
}

HRESULT _C_loadTypeLib(REFGUID libid,
		       unsigned short wVerMajor,
		       unsigned short wVerMinor,
		       LCID lcid,
		       ITypeLib** pITypeLib,
		       char const* szTypeLibFullName)
{
  HRESULT hr;
  *pITypeLib = NULL;
  
  hr = LoadRegTypeLib(libid, wVerMajor,wVerMinor,lcid,pITypeLib);
  if (FAILED(hr) && (szTypeLibFullName != NULL)) {
    wchar_t wszTypeLibFullName[_MAXTLIB_NAME];
    RCOM_TRACE(printf("LoadRegTypeLib Failed %10lx, now trying LoadTypeLib.\n",hr));
      
    mbstowcs(wszTypeLibFullName, szTypeLibFullName, _MAXTLIB_NAME);
      
    /* if LoadTypeLib succeeds, it will have registered the type library for
     * us for the next time.
     */
    hr = LoadTypeLib(wszTypeLibFullName,pITypeLib);
    if(FAILED(hr)) {
      RCOM_ERR(printf("LoadTypeLib Failed %10lx", hr));
      return hr;
    }
    
    /*
     * NOTE: LoadTypeLib should register the TLB automatically. It fails, if
     * you supply the complete path. see PSS ID Number Q131055
     * Ensure that the type library is registered.
     */
    hr = RegisterTypeLib(*pITypeLib, wszTypeLibFullName, NULL);
    if(FAILED(hr)) {
      RCOM_ERR(printf("RegisterTypeLib Failed %10lx", hr));
      return hr;
    }
  }
  return hr;
}

HRESULT _C_freeTypeLib(ITypeLib FAR* pITypeLib)
{
  pITypeLib->lpVtbl->Release(pITypeLib);
  return S_OK;
}

HRESULT _C_getTypeInfo(REFGUID guid,
		       ITypeLib* pITypeLib,
		       ITypeInfo** pITypeInfo)
{
  /* Get type information for the interface of the object. */
  HRESULT hr = pITypeLib->lpVtbl->GetTypeInfoOfGuid(pITypeLib,
						    guid,pITypeInfo);
  if (FAILED(hr)) {
    RCOM_ERR(printf("GetTypeInfoOfGuid failed. %10lx\n", hr));
  }
  return hr;
}

/* 04-07-14 | baier | don't register EXE for starting server, if/assert */
HRESULT _C_RegisterServer(HMODULE hModule,
			  const CLSID* clsid,
			  const char* szFriendlyName,
			  const char* szVerIndProgID,
			  const char* szProgID,
			  const GUID* libid)
{
  /* Get server location. */
  char szModule[512];
  DWORD dwResult = GetModuleFileName(hModule,szModule,
				     sizeof(szModule)/sizeof(char));
  char szCLSID[GUID_STRING_SIZE];
  char szKey[80];
  
  if(dwResult == 0) {
    return E_FAIL;
  }
  
  /* Convert the CLSID into a char. */
  if(FAILED(GUID2ANSI(clsid, szCLSID, sizeof(szCLSID)))) {
    return E_FAIL;
  }
  
  /* Build the key CLSID\\{...} */
  strcpy(szKey, "CLSID\\");
  strcat(szKey, szCLSID);
  
  /* Add the CLSID to the registry. */
  setKeyAndValue(szKey, NULL, szFriendlyName,NULL);
  
  /* Add the server filename subkey under the CLSID key. */
  /*  setKeyAndValue(szKey, ("LocalServer32"), szModule,NULL); */
    
  /* Add the ProgID subkey under the CLSID key. */
  setKeyAndValue(szKey, ("ProgID"), szProgID,NULL);
  
  /* Add the version-independent ProgID subkey under CLSID key. */
  setKeyAndValue(szKey, ("VersionIndependentProgID"),szVerIndProgID,NULL);
  
  if (libid) {
    /* Add the Type Library ID subkey under the CLSID key. */
    char szLIBID[GUID_STRING_SIZE];
    if(FAILED(GUID2ANSI(libid, szLIBID, sizeof(szLIBID)))) {
      return E_FAIL;
    }
    setKeyAndValue(szKey, ("TypeLib"), szLIBID,NULL);
  }
  
  /* Add the version-independent ProgID subkey under HKEY_CLASSES_ROOT. */
  setKeyAndValue(szVerIndProgID, NULL, szFriendlyName,NULL);
  setKeyAndValue(szVerIndProgID, ("CLSID"), szCLSID,NULL);
  setKeyAndValue(szVerIndProgID, ("CurVer"), szProgID,NULL);
  
  /* Add the versioned ProgID subkey under HKEY_CLASSES_ROOT. */
  setKeyAndValue(szProgID, NULL, szFriendlyName,NULL);
  setKeyAndValue(szProgID, ("CLSID"), szCLSID,NULL);
  
  return S_OK;
}

/* 04-07-15 | baier | changed assertions to if() */
HRESULT _C_UnregisterServer(const CLSID* clsid,
			    const char* szVerIndProgID,
			    const char* szProgID)
{
  /* Convert the CLSID into a char. */
  char szCLSID[GUID_STRING_SIZE];
  char szKey[80];
  char const *pOtherServerName=NULL;

  if(FAILED(GUID2ANSI(clsid, szCLSID, sizeof(szCLSID)))) {
    return E_FAIL;
  }
  
  /* Build the key CLSID\\{...} */
  strcpy(szKey, "CLSID\\");
  strcat(szKey, szCLSID);
  
  pOtherServerName="LocalServer32";
    
  /*
   * Check for a another server for this component.
   * Note: if there  is another server type registered too, do NOT remove the CLSID, the PROGID etc.
   *       elements in the registery. just remove the server specific part and let everything
   *       else in the registery.
   */
  if (pOtherServerName && (hasRegistrySubKey(szKey, pOtherServerName))) {
    LONG lResult;
    /* Delete only the path for this server. */
    strcat(szKey, "\\LocalServer32");
    lResult = deleteRegistryKey(HKEY_CLASSES_ROOT, szKey);
    if((lResult != ERROR_SUCCESS) && (lResult != ERROR_FILE_NOT_FOUND)) {
      return E_FAIL;
    }
  } else {
    /* Delete all related keys. */
    /* Delete the CLSID Key - CLSID\{...} */
    LONG lResult = deleteRegistryKey(HKEY_CLASSES_ROOT, szKey);
    if((lResult != ERROR_SUCCESS) && (lResult != ERROR_FILE_NOT_FOUND)) {
      return E_FAIL;
    }
      
    /* Delete the version-independent ProgID Key. */
    lResult = deleteRegistryKey(HKEY_CLASSES_ROOT, szVerIndProgID);
    if((lResult != ERROR_SUCCESS) && (lResult != ERROR_FILE_NOT_FOUND)) {
      return E_FAIL;
    }
      
    /* Delete the ProgID key. */
    lResult = deleteRegistryKey(HKEY_CLASSES_ROOT, szProgID);
    if((lResult != ERROR_SUCCESS) && (lResult != ERROR_FILE_NOT_FOUND)) {
      return E_FAIL;
    }
  }
  return S_OK;
}

ULONG STDMETHODCALLTYPE _IUnknown_AddRef(struct tagUnknown* _this)
{
  _this->m_RefCount++;
  return _this->m_RefCount;
}
ULONG STDMETHODCALLTYPE _IUnknown_Release(struct tagUnknown* _this)
{
  ULONG lRefCount;

  _this->m_RefCount--;
  lRefCount = _this->m_RefCount; /* because maybe the object gets deleted */
  
  if(lRefCount < 1) {
    _this->Delete(_this);
  }
  
  return lRefCount;
}
HRESULT STDMETHODCALLTYPE _IUnknown_QueryInterface(struct tagUnknown* _this,
						   REFIID riid,
						   LPVOID* ppvObj)
{
  if(IsEqualIID(riid,&IID_IUnknown)) {
    _IUnknown_AddRef(_this);
    *ppvObj = (LPVOID) _this;
    return S_OK;
  }
  return E_NOINTERFACE;
}
HRESULT STDMETHODCALLTYPE _IDispatch_GetTypeInfoCount(struct tagDispatch* _this,
						      UINT* pctinfo)
{
  *pctinfo = 1;
  return S_OK;
}
HRESULT STDMETHODCALLTYPE _IDispatch_GetTypeInfo(struct tagDispatch* _this,
						 UINT iTInfo,
						 LCID lcid,
						 ITypeInfo** ppTInfo)
{
  *ppTInfo = 0;
  if(iTInfo != 0) {
    return DISP_E_BADINDEX;
  }
  _this->m_ptinfo->lpVtbl->AddRef(_this->m_ptinfo);
  *ppTInfo = _this->m_ptinfo;
  return S_OK;
}
HRESULT STDMETHODCALLTYPE _IDispatch_GetIDsOfNames(struct tagDispatch* _this,
						   REFIID riid,
						   LPOLESTR* rgszNames,
						   UINT cNames,
						   LCID lcid,
						   DISPID* rgDispId)
{
  return DispGetIDsOfNames(_this->m_ptinfo, rgszNames, cNames, rgDispId);;
}
HRESULT STDMETHODCALLTYPE _IDispatch_Invoke(struct tagDispatch* _this,
					    DISPID dispIdMember,
					    REFIID riid,
					    LCID lcid,
					    WORD wFlags,
					    DISPPARAMS* pDispParams,
					    VARIANT* pVarResult,
					    EXCEPINFO* pExcepInfo,
					    UINT* puArgErr)
{
  return DispInvoke(_this,_this->m_ptinfo,dispIdMember,wFlags,pDispParams,
		    pVarResult,pExcepInfo,puArgErr);
}

/* 04-07-15 | baier | renamed, if() instead of assert() */
/* 04-07-21 | baier | return S_OK on success */
HRESULT GUID2ANSI(const GUID* guid,char* szGUID,int length)
{
 LPOLESTR wszGUID = NULL;
 HRESULT hr;

 if(length < GUID_STRING_SIZE) {
   return E_FAIL;
 }

 /* Get wide string version. */
 hr = StringFromCLSID(guid, &wszGUID);
 if(FAILED(hr)) {
   return hr;
 }

 /* Covert from wide characters to non-wide. */
 wcstombs(szGUID, wszGUID, length);

 /* Free memory. */
 CoTaskMemFree(wszGUID);

 return S_OK;
}

/* 04-07-15 | baier | renamed */
LONG deleteRegistryKey(HKEY hKeyParent,           /* Parent of key to delete */
                        const char* lpszKeyChild)  /* Key to delete */
{
  /* Open the child. */
 HKEY hKeyChild;
 LONG lRes = RegOpenKeyEx(hKeyParent, lpszKeyChild, 0,KEY_ALL_ACCESS, &hKeyChild);
 FILETIME time;
 char szBuffer[256];
 DWORD dwSize = 256;
 if (lRes != ERROR_SUCCESS) {
   return lRes;
 }

 /* Enumerate all of the decendents of this child. */
 while (RegEnumKeyEx(hKeyChild, 0, szBuffer, &dwSize, NULL,NULL, NULL, &time) == S_OK)
  {
    /* Delete the decendents of this child. */
   lRes = deleteRegistryKey(hKeyChild, szBuffer);
   if (lRes != ERROR_SUCCESS)
     {
       /* Cleanup before exiting. */
      RegCloseKey(hKeyChild);
      return lRes;
     }
   dwSize = 256;
  }

 /* Close the child. */
 RegCloseKey(hKeyChild);

 /* Delete this child. */
 return RegDeleteKey(hKeyParent, lpszKeyChild);
}

/* 04-07-15 | baier | renamed */
BOOL hasRegistrySubKey (const char* pszPath,
			const char* szSubkey)
{
  HKEY hKey;
  char szKeyBuf[80];
  LONG lResult;

  /* Copy keyname into buffer. */
  strcpy(szKeyBuf, pszPath);

  /* Add subkey name to buffer. */
  if (szSubkey != NULL) {
    strcat(szKeyBuf, "\\");
    strcat(szKeyBuf, szSubkey );
  }
  
  /* Determine if key exists by trying to open it. */
  lResult = RegOpenKeyEx(HKEY_CLASSES_ROOT, szKeyBuf,0,KEY_ALL_ACCESS,&hKey);
  if (lResult == ERROR_SUCCESS) {
    RegCloseKey(hKey);
    return TRUE;
  }
  return FALSE;
}
BOOL setKeyAndValue(const char* szKey,
                    const char * szSubkey,
                    const char* szValue,
                    const char * szName)
{
  HKEY hKey;
  char szKeyBuf[1024];
  long lResult;
  /* Copy keyname into buffer. */
  strcpy(szKeyBuf, szKey);
  
  /* Add subkey name to buffer. */
  if (szSubkey != NULL) {
    strcat(szKeyBuf, "\\");
    strcat(szKeyBuf, szSubkey );
  }
  
  /* Create and open key and subkey. */
  lResult = RegCreateKeyEx(HKEY_CLASSES_ROOT ,
			   szKeyBuf,
			   0, NULL, REG_OPTION_NON_VOLATILE,
			   KEY_ALL_ACCESS, NULL,
			   &hKey, NULL);
  
  if (lResult != ERROR_SUCCESS) {
    return FALSE;
  }

  /* Set the Value. */
  if (szValue != NULL) {
    RegSetValueEx(hKey, szName, 0, REG_SZ,(BYTE *)szValue,strlen(szValue)+1);
  }

  RegCloseKey(hKey);
  return TRUE;
}
HRESULT STDMETHODCALLTYPE _IDispatch_QueryInterface(struct tagDispatch* _this,
						    REFIID riid,
						    LPVOID* ppvObj)
{
  if(IsEqualIID(riid,&IID_IDispatch)) {
    _IUnknown_AddRef((struct tagUnknown*) _this);
    *ppvObj = (LPVOID) _this;
    return S_OK;
  }
  return _IUnknown_QueryInterface((struct tagUnknown*) _this,
				  riid,ppvObj);
}
