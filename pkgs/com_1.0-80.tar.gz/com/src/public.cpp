/*******************************************************************************
 *  RCOM : COM Client and Server for R
 *  Copyright (C) 2003-2005 Thomas Baier
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) an`y later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 */

#include "rcom.h"
#include <stdio.h>
#include <olectl.h>
#include "Rinternals.h"
#include "bdx_util.h"
#include "bdx_com.h"

/* SAMPLE SESSION WITH MICROSOFT EXCEL

   library(rcom);
   excel<-comCreate("Excel.Application");
   comPropertySet(excel,"Visible",TRUE);
   wb<-comInvoke(comPropertyGet(excel,"Workbooks"),"Open","c:\\tmp\\RTS Beteiligung.xls");
   sheet<-comPropertyGet(comPropertyGet(wb,"Sheets"),"Item","Kalkulationen");
   comInvoke(sheet,"Activate");
   r1<-comPropertyGet(sheet,"Range","C5");
   r2<-comPropertyGet(sheet,"Range","C6","C8");
   r3<-comPropertyGet(sheet,"Range","C6","E8");
   r4<-comPropertyGet(sheet,"Range","C3");
   r5<-comPropertyGet(sheet,"Range","C3","E3");
*/

/* sample session with power point

   ppt<-com.object.create("PowerPoint.Application")
   presentations<-comPropertyGet(ppt,"Presentations")
   comInvoke(presentations,"Add")
   # take care: Item property is not a property!!!
   pres<-comInvoke(presentations,"Item",1)
   slides<-comPropertyGet(pres,"Slides")
   # type 12 is empty slide, 8 is chart, 2 is title+enumeration
   slide<-comInvoke(slides,"Add",2,1)
   # set the title of the slide to "Summary Information"
   title<-comPropertyGet(comPropertyGet(slide,"Shapes"),"Title")
   textrange<-comPropertyGet(comPropertyGet(title,"TextFrame"),"TextRange")
   comPropertySet(textrange,"Text","Summary Information")
   # add analysis results to slide
   enumshape<-comInvoke(comPropertyGet(slide,"Shapes"),"Item",2)
   textrange<-comPropertyGet(comPropertyGet(enumshape,"TextFrame"),"TextRange")
   comPropertySet(textrange,"Text","Text1\rText2\rTexgt3")

*/
extern "C" {

    static int isInitialized = 0;

    void com_initialize(void)
    {
	if (!isInitialized) {
	    CoInitialize (NULL);
	    isInitialized = 1;
	}
    }

/** Create a COM Object.
 *
 * Call #com_release()# when you're done with the object.
 *
 * @arg progid[0] is the program id of the COM object to create,
 *      e.g. #"Excel.Application"#
 * @return rc[0] = 0 on error, else the object handle
 */
    SEXP com_create(SEXP progid)
    {
	CLSID clsid;
	HRESULT hr;
	LPDISPATCH object = NULL;
	SEXP sexp = NULL;
	RCOM_OBJHANDLE handle = RCOM_NULLHANDLE;

	if (TYPEOF(progid) != STRSXP) {
	    RCOM_ERR(printf ("com_create(): progid not a string\n"));
	    return R_NilValue;
	}
	com_initialize();
	hr = com_getCLSID (CHAR (STRING_ELT(progid,0)),&clsid);
	if (FAILED (hr)) {
	    RCOM_ERR(printf ("com_create: failed error %08lx querying CLSID for \"%s\"\n",
			     hr,CHAR (STRING_ELT(progid,0))));
	    return R_NilValue;
	}

	void* lTmp = NULL;
	hr = CoCreateInstance (clsid,NULL,CLSCTX_SERVER,
			       IID_IDispatch,&lTmp);
	object = (LPDISPATCH) lTmp;

	if (FAILED (hr)) {
	    RCOM_ERR(printf ("com_create: failed error %08lx creating \"%s\"\n",
			     hr,CHAR (STRING_ELT(progid,0))));
	    return R_NilValue;
	}

	handle = com_addObject (object);
	sexp = com_createSEXP(handle);
	if(sexp == R_NilValue) {
	    RCOM_ERR(printf("com_create: invalid SEXP for object, releasing object\n"));
	    object->Release();
	}
	return sexp;
    }


/** Create a COM Object.
 *
 * Call #com_release()# when you're done with the object.
 *
 * @arg progid[0] is the program id of the COM object to create,
 *      e.g. #"Excel.Application"#
 * @return rc[0] = 0 on error, else the object handle
 */
    SEXP com_getobject(SEXP progid)
    {
	CLSID clsid;
	HRESULT hr;
	LPDISPATCH object = NULL;
	SEXP sexp = NULL;
	RCOM_OBJHANDLE handle = RCOM_NULLHANDLE;

	if (TYPEOF(progid) != STRSXP) {
	    RCOM_ERR(printf ("com_getobject(): progid not a string\n"));
	    return R_NilValue;
	}
	com_initialize();
	hr = com_getCLSID (CHAR (STRING_ELT(progid,0)),&clsid);
	if (FAILED (hr)) {
	    RCOM_ERR(printf ("com_getobject: failed error %08lx querying CLSID for \"%s\"\n",
			     hr,CHAR (STRING_ELT(progid,0))));
	    return R_NilValue;
	}
	{
	    IUnknown* unk;
	    hr = GetActiveObject (clsid,NULL,&unk);
	    if (FAILED (hr)) {
		RCOM_ERR(printf ("com_getobject: failed error %08lx getting \"%s\"\n",
				 hr,CHAR (STRING_ELT(progid,0))));
		return R_NilValue;
	    }
	    void* lTmp = NULL;
	    hr = unk->QueryInterface(IID_IDispatch,&lTmp);
	    object = (LPDISPATCH) lTmp;
	    if (FAILED (hr)) {
		RCOM_ERR(printf ("com_getobject: failed error %08lx querying IDispatch\n",
				 hr));
		unk->Release();
		return R_NilValue;
	    }
	    unk->Release();
	}
	handle = com_addObject (object);
	sexp = com_createSEXP(handle);
	if(sexp == R_NilValue) {
	    RCOM_ERR(printf("com_create: invalid SEXP for object, releasing object\n"));
	    object->Release();
	}
	return sexp;
    }


/** Check for a valid COM Object.
 *
 * @arg handle[0] is the object handle as returned by com_create().
 * @return rc[0] is true if handle[0] is a valid object, false
 * otherwise
 */
    SEXP com_isvalid(SEXP handle)
    {
	SEXP rc = PROTECT (allocVector (LGLSXP,1));
	if (com_getObject (com_getHandle(handle)) != RCOM_NULLHANDLE) {
	    LOGICAL(rc)[0] = 1;
	} else {
	    LOGICAL(rc)[0] = 0;
	}
	UNPROTECT(1);
	return rc;
    }

/** Set a Property.
 *
 * @arg handle is the object handle as returned by com_create().
 * @arg property is the name of the property
 * @arg value is the new property value
 *
 * 06-11-01 | baier | multiple parameters for property set 
 *                    code contributed by Joachim Loebb
 *                    (mailto:Joachim.Loebb@access.unizh.ch)
 * 07-01-15 | baier | free VARIANT/call VariantClear() 
 */
    SEXP com_property_set(SEXP handle,SEXP property,SEXP value)
    {
	VARIANTARG* _var = NULL;
	DISPID propid = 0;
	DISPID dspput = DISPID_PROPERTYPUT;
	HRESULT hr;
	LPDISPATCH dsp;
	DISPPARAMS _value = {
	    NULL,
	    &dspput,
	    1,
	    1
	};

	dsp = com_getObject (com_getHandle (handle));
	if (dsp == NULL) {
	    RCOM_ERR(printf("com_property_set: handle not valid\n"));
	    return R_NilValue;
	}
	if (TYPEOF (property) != STRSXP) {
	    RCOM_ERR(printf("com_property_set: property name not a string\n"));
	    return R_NilValue;
	}
	hr = com_GetIDsOfName (dsp,CHAR(STRING_ELT(property,0)),&propid);
	if (FAILED(hr)) {
	    RCOM_ERR(printf("com_property_set: property \"%s\" not found (%08lx)\n",
			    CHAR(STRING_ELT(property,0)),hr));
	    return R_NilValue;
	}
	int argc = 0;
	if (value == R_NilValue) {
	    RCOM_TRACE(printf("com_property_set: no parameters\n"));
	    return R_NilValue;
	} else if (TYPEOF(value) == VECSXP) {
	    /*    RCOM_TRACE(printf("com_property_set: list of arguments, counting parameters\n"));*/
	    argc = Rf_length(value);
	    /*    RCOM_TRACE(printf("com_property_set: %d parameters for function counted\n",
		  argc));*/
	} else {
	    /*    RCOM_TRACE(printf("com_property_set: single parameter, type %d\n",TYPEOF(value))); */
	    com_trace(value);
	    argc = 1;
	}
	if (argc == 0) {
	    _var = NULL;
	} else {
	    _var = (VARIANTARG*) malloc(sizeof(VARIANTARG) * argc);
	    for (int i = 0;i < argc;i++) {
		VariantInit(&_var[argc-i-1]);
		/*      RCOM_TRACE(printf("Converting argument %d to VARIANT\n",i)); */
		if (!SEXP2Variant(VECTOR_ELT(value,i),&_var[argc-i-1])) {
		    RCOM_ERR(printf("com_property_set: conversion of parameter %d to variant failed\n",
				    i));
		    /* release all VARIANT parameters successfully converted */
		    while(i) {
			VariantClear(&_var[argc-i-2]);
			i--;
		    }
		    free(_var);
		    return R_NilValue;
		}
	    }
	}
	_value.rgvarg = _var;
	_value.cArgs = argc;
	hr = dsp->Invoke(propid,IID_NULL,LOCALE_USER_DEFAULT,DISPATCH_PROPERTYPUT,
			 &_value,NULL,NULL,NULL);
	if(argc > 0) {
	    for(int i = 0;i < argc;i++) {
		VariantClear(&_var[i]);
	    }
	    free(_var);
	}
	if (FAILED (hr)) {
	    RCOM_ERR(printf("com_property_set: error %08lx setting property \"%s\"\n",
			    hr,CHAR(STRING_ELT(property,0))));
	    return R_NilValue;
	}
	return R_NilValue;
    }

    int is_out_par(LPDISPATCH dsp,DISPID method, DISPID var){
    
	// ITypeInfo* typeinfo = 0;
	// hr = dsp->GetTypeInfo(0,LOCALE_USER_DEFAULT,&typeinfo);
	// if(FAILED(hr)) {
	//   RCOM_ERR(printf("com_object_trace: failed %8x GetTypeInfo()\n",hr));
	//   return 0;
	// }
	// FUNCDESC* funcdesc = 0;
	//   /*    RCOM_TRACE(printf("  function #%d:\n",i)); */
	// hr = typeinfo->GetFuncDesc(i,&funcdesc);
	// if(FAILED(hr)) {
	//     RCOM_ERR(printf("com_object_trace: error %8x retrieving description for function %d\n",hr,i));
	//     return 0;
	// }
    
	return 1;
    }

/** Get a Property.
 *
 * @arg handle is the object handle as returned by com_create().
 * @arg property is the name of the property
 * @arg index is the name/index for a collection element (e.g. Item property)
 *
 * 05-06-13 | baier | reversed order for anonymous parameters 
 * 07-01-15 | baier | free VARIANT/call VariantClear() 
 */
    SEXP com_property_get(SEXP handle,SEXP property,SEXP index)
    {
	VARIANT _result;
	DISPID propid = 0;
	VARIANTARG* _var = NULL;
	HRESULT hr;
	LPDISPATCH dsp;
	DISPPARAMS _value = {
	    NULL,
	    NULL,
	    0,
	    0
	};
	SEXP result = NULL;

	dsp = com_getObject (com_getHandle (handle));
	/*  RCOM_TRACE(printf("com_property_get(%p,\"%s\")\n",
	    dsp,CHAR(STRING_ELT(property,0))));*/
	if (dsp == NULL) {
	    RCOM_ERR(printf ("com_property_get: handle not valid\n"));
	    return R_NilValue;
	}
	if (TYPEOF (property) != STRSXP) {
	    RCOM_ERR(printf ("com_property_get: property name not a string\n"));
	    return R_NilValue;
	}
	hr = com_GetIDsOfName (dsp,CHAR(STRING_ELT(property,0)),&propid);
	if (FAILED(hr)) {
	    RCOM_ERR(printf ("com_property_get: property \"%s\" not found (%08lx)\n",
			     CHAR(STRING_ELT(property,0)),hr));
	    return R_NilValue;
	}
	int argc = 0;
	if (index == R_NilValue) {
	    RCOM_TRACE(printf("com_property_get: no parameters\n"));
	    argc = 0;
	} else if (TYPEOF(index) == VECSXP) {
	    /*    RCOM_TRACE(printf ("com_property_get: list of arguments, counting parameters\n")); */
	    argc = Rf_length(index);
	    /*    RCOM_TRACE(printf("com_property_get: %d parameters for function counted\n",
		  argc));*/
	} else {
	    /*    RCOM_TRACE(printf("com_property_get: single parameter, type %d\n",TYPEOF(index)));*/
	    com_trace(index);
	    argc = 1;
	}
	if (argc == 0) {
	    _var = NULL;
	} else {
	    _var = (VARIANTARG*) malloc(sizeof(VARIANTARG) * argc);
	    for (int i = 0;i < argc;i++) {
		VariantInit(&_var[argc-i-1]);
		/*      RCOM_TRACE(printf("Converting argument %d to VARIANT\n",i)); */
		if (!SEXP2Variant(VECTOR_ELT(index,i),&_var[argc-i-1])) {
		    RCOM_ERR(printf("com_property_get: conversion of parameter %d to variant failed\n",
				    i));
		    /* release all VARIANT parameters successfully converted */
		    while(i) {
			VariantClear(&_var[argc-i-2]);
			i--;
		    }
		    free(_var);
		    return R_NilValue;
		}
	    }
	}
	_value.rgvarg = _var;
	_value.cArgs = argc;
	VariantInit(&_result);
	hr = dsp->Invoke(propid,IID_NULL,LOCALE_USER_DEFAULT,DISPATCH_PROPERTYGET,
			 &_value,&_result,NULL,NULL);
	if (argc > 0) {
	    for(int i = 0;i < argc;i++) {
		VariantClear(&_var[i]);
	    }
	    free(_var);
	}
	if (FAILED (hr)) {
	    RCOM_ERR(printf ("com_property_get: error %08lx getting property \"%s\"\n",
			     hr,CHAR(STRING_ELT(property,0))));
	    return R_NilValue;
	}
	if (!Variant2SEXP (&_result,&result)) {
	    RCOM_ERR(printf ("com_property_get: conversion to SEXP failed\n"));
	    return R_NilValue;
	}
	VariantClear (&_result);
	return result;
    }

/** Call a COM Method.
 *
 * @arg handle is the object handle as returned by com_create().
 * @arg method is the name of the method to invoke
 * @arg property is the name of the property
 *
 * 04-07-04 | baier | better information on errors
 * 04-07-05 | baier | positional arguments in reversed order!
 * 06-10-28 | baier | implementation of named arguments 
 * 07-01-15 | baier | free VARIANT/call VariantClear() 
 */
// 13-06-03 invoke DISPATCH_METHOD  has changed to DISPATCH_METHOD | DISPATCH_PROPERTYGET
    SEXP com_invoke(SEXP handle,SEXP method,SEXP args)
    {
	VARIANT _result;
	VARIANTARG* _var = NULL; //, *_var1 = NULL;
	HRESULT hr = S_OK;
	LPDISPATCH dsp;
	DISPPARAMS _value = {
	    NULL,
	    NULL, /* &dspput, */
	    0, /* 1, */
	    0 /* 1 */
	};
	SEXP result = NULL;
	unsigned int argErr;

	dsp = com_getObject (com_getHandle (handle));
	if (dsp == NULL) {
	    RCOM_ERR(printf ("com_invoke: handle not valid\n"));
	    return R_NilValue;
	}
	/*  RCOM_TRACE(printf("com_invoke: IDispatch: %08x\n",dsp)); */
	if (TYPEOF (method) != STRSXP) {
	    RCOM_ERR(printf ("com_invoke: method name not a string\n"));
	    return R_NilValue;
	}

	/* prepare parameters: count and allocate variant data for all parameters */
	int argc = 0;
	OLECHAR** lUCParameterName = NULL;
	SEXP lParameterName;
	DISPID* lParameterIDs = NULL;
	int i;
	int lNamedParameterCount = 0;
	SEXP lParameterNames = R_NilValue;
	int protCnt=0;

	if (args == R_NilValue) {
	    RCOM_TRACE(printf("com_invoke: no parameters\n"));
	    argc = 0;
	} else if (TYPEOF(args) == VECSXP) {
	    argc = Rf_length(args);
	    lParameterNames = PROTECT(getAttrib(args,R_NamesSymbol)); protCnt++;
	} else {
	    com_trace(args);
	    argc = 1;
	}
	if (argc == 0) {
	    _var = NULL;
	} else {
	    _var = (VARIANTARG*) malloc(sizeof(VARIANTARG) * argc);
	    // P.V. 2008 11 25 _var1 for BYREF data
	    // _var1 = (VARIANTARG*) malloc(sizeof(VARIANTARG) * argc);

	    /* count named parameters first */
	    if(TYPEOF(lParameterNames) != NILSXP) {
		for(i = 0;i < argc;i++) {
		    lParameterName = STRING_ELT(lParameterNames,i);
		    if((TYPEOF(lParameterName) == CHARSXP)
		       && (CHAR(lParameterName)[0] != 0x0)) {
			lNamedParameterCount++;
		    }
		}
	    }
	}

#if 0
	///
	RCOM_TRACE(printf("com_invoke: %d named parameters, %d positional parameters",
			  lNamedParameterCount,
			  argc - lNamedParameterCount));
#endif

	/* we now know the number of positional and named parameters (if any) */
	lUCParameterName = (OLECHAR**) calloc(lNamedParameterCount + 1,
					      sizeof(OLECHAR*));
	lParameterIDs = (DISPID*) calloc(lNamedParameterCount + 1,
					 sizeof(DISPID));

	lUCParameterName[0] = com_getOLECHAR(CHAR(STRING_ELT(method,0)));

	if(lNamedParameterCount > 0) {
	    /* parameter names/DISPIDs array for GetIDsOfNames() */
	    int lIdx = 1;
    
	    /* init parameter names */
	    for(i = 0;i < argc;i++) {
		lParameterName = STRING_ELT(lParameterNames,i);
		if((TYPEOF(lParameterName) == CHARSXP)
		   && CHAR(lParameterName)[0] != 0x0) {
		    lUCParameterName[lIdx] = com_getOLECHAR(CHAR(lParameterName));
		    lIdx++;
		}
	    }
	    /* we're done, check this */
	    if(lIdx != (lNamedParameterCount + 1)) {
		hr = E_FAIL;
		RCOM_TRACE(printf("com_invoke: internal error, checked %d named parameters, should be %d\n",
				  lIdx - 1,lNamedParameterCount));
	    }
	}

	/* get DISPIDs of method and parameter names */
	hr = dsp->GetIDsOfNames(IID_NULL,lUCParameterName,
				lNamedParameterCount + 1,
				LOCALE_USER_DEFAULT,lParameterIDs);
	if(FAILED(hr)) {
	    RCOM_TRACE(printf("com_invoke: error %08x retrieving DISPIDs for %d named parameters or method \"%s\" not found\n",
			      hr,lNamedParameterCount,CHAR(STRING_ELT(method,0))));
	} else {
	    /*
	     * Named parameters parsed, checked DISPIDs, now build DISPPARAMS from
	     * named and positional parameters:
	     *
	     * First lNamedParameterCount elements are named parameters, corresponding
	     * with the DISPIDs in lParameterIDs. Starting with index
	     * lNamedParameterCount, positional parameters are passed. Positional
	     * parameters are in reversed order, last parameter being at index
	     * lNamedParameterCount.
	     */
	    int lNamedIdx = 0;
	    int lPositionalIdx = argc - 1;
	    int lIdx;//,isout;
	    VARIANTARG * ptr;

	    for(i = 0;i < argc;i++) {
		lIdx = -1;
		//isout= -1;
		/* is this parameter named or positional? */
		if(lNamedParameterCount) {
		    lParameterName = STRING_ELT(lParameterNames,i);
		    if((TYPEOF(lParameterName) == CHARSXP)
		       && CHAR(lParameterName)[0] != 0x0) {
			/* named parameter */
			lIdx = lNamedIdx++;
			// isout = is_out_par(dsp,lParameterIDs[0],lParameterIDs[lIdx+1]);
		    }
		} 

		if(lIdx < 0) {
		    /* positional: reversed order */
		    lIdx = lPositionalIdx--;
		}
#if 0
		///
		RCOM_TRACE(printf("com_invoke: storing parameter %d at index %d\n",
				  i,lIdx));
#endif
		VariantInit(&(_var[lIdx]));
		// VariantInit(&(_var1[lIdx]));
      
		// if(isout==1) {
		//     ptr = &(_var1[lIdx]);
		//     if (!SEXP2Variant(VECTOR_ELT(args,i),ptr)) {
		// 	RCOM_ERR(printf("com_invoke: conversion of parameter %d to variant failed\n",
		// 			i));
		// 	/* @@release all VARIANT parameters successfully converted */
		// 	hr = E_FAIL;
		//     }
      
		//     V_VT(&(_var[lIdx])) = V_VT(ptr) | VT_BYREF;
		//     V_BYREF(&(_var[lIdx])) = &(V_BYREF(ptr));
		// } 
		// else {
		    ptr=&(_var[lIdx]);
      
		    if (!SEXP2Variant(VECTOR_ELT(args,i),ptr)) {
			RCOM_ERR(printf("com_invoke: conversion of parameter %d to variant failed\n",
					i));
			/* @@release all VARIANT parameters successfully converted */
			hr = E_FAIL;
			//}
		}
	    }
	}
	if(SUCCEEDED(hr)) {
	    _value.rgvarg = _var;
	    _value.cArgs = argc;
	    _value.rgdispidNamedArgs = &(lParameterIDs[1]);
	    _value.cNamedArgs = lNamedParameterCount;
    
	    VariantInit(&_result);
	    hr = dsp->Invoke(lParameterIDs[0],IID_NULL,LOCALE_USER_DEFAULT,
			     DISPATCH_METHOD | DISPATCH_PROPERTYGET,
			     &_value,&_result,NULL,&argErr);
	}
//	SEXP res_attr,elm;
	if (argc > 0) {
	    //    PROTECT(res_attr=allocVector(VECSXP,argc));
	    for(int i = 0;i < argc;i++) {
		//if(V_ISBYREF(&_var[i])){
		//   Variant2SEXP (&_var1[i],&elm);
		//    SET_VECTOR_ELT(res_attr,i,elm);
		//}
		VariantClear(&_var[i]);
		//VariantClear(&_var1[i]);
	    }
//	    free(_var1);
	    free(_var);
	}
	/* release all memory */
	for(i = 0;i <= lNamedParameterCount;i++) {
	    free(lUCParameterName[i]);
	}
	free(lParameterIDs);
	free(lUCParameterName);

	if(FAILED(hr)) {
	    switch(hr) {
		case DISP_E_TYPEMISMATCH:
		    RCOM_ERR(printf ("com_invoke: \"type mismatch\" for parameter #%d invoking method \"%s\"\n",
				     argErr,CHAR(STRING_ELT(method,0))));
		    break;
		case DISP_E_BADPARAMCOUNT:
		    RCOM_ERR(printf("com_invoke: \"bad parameter count\" invoking method \"%s\"\n",
				    CHAR(STRING_ELT(method,0))));
		    break;
		case DISP_E_BADVARTYPE:
		    RCOM_ERR(printf("com_invoke: \"bad variant type\" invoking method \"%s\"\n",
				    CHAR(STRING_ELT(method,0))));
		    break;
		case DISP_E_PARAMNOTFOUND:
		    RCOM_ERR(printf("com_invoke: \"parameter not found\" for parameter #%d invoking method \"%s\"\n",
				    argErr,CHAR(STRING_ELT(method,0))));
		    break;
		case DISP_E_OVERFLOW:
		    RCOM_ERR(printf("com_invoke: \"overflow\" invoking method \"%s\"\n",
				    CHAR(STRING_ELT(method,0))));
		    break;
		default:
		    RCOM_ERR(printf ("com_invoke: error %08lx invoking method \"%s\"\n",
				     hr,CHAR(STRING_ELT(method,0))));
	    }
	    if(protCnt) UNPROTECT(protCnt); 
	    return R_NilValue;
	}
	if(!Variant2SEXP (&_result,&result)) {
	    RCOM_ERR(printf ("com_invoke: conversion of result to SEXP failed\n"));
	    if(protCnt) UNPROTECT(protCnt); 
	    return R_NilValue;
	}
	VariantClear(&_result);
	//setAttrib(result,install("retval"),res_attr);
	//UNPROTECT(1);
	if(protCnt) UNPROTECT(protCnt); 
	return result;
    }

/*
** 07-07-30 | baier | now (char const*) instead of (char*)
*/
    HRESULT com_GetIDsOfName(LPDISPATCH dsp,char const* name,DISPID* dispid)
    {
	HRESULT hr;
	OLECHAR* _name = com_getOLECHAR (name);
	if (_name == NULL) {
	    RCOM_ERR(printf ("com_GetIDsOfName: \"%s\" not a valid string\n",name));
	    return E_FAIL;
	}
	hr = dsp->GetIDsOfNames(IID_NULL,&_name,1,LOCALE_USER_DEFAULT,dispid);
	free (_name); _name = NULL;
	return hr;
    }


    void com_trace_object(int level,LPDISPATCH obj)
    {
	ITypeInfo* typeinfo = NULL;
	HRESULT hr = E_FAIL;

	hr = obj->GetTypeInfo(0,LOCALE_USER_DEFAULT,&typeinfo);
	if(FAILED(hr)) {
	    RCOM_ERR(printf("com_trace_object(): GetTypeInfo() returns failure code %08lx\n",
			    hr));
	    return;
	}
	typeinfo->Release();
	/* properties first */
    }


/*
** 07-08-23 | TB | reworked for R 2.6
*/
    SEXP com_trace_internal (int level,SEXP sexp)
    {
	char const* structtype = NULL;
	int length = 0;
	int dims = 0;

	if(sexp == R_NilValue) {
	    RCOM_ERR(printf("(%d) SEXP is R_NilValue\n",level));
	    return R_NilValue;
	}
	RCOM_ERR(printf("(%d) SEXP is %p\n",level,sexp));

	if (Rf_length (sexp) == 0) {
	    RCOM_ERR(printf ("(%d) SEXP has length 0 -- invalid\n",level));
	    return R_NilValue;
	} else if (Rf_length (sexp) == 1) {
	    structtype = "scalar";
	    length = 1;
	    dims = 1;
	} else {
	    RCOM_ERR(printf("(%d) checking SEXP, length is %d, type %d\n",
			    level,Rf_length(sexp),TYPEOF(sexp)));
	    SEXP dim = getAttrib (sexp,R_DimSymbol);
	    length = Rf_length (sexp);
	    if (TYPEOF (dim) == NILSXP) {
		RCOM_ERR(printf("dim is NILSXP"));
		structtype = "vector";
		dims = Rf_length (sexp);
	    } else {
		RCOM_ERR(printf("dim is not NILSXP"));
		structtype = "matrix";
		dims = INTEGER (dim)[0];
	    }
	}
	RCOM_ERR(printf ("(%d) SEXP is a %s, %d elements, %d dimensions\n",level,structtype,
			 length,dims));
	switch (TYPEOF(sexp)) {
	    case NILSXP:
		RCOM_ERR(printf ("(%d) SEXP is of type NILSXP\n",level));
		return R_NilValue;
	    case LGLSXP:
		RCOM_ERR(printf ("(%d) SEXP is of type LGLSXP, value %s\n",level,
				 LOGICAL (sexp)[0] ? "TRUE" : "FALSE"));
		break;
	    case INTSXP:
		RCOM_ERR(printf ("(%d) SEXP is of type INTSXP, value %d\n",level,INTEGER (sexp)[0]));
		break;
	    case REALSXP:
		RCOM_ERR(printf ("(%d) SEXP is of type REALSXP, value %f\n",level,REAL (sexp)[0]));
		break;
	    case STRSXP:
		RCOM_ERR(printf ("(%d) SEXP is of type STRSXP, value \"%s\"\n",level,CHAR(STRING_ELT(sexp,0))));
		break;
	    case VECSXP:
	    {
		int i;
		RCOM_ERR(printf ("(%d) SEXP is of type VECSXP, now tracing contents\n",level));
		for (i = 0;i < Rf_length (sexp);i++) {
		    com_trace_internal (level+1,VECTOR_ELT (sexp,i));
		}
	    }
	    break;
	    case EXTPTRSXP:
	    {
		/* is it a COM object? */
		RCOM_OBJHANDLE handle = com_getHandle (sexp);
		if (handle != RCOM_NULLHANDLE) {
		    /* valid COM object */
		    RCOM_ERR(printf ("(%d) SEXP is of type EXTPTRSXP, is a valid COM handle (%p, %p)\n",level,
				     handle,com_getObject (handle)));
		    com_trace_object(level,com_getObject(handle));
		} else {
		    /* plain external pointer */
		    RCOM_ERR(printf ("(%d) SEXP is of type EXTPTRSXP, value %p\n",
				     level,R_ExternalPtrAddr(sexp)));
		}
	    }
	    break;
	    case CPLXSXP:
		RCOM_ERR(printf ("(%d) SEXP is of type CPLXSXP\n",level));
		break;
	    default:
		RCOM_ERR(printf ("(%d) SEXP is of unknown type %d\n",level,TYPEOF (sexp)));
		return R_NilValue;
	}
	return R_NilValue;
    }

    SEXP com_trace(SEXP sexp)
    {
	return com_trace_internal (0,sexp);
    }


    void my_finalizer(SEXP sexp)
    {
	if(TYPEOF(sexp) != EXTPTRSXP) {
	    RCOM_ERR(printf("my_finalizer() called for non-pointer SEXP\n"));
	} else {
	    RCOM_TRACE(printf("my_finalizer() called for pointer at %p\n",
			      R_ExternalPtrAddr(sexp)));
	}
    }

    char* get_elem_desc(ELEMDESC* desc)
    {
	char tmp[1024];
	char tmp2[1024];
	switch(desc->tdesc.vt) {
	    case VT_EMPTY: sprintf(tmp,"VT_EMPTY"); break;
	    case VT_NULL: sprintf(tmp,"VT_NULL"); break;
	    case VT_I2: sprintf(tmp,"short"); break;
	    case VT_I4: sprintf(tmp,"int"); break;
	    case VT_R4: sprintf(tmp,"real"); break;
	    case VT_R8: sprintf(tmp,"double"); break;
	    case VT_CY: sprintf(tmp,"CURRENCY"); break;
	    case VT_DATE: sprintf(tmp,"DATE"); break;
	    case VT_BSTR: sprintf(tmp,"BSTR"); break;
	    case VT_DISPATCH: sprintf(tmp,"LPDISPATCH"); break;
	    case VT_ERROR: sprintf(tmp,"VT_ERROR"); break;
	    case VT_BOOL: sprintf(tmp,"VARIANT_BOOL"); break;
	    case VT_VARIANT: sprintf(tmp,"VARIANT"); break;
	    case VT_DECIMAL: sprintf(tmp,"DECIMAL"); break;
	    case VT_RECORD: sprintf(tmp,"VT_RECORD"); break;
	    case VT_UNKNOWN: sprintf(tmp,"VT_UNKNOWN"); break;
	    case VT_I1: sprintf(tmp,"char"); break;
	    case VT_UI1: sprintf(tmp,"unsigned char"); break;
	    case VT_UI2: sprintf(tmp,"unsigned short"); break;
	    case VT_UI4: sprintf(tmp,"unsigned long"); break;
	    case VT_INT: sprintf(tmp,"int"); break;
	    case VT_UINT: sprintf(tmp,"unsigned int"); break;
	    case VT_VOID: sprintf(tmp,"void"); break;
	    case VT_HRESULT: sprintf(tmp,"HRESULT"); break;
	    case VT_PTR: sprintf(tmp,"POINTER"); break;
	    case VT_SAFEARRAY: sprintf(tmp,"SAFEARRAY"); break;
	    case VT_USERDEFINED: sprintf(tmp,"VT_USERDEFINED"); break;
	    case VT_LPSTR: sprintf(tmp,"LPSTR"); break;
	    case VT_LPWSTR: sprintf(tmp,"LPWSTR"); break;
	    case VT_FILETIME: sprintf(tmp,"FILETIME"); break;
	    case VT_BLOB: sprintf(tmp,"BLOB"); break;
	    case VT_STREAM: sprintf(tmp,"STREAM"); break;
	    case VT_STORAGE: sprintf(tmp,"STORAGE"); break;
	    case VT_STREAMED_OBJECT: sprintf(tmp,"STREAMED_OBJECT"); break;
	    case VT_STORED_OBJECT: sprintf(tmp,"STORED_OBJECT"); break;
	    case VT_BLOB_OBJECT: sprintf(tmp,"BLOB_OBJECT"); break;
	    case VT_CF: sprintf(tmp,"CLIPFORMAT"); break;
	    case VT_CLSID: sprintf(tmp,"CLSID"); break;
	    case VT_VECTOR: sprintf(tmp,"VECTOR"); break;
	    case VT_ARRAY: sprintf(tmp,"ARRAY"); break;
	    case VT_BYREF: sprintf(tmp,"VT_BYREF"); break;
	    case VT_RESERVED: sprintf(tmp,"VT_RESERVED"); break;
	    default: sprintf(tmp,"unknown type"); break;
	}
	char params[1024];
	strcpy(params,"");
	if(desc->paramdesc.wParamFlags != PARAMFLAG_NONE) {
	    int first = 1;
	    if((desc->paramdesc.wParamFlags & PARAMFLAG_FIN) == PARAMFLAG_FIN) {
		if(first) {
		    sprintf(params,"in");
		    first = 0;
		} else {
		    sprintf(params,"%s,in",params);
		}
	    }
	    if((desc->paramdesc.wParamFlags & PARAMFLAG_FOUT) == PARAMFLAG_FOUT) {
		if(first) {
		    sprintf(params,"out");
		    first = 0;
		} else {
		    sprintf(params,"%s,out",params);
		}
	    }
	    if((desc->paramdesc.wParamFlags & PARAMFLAG_FRETVAL) == PARAMFLAG_FRETVAL) {
		if(first) {
		    sprintf(params,"retval");
		    first = 0;
		} else {
		    sprintf(params,"%s,retval",params);
		}
	    }
	    if((desc->paramdesc.wParamFlags & PARAMFLAG_FOPT) == PARAMFLAG_FOPT) {
		if(first) {
		    sprintf(params,"optional");
		    first = 0;
		} else {
		    sprintf(params,"%s,optional",params);
		}
	    }
	    if((desc->paramdesc.wParamFlags & PARAMFLAG_FHASDEFAULT) == PARAMFLAG_FHASDEFAULT) {
		if(first) {
		    sprintf(params,"hasdefault");
		    first = 0;
		} else {
		    sprintf(params,"%s,hasdefault",params);
		}
	    }
	    sprintf(tmp2,"[%s] %s",params,tmp);
	    strcpy(tmp,tmp2);
	}
	return strdup(tmp);
    }

    SEXP com_object_trace(SEXP handle)
    {
	LPDISPATCH dsp = com_getObject (com_getHandle (handle));
	HRESULT hr;
	if (dsp == NULL) {
	    RCOM_ERR(printf ("com_object_trace: handle not valid\n"));
	    return R_NilValue;
	}
	ITypeInfo* typeinfo = 0;

	hr = dsp->GetTypeInfo(0,LOCALE_USER_DEFAULT,&typeinfo);
	if(FAILED(hr)) {
	    RCOM_ERR(printf("com_object_trace: failed %8x GetTypeInfo()\n",hr));
	    return R_NilValue;
	}
	TYPEATTR* attr = 0;
	hr = typeinfo->GetTypeAttr(&attr);
	if(FAILED(hr)) {
	    RCOM_ERR(printf("com_object_trace: failed %8x getting TYPEATTR\n",hr));
	    typeinfo->Release();
	}
	/* trace global type attributes/information */
	RCOM_ERR(printf("COM object information:\n"));
	RCOM_ERR(printf("  type kind: "));
	switch(attr->typekind) {
	    case TKIND_ENUM: RCOM_ERR(printf("TKIND_ENUM\n")); break;
	    case TKIND_RECORD: RCOM_ERR(printf("TKIND_RECORD\n")); break;
	    case TKIND_MODULE: RCOM_ERR(printf("TKIND_MODULE\n")); break;
	    case TKIND_INTERFACE: RCOM_ERR(printf("TKIND_INTERFACE\n")); break;
	    case TKIND_DISPATCH: RCOM_ERR(printf("TKIND_DISPATCH\n")); break;
	    case TKIND_COCLASS: RCOM_ERR(printf("TKIND_COCLASS\n")); break;
	    case TKIND_ALIAS: RCOM_ERR(printf("TKIND_ALIAS\n")); break;
	    case TKIND_UNION: RCOM_ERR(printf("TKIND_UNION\n")); break;
	    case TKIND_MAX: RCOM_ERR(printf("TKIND_MAX\n")); break;
	    default: RCOM_ERR(printf("unknown\n")); break;
	}
	RCOM_ERR(printf("  implemented interfaces: %d\n",attr->cImplTypes));
	RCOM_ERR(printf("  number of functions:    %d\n",attr->cFuncs));
	RCOM_ERR(printf("  number of variables:    %d\n",attr->cVars));
	/* trace functions */
	int i=0;
	for(i = 0;i < attr->cFuncs;i++) {
	    FUNCDESC* funcdesc = 0;
	    /*    RCOM_TRACE(printf("  function #%d:\n",i)); */
	    hr = typeinfo->GetFuncDesc(i,&funcdesc);
	    if(FAILED(hr)) {
		RCOM_ERR(printf("com_object_trace: error %8x retrieving description for function %d\n",hr,i));
	    } else {
		BSTR docbstr = NULL;
		hr = typeinfo->GetDocumentation(funcdesc->memid,NULL,&docbstr,NULL,NULL);
		char* docstr = NULL;
		if(SUCCEEDED(hr) && docbstr) {
		    docstr = BSTR2ANSI(docbstr);
		    SysFreeString(docbstr);
		} else {
		    docstr = NULL;
		}
		{
		    int j;
		    unsigned int cnt;
		    BSTR names[funcdesc->cParams+1];
		    for(j = 0;j < funcdesc->cParams+1;j++) names[j] = NULL;
		    hr = typeinfo->GetNames(funcdesc->memid,names,funcdesc->cParams+1,&cnt);
		    if(FAILED(hr)) {
			RCOM_ERR(printf("com_object_trace: failed %8x retrieving %d names for member id %d\n",
					hr,funcdesc->cParams+1,funcdesc->memid));
		    } else {
			char* funcname = BSTR2ANSI(names[0]);
			RCOM_ERR(printf("  [id(%d)",
					funcdesc->memid));
			switch(funcdesc->invkind) {
			    case INVOKE_FUNC: break;
			    case INVOKE_PROPERTYGET: RCOM_ERR(printf(", propget")); break;
			    case INVOKE_PROPERTYPUT: RCOM_ERR(printf(", propput")); break;
			    case INVOKE_PROPERTYPUTREF: RCOM_ERR(printf(", propputref")); break;
			    default: RCOM_ERR(printf(", >>unknown<<\n"));
			}
			if(docstr) {
			    RCOM_ERR(printf(", helpstring(\"%s\")",docstr));
			    free(docstr);
			}
			char* tmp = get_elem_desc(&funcdesc->elemdescFunc);
			RCOM_ERR(printf("] %s %s(",tmp,funcname));
			free(tmp);
			free(funcname);
			SysFreeString(names[0]);
			for(j = 1;j < (int) cnt;j++) {
			    funcname = BSTR2ANSI(names[j]);
			    tmp = get_elem_desc(&funcdesc->lprgelemdescParam[j-1]);
			    RCOM_ERR(printf("%s %s",tmp,funcname));
			    free(tmp);
			    if(j < ((int) cnt) -1) RCOM_ERR(printf(","));
			    free(funcname);
			    SysFreeString(names[j]);
			}
			RCOM_ERR(printf(")\n"));
		    }
		}
		typeinfo->ReleaseFuncDesc(funcdesc);
	    }
	}
	/* trace variables */
	/*  for(i = 0;i < attr->cFuncs;i++) {
	    }*/
	typeinfo->ReleaseTypeAttr(attr);
	typeinfo->Release();
	return R_NilValue;
    }


/*
** 07-08-23 | TB | reworked for R 2.6
*/
    SEXP com_object_getinfo(SEXP handle)
    {
	int protCnt = 0;
	LPDISPATCH dsp = com_getObject (com_getHandle (handle));
	HRESULT hr;
	if (dsp == NULL) {
	    RCOM_ERR(printf ("com_object_trace: handle not valid\n"));
	    return R_NilValue;
	}
	ITypeInfo* typeinfo = 0;

	hr = dsp->GetTypeInfo(0,LOCALE_USER_DEFAULT,&typeinfo);
	if(FAILED(hr)) {
	    RCOM_ERR(printf("com_object_trace: failed %8x GetTypeInfo()\n",hr));
	    return R_NilValue;
	}
	TYPEATTR* attr = 0;
	hr = typeinfo->GetTypeAttr(&attr);
	if(FAILED(hr)) {
	    RCOM_ERR(printf("com_object_trace: failed %8x getting TYPEATTR\n",hr));
	    typeinfo->Release();
	    return R_NilValue;
	}
	/* number of functions to put in array: attr->cFuncs */
	SEXP rc = PROTECT(allocVector(VECSXP,attr->cFuncs));
	SEXP namesattribute = PROTECT(allocVector(STRSXP,attr->cFuncs));
	protCnt++;
	protCnt++;
	/* init the member names: "name", "description", "return", "parameters" */
	SEXP membnamesattribute = PROTECT(allocVector(STRSXP,4));
	protCnt++;
	{
	    SET_STRING_ELT(membnamesattribute,0,mkChar("name"));
	    SET_STRING_ELT(membnamesattribute,1,mkChar("description"));
	    SET_STRING_ELT(membnamesattribute,2,mkChar("return"));
	    SET_STRING_ELT(membnamesattribute,3,mkChar("parameters"));
	}

	/* add an entry for each function */
	int i=0;
	for(i = 0;i < attr->cFuncs;i++) {
	    FUNCDESC* funcdesc = 0;
	    hr = typeinfo->GetFuncDesc(i,&funcdesc);
	    if(FAILED(hr)) {
		RCOM_ERR(printf("com_object_trace: error %8x retrieving description for function %d\n",hr,i));
		SEXP strSexp = PROTECT(mkChar("###"));
		protCnt++;
		SEXP vecSexp = PROTECT(allocVector(STRSXP,4));
		protCnt++;
		SET_STRING_ELT(namesattribute,i,strSexp);
		SET_STRING_ELT(vecSexp,0,strSexp);
		SET_STRING_ELT(vecSexp,1,strSexp);
		SET_STRING_ELT(vecSexp,2,strSexp);
		SET_STRING_ELT(vecSexp,3,strSexp);
		setAttrib(vecSexp,R_NamesSymbol,membnamesattribute);
		SET_VECTOR_ELT(rc,i,vecSexp);
	    } else {
		BSTR docbstr = NULL;
		hr = typeinfo->GetDocumentation(funcdesc->memid,NULL,&docbstr,NULL,NULL);
		char* docstr = NULL;
		if(SUCCEEDED(hr) && docbstr) {
		    docstr = BSTR2ANSI(docbstr);
		    SysFreeString(docbstr);
		} else {
		    docstr = NULL;
		}
		{
		    int j;
		    unsigned int cnt;
		    BSTR names[funcdesc->cParams+1];
		    for(j = 0;j < funcdesc->cParams+1;j++) names[j] = NULL;
		    hr = typeinfo->GetNames(funcdesc->memid,names,funcdesc->cParams+1,&cnt);
		    if(FAILED(hr)) {
			RCOM_ERR(printf("com_object_trace: failed %8x retrieving %d names for member id %d\n",
					hr,funcdesc->cParams+1,funcdesc->memid));
			SEXP strSexp = PROTECT(mkChar("***"));
			protCnt++;
			SEXP vecSexp = PROTECT(allocVector(STRSXP,4));
			protCnt++;
			SET_STRING_ELT(namesattribute,i,strSexp);
			SET_STRING_ELT(vecSexp,0,strSexp);
			SET_STRING_ELT(vecSexp,1,strSexp);
			SET_STRING_ELT(vecSexp,2,strSexp);
			SET_STRING_ELT(vecSexp,3,strSexp);
			setAttrib(vecSexp,R_NamesSymbol,membnamesattribute);
			SET_VECTOR_ELT(rc,i,vecSexp);
		    } else {
			char* funcname = BSTR2ANSI(names[0]);
			SEXP strSexp = PROTECT(mkChar(funcname));
			protCnt++;
			SEXP vecSexp = PROTECT(allocVector(STRSXP,4));
			protCnt++;
			SET_STRING_ELT(namesattribute,i,strSexp);
			SET_STRING_ELT(vecSexp,0,strSexp);
			SET_STRING_ELT(vecSexp,1,strSexp);
			SET_STRING_ELT(vecSexp,2,strSexp);
			SET_STRING_ELT(vecSexp,3,strSexp);
			setAttrib(vecSexp,R_NamesSymbol,membnamesattribute);
			SET_VECTOR_ELT(rc,i,vecSexp);
			free(funcname);
			SysFreeString(names[0]);
			for(j = 1;j < (int) cnt;j++) {
			    funcname = BSTR2ANSI(names[j]);
			    free(funcname);
			    SysFreeString(names[j]);
			}
		    }
		}
		typeinfo->ReleaseFuncDesc(funcdesc);
	    }
	}
	/* trace variables */
	/*  for(i = 0;i < attr->cFuncs;i++) {
	    }*/
	typeinfo->ReleaseTypeAttr(attr);
	typeinfo->Release();
	setAttrib(rc,R_NamesSymbol,namesattribute);
	UNPROTECT(protCnt);
	return rc;
    }

    SEXP com_version_get(SEXP sexp)
    {
	SEXP lRc = NULL;
	char* lEnd = NULL;

	lRc = PROTECT(allocVector(REALSXP,1));
	REAL(lRc)[0] = 
	    strtod(STRINGIFY(RCOM_VERSION_MAJOR) "." STRINGIFY(RCOM_VERSION_MINOR),
		   &lEnd);
	UNPROTECT(1);
	return lRc;
    }

    HRESULT STDMETHODCALLTYPE
    _IClassFactory_CreateInstance(void* _this,
				  LPUNKNOWN pUnkO,
				  REFIID riid,
				  LPVOID* ppvObj);

/** return the COM object for the internal server itself */
    SEXP com_this(SEXP null)
    {
	RCOM_OBJHANDLE handle = RCOM_NULLHANDLE;
	HRESULT hr;
	LPDISPATCH object = NULL;
	SEXP sexp = NULL;

	void* lTmp;
	hr = _IClassFactory_CreateInstance(NULL,NULL,
					   IID_IDispatch,
					   &lTmp);
	object = (LPDISPATCH) lTmp;

	if(SUCCEEDED(hr)) {
	    handle = com_addObject (object);
	    sexp = com_createSEXP(handle);
	    if(sexp == R_NilValue) {
		RCOM_ERR(printf("com_this: invalid SEXP for object, releasing object\n"));
		object->Release();
	    }
	}
	return sexp;
    }

/**
 * return a COM object implementing IPictureDisp from enhanced metafile
 * in clipboard
 */
    SEXP com_get_picture(SEXP pSexp)
    {
	HENHMETAFILE lMF = NULL;
	PICTDESC lPictDesc;
	HRESULT lRc;
	RCOM_OBJHANDLE handle = RCOM_NULLHANDLE;
	LPDISPATCH object = NULL;
	SEXP sexp = NULL;

	if(!OpenClipboard(NULL)) {
	    RCOM_ERR(printf("OpenClipboard() failed, error is %d\n",GetLastError()));
	    return R_NilValue;
	}
	if(!IsClipboardFormatAvailable(CF_ENHMETAFILE)) {
	    RCOM_TRACE(printf("IsClipboardFormatAvailable() no CF_ENHMETAFILE\n"));
	    return R_NilValue;
	}
	if(!(lMF = (HENHMETAFILE) GetClipboardData(CF_ENHMETAFILE))) {
	    RCOM_ERR(printf("GetClipboardData() failed, error is %d\n",GetLastError()));
	    return R_NilValue;
	}
	if(!CloseClipboard()) {
	    RCOM_ERR(printf("CloseClipboard() failed, error is %d\n",GetLastError()));
	    return R_NilValue;
	}

	/* now create an SEXP containing an array of bytes */
	memset(&lPictDesc,0,sizeof(lPictDesc));
	lPictDesc.cbSizeofstruct  = sizeof(lPictDesc);
	lPictDesc.picType = PICTYPE_ENHMETAFILE;
	lPictDesc.emf.hemf = lMF;

	void* lTmp;
	lRc = OleCreatePictureIndirect(&lPictDesc,
				       IID_IDispatch,
				       FALSE,
				       &lTmp);
	object = (LPDISPATCH) lTmp;

	if(FAILED(lRc)) {
	    RCOM_ERR(printf("OleCreatePictureIndirect() failed rc=%08x\n",lRc));
	    return R_NilValue;
	}
	handle = com_addObject (object);
	sexp = com_createSEXP(handle);
	if(sexp == R_NilValue) {
	    RCOM_ERR(printf("com_this: invalid SEXP for object, releasing object\n"));
	    object->Release();
	}
	return sexp;
    }
}

//  Arguments by reference
// If the method invoked returns a value via a VARIANT argument that is by ref or marked as [out] but is not the default return value, then for the argument in question, if you pass in a simple VARIANT, you will not get any value back. The VARIANT passed in will remain unchanged. You have to pass a VARIANT by reference to the Invoke method. This can be set up as follows: 


// VARIANT vretVal;
// VariantInit(&vretVal);
// VARIANT vretValRef;
// V_VT(&vretValRef) = VT_VARIANT | VT_BYREF;
// V_VARIANTREF(&vretValRef) = &vretVal;

// Then in the array of VARIANT arguments passed to Invoke, use vretValRef. Then the return value will then be returned in vretVal.
