/*******************************************************************************
 *  RCOM : COM Client and Server for R
 *  Copyright (C) 2003 Thomas Baier
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  ---------------------------------------------------------------------------
 *
 *  $Id: com_helpers.h 1.1 2003/04/27 16:32:32 baier Exp $
 *
 ******************************************************************************/

#ifdef __cplusplus
      extern "C" {
#endif

#include <windows.h>
#include <objbase.h>
#include <oleauto.h>
#include <wtypes.h>

/* Set the given key and its value. */
BOOL setKeyAndValue(const char* pszPath,const char * szSubkey,const char* szValue
			   ,const char * szName) ;

/* Convert a GUID into a char string. */
HRESULT GUID2ANSI(const GUID* guid, char* szGUID,int length) ;

/* Determine if a particular subkey exists. */
BOOL hasRegistrySubKey(const char* pszPath,  const char* szSubkey) ;

/* Delete szKeyChild and all of its descendents. */
LONG deleteRegistryKey(HKEY hKeyParent, const char* szKeyChild) ;


HRESULT _C_registerTypeLib(char const* szTypeLibFullName);
HRESULT _C_loadTypeLib(REFGUID libid,
		       unsigned short wVerMajor,
		       unsigned short wVerMinor,
		       LCID lcid,
		       ITypeLib** pITypeLib,
		       char const* szTypeLibFullName);
HRESULT _C_freeTypeLib(ITypeLib FAR* pITypeLib);
HRESULT _C_getTypeInfo(REFGUID guid,
		       ITypeLib* pITypeLib,
		       ITypeInfo** pITypeInfo);
HRESULT _C_RegisterServer(HMODULE hModule,
			  const CLSID* clsid,
			  const char* szFriendlyName,
			  const char* szVerIndProgID,
			  const char* szProgID,
			  const GUID* libid);
HRESULT _C_UnregisterServer(const CLSID* clsid,
			    const char* szVerIndProgID,
			    const char* szProgID);

typedef void (*__IUnknown_Delete)(void*);

struct tagUnknown {
  IUnknown obj;
  ULONG m_RefCount;
  __IUnknown_Delete Delete;
};
struct tagDispatch {
  IDispatch obj;
  ULONG m_RefCount;
  __IUnknown_Delete Delete;
  ITypeInfo* m_ptinfo;
};

typedef HRESULT WINAPI (*__IUnknown_QueryInterface)(IUnknown*,REFIID,LPVOID*);
typedef ULONG WINAPI (*__IUnknown_AddRef)(IUnknown*);
typedef ULONG WINAPI (*__IUnknown_Release)(IUnknown*);

ULONG STDMETHODCALLTYPE _IUnknown_AddRef(struct tagUnknown* _this);
ULONG STDMETHODCALLTYPE _IUnknown_Release(struct tagUnknown* _this);
HRESULT STDMETHODCALLTYPE _IUnknown_QueryInterface(struct tagUnknown* _this,
						   REFIID riid,
						   LPVOID* ppvObj);

typedef HRESULT WINAPI (*__IDispatch_QueryInterface)(IDispatch*,REFIID,LPVOID*);
typedef ULONG WINAPI (*__IDispatch_AddRef)(IDispatch*);
typedef ULONG WINAPI (*__IDispatch_Release)(IDispatch*);
typedef HRESULT WINAPI (*__IDispatch_GetTypeInfoCount)(IDispatch*,UINT*);
typedef HRESULT WINAPI (*__IDispatch_GetTypeInfo)(IDispatch*,UINT,LCID,
						  ITypeInfo**);
typedef HRESULT WINAPI (*__IDispatch_GetIDsOfNames)(IDispatch*,REFIID,
						    LPOLESTR*,UINT,DISPID*);
typedef HRESULT WINAPI (*__IDispatch_Invoke)(IDispatch*,DISPID,REFIID,
					     LCID,WORD,DISPPARAMS*,VARIANT*,
					     EXCEPINFO*,UINT*);

HRESULT STDMETHODCALLTYPE _IDispatch_GetTypeInfoCount(struct tagDispatch* _this,
						      UINT*);
HRESULT STDMETHODCALLTYPE _IDispatch_GetTypeInfo(struct tagDispatch* _this,
						 UINT iTInfo,
						 LCID lcid,
						 ITypeInfo** ppTInfo);
HRESULT STDMETHODCALLTYPE _IDispatch_GetIDsOfNames(struct tagDispatch* _this,
						   REFIID riid,
						   LPOLESTR* rgszNames,
						   UINT cNames,
						   LCID lcid,
						   DISPID* rgDispId);
HRESULT STDMETHODCALLTYPE _IDispatch_Invoke(struct tagDispatch* _this,
					    DISPID dispIdMember,
					    REFIID riid,
					    LCID lcid,
					    WORD wFlags,
					    DISPPARAMS* pDispParams,
					    VARIANT* pVarResult,
					    EXCEPINFO* pExcepInfo,
					    UINT* puArgErr);
HRESULT STDMETHODCALLTYPE _IDispatch_QueryInterface(struct tagDispatch* _this,
						    REFIID riid,
						    LPVOID* ppvObj);
#ifdef __cplusplus
}
#endif
