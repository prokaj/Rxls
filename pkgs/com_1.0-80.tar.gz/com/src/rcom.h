/*******************************************************************************
 *  RCOM : COM Client and Server for R
 *  Copyright (C) 2003-2006 Thomas Baier
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  ---------------------------------------------------------------------------
 *
 *  $Id: rcom.h 1.1 2003/04/27 16:33:06 baier Exp $
 *
 ******************************************************************************/

#ifdef __cplusplus
      extern "C" {
#endif


#define RCOM_SERVER_NAME "COM Statistics Interpreter Interface (R Internal)"
#define RCOM_SERVER_DESCRIPTION "R Internal Implementation: interface between a client application (e.g. a spread-sheet) and R"
#define RCOM_SERVER_COPYRIGHT "(C) 1999-2008, Thomas Baier, Erich Neuwirth"
#define RCOM_SERVER_LICENSE "GNU General Public License version 2 or greater"
#define RCOM_VERSION_MAJOR 2
#define RCOM_VERSION_MINOR 0

#define _STRINGIFY(x) #x
#define STRINGIFY(x) _STRINGIFY(x)

#define USE_EXTPTR 1

#undef Free
#undef ERROR
#include <windows.h>
#include <ole2.h>
#undef Free
#undef ERROR
#include <R.h>
#include <Rinternals.h>

#include "com_util.h"
#include "rproxy.h"

#ifdef NDEBUG
#define RCOM_ERR(x) R_Proxy_ ## x
#define RCOM_TRACE(x)
#else
#define RCOM_ERR(x) R_Proxy_ ## x
#define RCOM_TRACE(x) R_Proxy_ ## x
#endif

/** @name Exported Functions */
/*@{*/
/** Get a Handle to the COM server for this R instance.
 */
SEXP com_this(SEXP null);

/** Create a COM Object.
 *
 * Call #com_release()# when you're done with the object.
 *
 * @arg progid[0] is the program id of the COM object to create,
 *      e.g. #"Excel.Application"#
 * @return rc[0] = 0 on error, else the object handle
 */
SEXP com_create(SEXP progid);

/** Get access to a COM Object.
 *
 * Call #com_release()# when you're done with the object.
 *
 * @arg progid[0] is the program id of the COM object to create,
 *      e.g. #"Excel.Application"#
 * @return rc[0] = 0 on error, else the object handle
 */
SEXP com_getobject(SEXP progid);

/** Check for a valid COM Object.
 *
 * @arg handle[0] is the object handle as returned by com_create().
 * @return rc[0] is true if handle[0] is a valid object, false
 * otherwise
 */
SEXP com_isvalid(SEXP handle);

/** Set a Property.
 *
 * @arg handle is the object handle as returned by com_create().
 * @arg property is the name of the property
 * @arg value is the new property value
 */
SEXP com_property_set(SEXP handle,SEXP property,SEXP value);

/** Get a Property.
 *
 * @arg handle is the object handle as returned by com_create().
 * @arg property is the name of the property
 * @arg index is the name/index for a collection element (e.g. Item property)
 */
SEXP com_property_get(SEXP handle,SEXP property,SEXP index);

/** Call a COM Method.
 *
 * @arg handle is the object handle as returned by com_create().
 * @arg method is the name of the method to invoke
 * @arg property is the name of the property
 */
SEXP com_invoke(SEXP handle,SEXP method,SEXP args);

/** Return package version information.
 *
 */
SEXP com_version_get(SEXP sexp);

 /** trace the passed SEXP */
SEXP com_trace(SEXP sexp);

 /** return a COM object implementing IPictureDisp from enhanced metafile
   * in clipboard */
SEXP com_get_picture(SEXP sexp);
/*@}*/

/** @name Internal Functions */
/*@{*/
/** initialize the COM subsystem */
void com_initialize(void);
/** get the CLSID from an ANSI string (prod id or clsid string) */
HRESULT com_getCLSID(char const* str,LPCLSID pclsid);
/** get the COM object by handle */
/*LPDISPATCH com_getObject(RCOM_OBJHANDLE handle);*/
/** get the COM object index by handle */
/*RCOM_OBJHANDLE com_getHandle(SEXP handle);*/
/** add the COM object and return the new handle */
/*RCOM_OBJHANDLE com_addObject(LPDISPATCH object);*/
/** remove the COM object by handle */
/*void com_removeObject(RCOM_OBJHANDLE handle);*/
/** create an SEXP for a handle */
/*SEXP com_createSEXP(RCOM_OBJHANDLE handle);*/
/*@}*/

/** @name COM Data Type Conversions. */
/*@{*/
HRESULT com_GetIDsOfName(LPDISPATCH dsp,char const* name,DISPID* dispid);
/** get the OLECHAR[] from an ANSI string */
/* OLECHAR* com_getOLECHAR(char* str); */
/** get the BSTR from an ANSI string */
/* BSTR ANSI2BSTR(char* str); */
/** get the ANSI string from an BSTR */
/* char* BSTR2ANSI(BSTR bstr); */
/** create a VARIANT from an SEXP */
BOOL SEXP2Variant(SEXP sexp,VARIANT* variant);
/** create an SEXP from a VARIANT */
BOOL Variant2SEXP(VARIANT* variant,SEXP* sexp);
/*@}*/
#ifdef __cplusplus
}
#endif
