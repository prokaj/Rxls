/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Jan 25 09:09:50 2001
 */
/* Compiler settings for statconn.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __statconn_h__
#define __statconn_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ISGFX_FWD_DEFINED__
#define __ISGFX_FWD_DEFINED__
typedef interface ISGFX ISGFX;
#endif 	/* __ISGFX_FWD_DEFINED__ */


#ifndef __IStatConnectorCharacterDevice_FWD_DEFINED__
#define __IStatConnectorCharacterDevice_FWD_DEFINED__
typedef interface IStatConnectorCharacterDevice IStatConnectorCharacterDevice;
#endif 	/* __IStatConnectorCharacterDevice_FWD_DEFINED__ */


#ifndef __IStatConnectorUIAgent_FWD_DEFINED__
#define __IStatConnectorUIAgent_FWD_DEFINED__
typedef interface IStatConnectorUIAgent IStatConnectorUIAgent;
#endif 	/* __IStatConnectorUIAgent_FWD_DEFINED__ */


#ifndef __ISGFX_FWD_DEFINED__
#define __ISGFX_FWD_DEFINED__
typedef interface ISGFX ISGFX;
#endif 	/* __ISGFX_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
//PV. javitas
//javitas PV.
#ifndef __MIDL_user_allocate_free_DEFINED__
#define __MIDL_user_allocate_free_DEFINED__
  void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
  void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 
#endif

#ifndef __ISGFX_INTERFACE_DEFINED__
#define __ISGFX_INTERFACE_DEFINED__

/* interface ISGFX */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISGFX;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("18c8b663-81a2-11d3-9254-00e09812f727")
    ISGFX : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ActivateDevice( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DeactivateDevice( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE BeginDrawing( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE EndDrawing( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawLine( 
            /* [in] */ double dblStartX,
            /* [in] */ double dblStartY,
            /* [in] */ double dblEndX,
            /* [in] */ double dblEnd,
            /* [in] */ ULONG ulColor) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawCircle( 
            /* [in] */ double dblCenterX,
            /* [in] */ double dblCenterY,
            /* [in] */ double rad,
            /* [in] */ ULONG ulBorderColor,
            /* [in] */ ULONG ulFillColor) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawPolygon( 
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsX,
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsY,
            /* [in] */ ULONG ulBorderColor,
            /* [in] */ ULONG ulFillColor) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawPolyline( 
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsX,
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsY,
            /* [in] */ ULONG ulColor) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawRectangle( 
            /* [in] */ double dblStartX,
            /* [in] */ double dblStartY,
            /* [in] */ double dblEndX,
            /* [in] */ double dblEnd,
            /* [in] */ ULONG ulBorderColor,
            /* [in] */ ULONG ulFillColor) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawText( 
            /* [in] */ double dblX,
            /* [in] */ double dblY,
            /* [in] */ BSTR bstrText,
            /* [in] */ double dblAngle,
            /* [in] */ double dblAdjustment,
            /* [in] */ int iFont,
            /* [in] */ int iSize,
            /* [in] */ ULONG ulColor) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetClipping( 
            /* [in] */ double dblStartX,
            /* [in] */ double dblStartY,
            /* [in] */ double dblEndX,
            /* [in] */ double dblEndY) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetDimensions( 
            /* [out][in] */ double __RPC_FAR *pdblWidth,
            /* [out][in] */ double __RPC_FAR *pdblHeight) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetMousePosition( 
            /* [out][in] */ double __RPC_FAR *pdblX,
            /* [out][in] */ double __RPC_FAR *pdblY) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetStringWidth( 
            /* [in] */ BSTR bstrText,
            /* [retval][out] */ double __RPC_FAR *pdblWidth) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCharacterInformation( 
            /* [in] */ BSTR cCharacter,
            /* [out][in] */ double __RPC_FAR *pdblAscent,
            /* [out][in] */ double __RPC_FAR *pdblDescent,
            /* [out][in] */ double __RPC_FAR *pdblWidth) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ClearPage( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISGFXVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISGFX __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISGFX __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISGFX __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ActivateDevice )( 
            ISGFX __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DeactivateDevice )( 
            ISGFX __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *BeginDrawing )( 
            ISGFX __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *EndDrawing )( 
            ISGFX __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawLine )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ double dblStartX,
            /* [in] */ double dblStartY,
            /* [in] */ double dblEndX,
            /* [in] */ double dblEnd,
            /* [in] */ ULONG ulColor);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawCircle )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ double dblCenterX,
            /* [in] */ double dblCenterY,
            /* [in] */ double rad,
            /* [in] */ ULONG ulBorderColor,
            /* [in] */ ULONG ulFillColor);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawPolygon )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsX,
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsY,
            /* [in] */ ULONG ulBorderColor,
            /* [in] */ ULONG ulFillColor);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawPolyline )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsX,
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsY,
            /* [in] */ ULONG ulColor);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawRectangle )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ double dblStartX,
            /* [in] */ double dblStartY,
            /* [in] */ double dblEndX,
            /* [in] */ double dblEnd,
            /* [in] */ ULONG ulBorderColor,
            /* [in] */ ULONG ulFillColor);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawText )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ double dblX,
            /* [in] */ double dblY,
            /* [in] */ BSTR bstrText,
            /* [in] */ double dblAngle,
            /* [in] */ double dblAdjustment,
            /* [in] */ int iFont,
            /* [in] */ int iSize,
            /* [in] */ ULONG ulColor);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetClipping )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ double dblStartX,
            /* [in] */ double dblStartY,
            /* [in] */ double dblEndX,
            /* [in] */ double dblEndY);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetDimensions )( 
            ISGFX __RPC_FAR * This,
            /* [out][in] */ double __RPC_FAR *pdblWidth,
            /* [out][in] */ double __RPC_FAR *pdblHeight);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetMousePosition )( 
            ISGFX __RPC_FAR * This,
            /* [out][in] */ double __RPC_FAR *pdblX,
            /* [out][in] */ double __RPC_FAR *pdblY);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetStringWidth )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ BSTR bstrText,
            /* [retval][out] */ double __RPC_FAR *pdblWidth);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCharacterInformation )( 
            ISGFX __RPC_FAR * This,
            /* [in] */ BSTR cCharacter,
            /* [out][in] */ double __RPC_FAR *pdblAscent,
            /* [out][in] */ double __RPC_FAR *pdblDescent,
            /* [out][in] */ double __RPC_FAR *pdblWidth);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ClearPage )( 
            ISGFX __RPC_FAR * This);
        
        END_INTERFACE
    } ISGFXVtbl;

    interface ISGFX
    {
        CONST_VTBL struct ISGFXVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISGFX_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISGFX_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISGFX_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISGFX_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISGFX_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISGFX_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISGFX_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISGFX_ActivateDevice(This)	\
    (This)->lpVtbl -> ActivateDevice(This)

#define ISGFX_DeactivateDevice(This)	\
    (This)->lpVtbl -> DeactivateDevice(This)

#define ISGFX_BeginDrawing(This)	\
    (This)->lpVtbl -> BeginDrawing(This)

#define ISGFX_EndDrawing(This)	\
    (This)->lpVtbl -> EndDrawing(This)

#define ISGFX_DrawLine(This,dblStartX,dblStartY,dblEndX,dblEnd,ulColor)	\
    (This)->lpVtbl -> DrawLine(This,dblStartX,dblStartY,dblEndX,dblEnd,ulColor)

#define ISGFX_DrawCircle(This,dblCenterX,dblCenterY,rad,ulBorderColor,ulFillColor)	\
    (This)->lpVtbl -> DrawCircle(This,dblCenterX,dblCenterY,rad,ulBorderColor,ulFillColor)

#define ISGFX_DrawPolygon(This,adblPointsX,adblPointsY,ulBorderColor,ulFillColor)	\
    (This)->lpVtbl -> DrawPolygon(This,adblPointsX,adblPointsY,ulBorderColor,ulFillColor)

#define ISGFX_DrawPolyline(This,adblPointsX,adblPointsY,ulColor)	\
    (This)->lpVtbl -> DrawPolyline(This,adblPointsX,adblPointsY,ulColor)

#define ISGFX_DrawRectangle(This,dblStartX,dblStartY,dblEndX,dblEnd,ulBorderColor,ulFillColor)	\
    (This)->lpVtbl -> DrawRectangle(This,dblStartX,dblStartY,dblEndX,dblEnd,ulBorderColor,ulFillColor)

#define ISGFX_DrawText(This,dblX,dblY,bstrText,dblAngle,dblAdjustment,iFont,iSize,ulColor)	\
    (This)->lpVtbl -> DrawText(This,dblX,dblY,bstrText,dblAngle,dblAdjustment,iFont,iSize,ulColor)

#define ISGFX_SetClipping(This,dblStartX,dblStartY,dblEndX,dblEndY)	\
    (This)->lpVtbl -> SetClipping(This,dblStartX,dblStartY,dblEndX,dblEndY)

#define ISGFX_GetDimensions(This,pdblWidth,pdblHeight)	\
    (This)->lpVtbl -> GetDimensions(This,pdblWidth,pdblHeight)

#define ISGFX_GetMousePosition(This,pdblX,pdblY)	\
    (This)->lpVtbl -> GetMousePosition(This,pdblX,pdblY)

#define ISGFX_GetStringWidth(This,bstrText,pdblWidth)	\
    (This)->lpVtbl -> GetStringWidth(This,bstrText,pdblWidth)

#define ISGFX_GetCharacterInformation(This,cCharacter,pdblAscent,pdblDescent,pdblWidth)	\
    (This)->lpVtbl -> GetCharacterInformation(This,cCharacter,pdblAscent,pdblDescent,pdblWidth)

#define ISGFX_ClearPage(This)	\
    (This)->lpVtbl -> ClearPage(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_ActivateDevice_Proxy( 
    ISGFX __RPC_FAR * This);


void __RPC_STUB ISGFX_ActivateDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_DeactivateDevice_Proxy( 
    ISGFX __RPC_FAR * This);


void __RPC_STUB ISGFX_DeactivateDevice_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_BeginDrawing_Proxy( 
    ISGFX __RPC_FAR * This);


void __RPC_STUB ISGFX_BeginDrawing_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_EndDrawing_Proxy( 
    ISGFX __RPC_FAR * This);


void __RPC_STUB ISGFX_EndDrawing_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_DrawLine_Proxy( 
    ISGFX __RPC_FAR * This,
    /* [in] */ double dblStartX,
    /* [in] */ double dblStartY,
    /* [in] */ double dblEndX,
    /* [in] */ double dblEnd,
    /* [in] */ ULONG ulColor);


void __RPC_STUB ISGFX_DrawLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_DrawCircle_Proxy( 
    ISGFX __RPC_FAR * This,
    /* [in] */ double dblCenterX,
    /* [in] */ double dblCenterY,
    /* [in] */ double rad,
    /* [in] */ ULONG ulBorderColor,
    /* [in] */ ULONG ulFillColor);


void __RPC_STUB ISGFX_DrawCircle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_DrawPolygon_Proxy( 
    ISGFX __RPC_FAR * This,
    /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsX,
    /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsY,
    /* [in] */ ULONG ulBorderColor,
    /* [in] */ ULONG ulFillColor);


void __RPC_STUB ISGFX_DrawPolygon_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_DrawPolyline_Proxy( 
    ISGFX __RPC_FAR * This,
    /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsX,
    /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *adblPointsY,
    /* [in] */ ULONG ulColor);


void __RPC_STUB ISGFX_DrawPolyline_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_DrawRectangle_Proxy( 
    ISGFX __RPC_FAR * This,
    /* [in] */ double dblStartX,
    /* [in] */ double dblStartY,
    /* [in] */ double dblEndX,
    /* [in] */ double dblEnd,
    /* [in] */ ULONG ulBorderColor,
    /* [in] */ ULONG ulFillColor);


void __RPC_STUB ISGFX_DrawRectangle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_DrawText_Proxy( 
    ISGFX __RPC_FAR * This,
    /* [in] */ double dblX,
    /* [in] */ double dblY,
    /* [in] */ BSTR bstrText,
    /* [in] */ double dblAngle,
    /* [in] */ double dblAdjustment,
    /* [in] */ int iFont,
    /* [in] */ int iSize,
    /* [in] */ ULONG ulColor);


void __RPC_STUB ISGFX_DrawText_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_SetClipping_Proxy( 
    ISGFX __RPC_FAR * This,
    /* [in] */ double dblStartX,
    /* [in] */ double dblStartY,
    /* [in] */ double dblEndX,
    /* [in] */ double dblEndY);


void __RPC_STUB ISGFX_SetClipping_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_GetDimensions_Proxy( 
    ISGFX __RPC_FAR * This,
    /* [out][in] */ double __RPC_FAR *pdblWidth,
    /* [out][in] */ double __RPC_FAR *pdblHeight);


void __RPC_STUB ISGFX_GetDimensions_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_GetMousePosition_Proxy( 
    ISGFX __RPC_FAR * This,
    /* [out][in] */ double __RPC_FAR *pdblX,
    /* [out][in] */ double __RPC_FAR *pdblY);


void __RPC_STUB ISGFX_GetMousePosition_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_GetStringWidth_Proxy( 
    ISGFX __RPC_FAR * This,
    /* [in] */ BSTR bstrText,
    /* [retval][out] */ double __RPC_FAR *pdblWidth);


void __RPC_STUB ISGFX_GetStringWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_GetCharacterInformation_Proxy( 
    ISGFX __RPC_FAR * This,
    /* [in] */ BSTR cCharacter,
    /* [out][in] */ double __RPC_FAR *pdblAscent,
    /* [out][in] */ double __RPC_FAR *pdblDescent,
    /* [out][in] */ double __RPC_FAR *pdblWidth);


void __RPC_STUB ISGFX_GetCharacterInformation_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISGFX_ClearPage_Proxy( 
    ISGFX __RPC_FAR * This);


void __RPC_STUB ISGFX_ClearPage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISGFX_INTERFACE_DEFINED__ */


#ifndef __IStatConnectorCharacterDevice_INTERFACE_DEFINED__
#define __IStatConnectorCharacterDevice_INTERFACE_DEFINED__

/* interface IStatConnectorCharacterDevice */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IStatConnectorCharacterDevice;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("18c8b664-81a2-11d3-9254-00e09812f727")
    IStatConnectorCharacterDevice : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteString( 
            /* [in] */ BSTR bstrLine) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteStringLevel( 
            /* [in] */ BSTR bstrLine,
            /* [in] */ LONG lLevel) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Clear( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IStatConnectorCharacterDeviceVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IStatConnectorCharacterDevice __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IStatConnectorCharacterDevice __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IStatConnectorCharacterDevice __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IStatConnectorCharacterDevice __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IStatConnectorCharacterDevice __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IStatConnectorCharacterDevice __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IStatConnectorCharacterDevice __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteString )( 
            IStatConnectorCharacterDevice __RPC_FAR * This,
            /* [in] */ BSTR bstrLine);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteStringLevel )( 
            IStatConnectorCharacterDevice __RPC_FAR * This,
            /* [in] */ BSTR bstrLine,
            /* [in] */ LONG lLevel);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Clear )( 
            IStatConnectorCharacterDevice __RPC_FAR * This);
        
        END_INTERFACE
    } IStatConnectorCharacterDeviceVtbl;

    interface IStatConnectorCharacterDevice
    {
        CONST_VTBL struct IStatConnectorCharacterDeviceVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStatConnectorCharacterDevice_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStatConnectorCharacterDevice_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStatConnectorCharacterDevice_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStatConnectorCharacterDevice_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IStatConnectorCharacterDevice_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IStatConnectorCharacterDevice_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IStatConnectorCharacterDevice_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IStatConnectorCharacterDevice_WriteString(This,bstrLine)	\
    (This)->lpVtbl -> WriteString(This,bstrLine)

#define IStatConnectorCharacterDevice_WriteStringLevel(This,bstrLine,lLevel)	\
    (This)->lpVtbl -> WriteStringLevel(This,bstrLine,lLevel)

#define IStatConnectorCharacterDevice_Clear(This)	\
    (This)->lpVtbl -> Clear(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnectorCharacterDevice_WriteString_Proxy( 
    IStatConnectorCharacterDevice __RPC_FAR * This,
    /* [in] */ BSTR bstrLine);


void __RPC_STUB IStatConnectorCharacterDevice_WriteString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnectorCharacterDevice_WriteStringLevel_Proxy( 
    IStatConnectorCharacterDevice __RPC_FAR * This,
    /* [in] */ BSTR bstrLine,
    /* [in] */ LONG lLevel);


void __RPC_STUB IStatConnectorCharacterDevice_WriteStringLevel_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IStatConnectorCharacterDevice_Clear_Proxy( 
    IStatConnectorCharacterDevice __RPC_FAR * This);


void __RPC_STUB IStatConnectorCharacterDevice_Clear_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IStatConnectorCharacterDevice_INTERFACE_DEFINED__ */


#ifndef __IStatConnectorUIAgent_INTERFACE_DEFINED__
#define __IStatConnectorUIAgent_INTERFACE_DEFINED__

/* interface IStatConnectorUIAgent */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IStatConnectorUIAgent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("18c8b665-81a2-11d3-9254-00e09812f727")
    IStatConnectorUIAgent : public IDispatch
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IStatConnectorUIAgentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IStatConnectorUIAgent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IStatConnectorUIAgent __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IStatConnectorUIAgent __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IStatConnectorUIAgent __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IStatConnectorUIAgent __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IStatConnectorUIAgent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IStatConnectorUIAgent __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IStatConnectorUIAgentVtbl;

    interface IStatConnectorUIAgent
    {
        CONST_VTBL struct IStatConnectorUIAgentVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IStatConnectorUIAgent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IStatConnectorUIAgent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IStatConnectorUIAgent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IStatConnectorUIAgent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IStatConnectorUIAgent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IStatConnectorUIAgent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IStatConnectorUIAgent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IStatConnectorUIAgent_INTERFACE_DEFINED__ */



#ifndef __StatConnectorCommonLib_LIBRARY_DEFINED__
#define __StatConnectorCommonLib_LIBRARY_DEFINED__

/* library StatConnectorCommonLib */
/* [helpstring][version][uuid] */ 




EXTERN_C const IID LIBID_StatConnectorCommonLib;
#endif /* __StatConnectorCommonLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  LPSAFEARRAY_UserSize(     unsigned long __RPC_FAR *, unsigned long            , LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
void                      __RPC_USER  LPSAFEARRAY_UserFree(     unsigned long __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
